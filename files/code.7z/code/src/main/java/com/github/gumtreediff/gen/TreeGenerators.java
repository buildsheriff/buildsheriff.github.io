package com.github.gumtreediff.gen;

import com.github.gumtreediff.tree.TreeContext;

import java.io.IOException;
import java.util.Arrays;
import java.util.regex.Pattern;

public class TreeGenerators extends Registry<String, TreeGenerator, Register> {

    private static TreeGenerators registry;

    /**
     * Return the tree generators registry instance (singleton pattern)
     */
    public static TreeGenerators getInstance() {
        if (registry == null)
            registry = new TreeGenerators();
        return registry;
    }

    /**
     * Automatically search a tree generator for the given file path, and use it
     * to parse it
     * @param file the file path
     * @return the TreeContext of the file
     * @throws UnsupportedOperationException if no suitable generator is found
     */
    public TreeContext getTree(String file) throws UnsupportedOperationException, IOException {
        // 处理JAVA文件的类 class com.github.gumtreediff.gen.jdt.JdtTreeGenerator
        TreeGenerator p = get(file);
        if (p == null)
            throw new UnsupportedOperationException("No generator found for file: " + file);
        return p.generateFrom().file(file);
    }

    /**
     * Use the tree generator with the supplied name to parse the file at the given path
     * to parse it
     * @param generator the tree generator's name. if null, fallbacks to @see getTree(String)
     * @throws UnsupportedOperationException if no suitable generator is found
     */
    public TreeContext getTree(String file, String generator) throws UnsupportedOperationException, IOException {
        if (generator == null)
            return getTree(file);

        for (Entry e : entries)
            if (e.id.equals(generator))
                return e.instantiate(null).generateFrom().file(file);

        throw new UnsupportedOperationException("No generator \"" + generator + "\" found.");
    }

    public boolean has(String generator) {
        return this.findById(generator) != null;
    }

    /**
     * Indicate whether or not the given file path has a related tree generator
     */
    public boolean hasGeneratorForFile(String file) {
        return get(file) != null;
    }

    @Override
    protected Entry newEntry(Class<? extends TreeGenerator> clazz, Register annotation) {
        return new Entry(annotation.id(), clazz, defaultFactory(clazz), annotation.priority()) {
            final Pattern[] accept;

            {
                String[] accept = annotation.accept();
                this.accept = new Pattern[accept.length];
                for (int i = 0; i < accept.length; i++)
                    this.accept[i] = Pattern.compile(accept[i]);
            }

            @Override
            protected boolean handle(String key) {
                for (Pattern pattern : accept)
                    if (pattern.matcher(key).find())
                        return true;
                return false;
            }

            @Override
            public String toString() {
                return String.format("%d\t%s\t%s: %s", priority, id, Arrays.toString(accept), clazz.getCanonicalName());
            }
        };
    }
}
