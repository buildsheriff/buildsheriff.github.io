package com.github.gumtreediff.matchers.heuristic.gt;

import com.github.gumtreediff.tree.Tree;

import java.util.List;
import java.util.function.Function;

public interface PriorityTreeQueue {
    Function<Tree, Integer> HEIGHT_PRIORITY_CALCULATOR = (Tree t) -> t.getMetrics().height;
    Function<Tree, Integer> SIZE_PRIORITY_CALCULATOR = (Tree t) -> t.getMetrics().size;

    static Function<Tree, Integer> getPriorityCalculator(String name) {
        if ("size".equals(name))
            return SIZE_PRIORITY_CALCULATOR;
        else if ("height".equals(name))
            return HEIGHT_PRIORITY_CALCULATOR;
        else
            return HEIGHT_PRIORITY_CALCULATOR;
    }

    /**
     * Return the list of trees with the greatest priority, and place all
     * their children in the queue.
     * @return
     */
    List<Tree> popOpen();

    /**
     * Set the function that computes the priority on a given tree.
     */
    void setPriorityCalculator(Function<Tree, Integer> calculator);

    /**
     * Return the list of trees with the greatest priority.
     * @return
     */
    List<Tree> pop();

    /**
     * Put the child of the tree into the priority queue.
     * @return
     */
    void open(Tree tree);

    /**
     * Return the current greatest priority.
     * @return
     */
    int currentPriority();

    /**
     * Set the minimum priority of a Tree to enter the queue.
     */
    void setMinimumPriority(int priority);

    /**
     * Return the minimum priority of a Tree to enter the queue.
     */
    int getMinimumPriority();

    /**
     * Return if there is any tree in the queue.
     */
    boolean isEmpty();

    /**
     * Empty the queue.
     */
    void clear();

    /**
     * Pop the provided queues until their current priorities are equal or they are empty.
     */
    static void synchronize(PriorityTreeQueue q1, PriorityTreeQueue q2) {
        if (q1.isEmpty() || q2.isEmpty()) {
            q1.clear();
            q2.clear();
            return;
        }

        while (q1.currentPriority() != q2.currentPriority()) {
            List<Tree> pop = (q1.currentPriority() > q2.currentPriority()) ? q1.popOpen() : q2.popOpen();
            if (q1.isEmpty() || q2.isEmpty()) {
                q1.clear();
                q2.clear();
                return;
            }
        }
    }
}
