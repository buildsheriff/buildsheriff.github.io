package com.github.gumtreediff.matchers.heuristic.gt;

import com.github.gumtreediff.matchers.Mapping;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.utils.SequenceAlgorithms;

import java.util.*;

public final class ParentsMappingComparator extends AbstractMappingComparator {

    public ParentsMappingComparator(List<Mapping> ambiguousMappings, MappingStore mappings,
                                    int maxTreeSize) {
        super(ambiguousMappings, mappings, maxTreeSize);
        for (Mapping ambiguousMapping: ambiguousMappings)
            similarities.put(ambiguousMapping, similarity(ambiguousMapping.first, ambiguousMapping.second));
    }

    @Override
    protected double similarity(Tree src, Tree dst) {
        return 100D * parentsJaccardSimilarity(src, dst)
                + 10D * posInParentSimilarity(src, dst) + numberingSimilarity(src , dst);
    }

    protected double parentsJaccardSimilarity(Tree src, Tree dst) {
        List<Tree> srcParents = src.getParents();
        List<Tree> dstParents = dst.getParents();
        double numerator =
                (double) SequenceAlgorithms.longestCommonSubsequenceWithTypeAndLabel(srcParents, dstParents).size();
        double denominator = (double) srcParents.size() + (double) dstParents.size() - numerator;
        return numerator / denominator;
    }

}