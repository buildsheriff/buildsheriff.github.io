package com.github.gumtreediff.matchers.heuristic.gt;

import com.github.gumtreediff.tree.Tree;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.Function;

public class DefaultPriorityTreeQueue implements PriorityTreeQueue {
    private Function<Tree, Integer> priorityCalculator;
    private SortedMap<Integer, List<Tree>> trees;
    private int minimumPriority;

    public DefaultPriorityTreeQueue(Tree root, int minimumPriority, Function<Tree, Integer> priorityCalculator) {
        this.trees = new TreeMap<>();
        this.setMinimumPriority(minimumPriority);
        this.setPriorityCalculator(priorityCalculator);
        add(root);
    }

    @Override
    public List<Tree> popOpen() {
        List<Tree> pop = pop();
        for (Tree t: pop)
            open(t);
        return pop;
    }

    @Override
    public void setPriorityCalculator(Function<Tree, Integer> priorityCalculator) {
        this.priorityCalculator = priorityCalculator;
    }

    @Override
    public List<Tree> pop() {
        return trees.remove(currentPriority());
    }

    @Override
    public void open(Tree tree) {
        for (Tree c: tree.getChildren())
            add(c);
    }

    @Override
    public int currentPriority() {
        return trees.lastKey();
    }

    @Override
    public void setMinimumPriority(int minimumPriority) {
        this.minimumPriority = minimumPriority;
    }

    @Override
    public int getMinimumPriority() {
        return this.minimumPriority;
    }

    @Override
    public boolean isEmpty() {
        return trees.isEmpty();
    }

    @Override
    public void clear() {
        trees.clear();
    }

    private void add(Tree t) {
        int priority = priorityCalculator.apply(t);
        if (priority < this.getMinimumPriority())
            return;

        if (trees.get(priority) == null)
            trees.put(priority, new ArrayList<>());
        trees.get(priority).add(t);
    }
}
