package com.github.gumtreediff.tree;

import org.eclipse.jdt.core.dom.ASTNode;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

public class DefaultTree extends AbstractTree implements Tree {
    private Type type;

    private String label;

    private int pos;
    private int length;

    private ASTNode astNode;

    private AssociationMap metadata;

    private int startLineNum;
    private int endLineNum;

    public DefaultTree(Type type) {
        this(type, NO_LABEL);
    }

    public DefaultTree(Type type, String label) {
        this.type = type;
        this.label = (label == null) ? NO_LABEL : label.intern();
        this.children = new ArrayList<>();
    }

    protected DefaultTree(Tree other) {
        this.type = other.getType();
        this.label = other.getLabel();
        this.pos = other.getPos();
        this.length = other.getLength();
        this.children = new ArrayList<>();
    }

    @Override
    public Tree deepCopy() {
        Tree copy = new DefaultTree(this);
        for (Tree child : getChildren())
            copy.addChild(child.deepCopy());
        return copy;
    }
    @Override
    public int getStartLineNum() {
        return startLineNum;
    }
    @Override
    public void setStartLineNum(int startLineNum) {
        this.startLineNum = startLineNum;
    }
    @Override
    public int getEndLineNum() {
        return endLineNum;
    }
    @Override
    public void setEndLineNum(int endLineNum) {
        this.endLineNum = endLineNum;
    }

    @Override
    public ASTNode getASTNode() {
        return astNode;
    }

    @Override
    public void setASTNode(ASTNode node) {
        this.astNode = node;
    }

    @Override
    public String getLabel() {
        return label;
    }

    @Override
    public int getLength() {
        return length;
    }

    @Override
    public int getPos() {
        return pos;
    }

    @Override
    public Type getType() {
        return type;
    }

    @Override
    public void setLabel(String label) {
        this.label = (label == null) ? NO_LABEL : label.intern();
    }

    @Override
    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public void setPos(int pos) {
        this.pos = pos;
    }

    @Override
    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public Object getMetadata(String key) {
        if (metadata == null)
            return null;
        return metadata.get(key);
    }

    @Override
    public Object setMetadata(String key, Object value) {
        if (value == null) {
            if (metadata == null)
                return null;
            else
                return metadata.remove(key);
        }
        if (metadata == null)
            metadata = new AssociationMap();
        return metadata.set(key, value);
    }

    @Override
    public Iterator<Entry<String, Object>> getMetadata() {
        if (metadata == null)
            return new EmptyEntryIterator();
        return metadata.iterator();
    }
}
