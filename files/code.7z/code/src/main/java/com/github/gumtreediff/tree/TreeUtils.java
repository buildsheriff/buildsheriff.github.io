package com.github.gumtreediff.tree;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import com.github.gumtreediff.utils.Pair;

public final class TreeUtils {
    private TreeUtils() {
    }

    public static List<Tree> preOrder(Tree tree) {
        List<Tree> trees = new ArrayList<>();
        preOrder(tree, trees);
        return trees;
    }

    private static void preOrder(Tree tree, List<Tree> trees) {
        trees.add(tree);
        if (!tree.isLeaf())
            for (Tree c: tree.getChildren())
                preOrder(c, trees);
    }

    public static List<Tree> breadthFirst(Tree tree) {
        List<Tree> trees = new ArrayList<>();
        List<Tree> currents = new ArrayList<>();
        currents.add(tree);
        while (currents.size() > 0) {
            Tree c = currents.remove(0);
            trees.add(c);
            currents.addAll(c.getChildren());
        }
        return trees;
    }

    public static Iterator<Tree> breadthFirstIterator(final Tree tree) {
        return new Iterator<Tree>() {
            Deque<Iterator<Tree>> fifo = new ArrayDeque<>();

            {
                addLasts(new FakeTree(tree));
            }

            @Override
            public boolean hasNext() {
                return !fifo.isEmpty();
            }

            @Override
            public Tree next() {
                while (!fifo.isEmpty()) {
                    Iterator<Tree> it = fifo.getFirst();
                    if (it.hasNext()) {
                        Tree item = it.next();
                        if (!it.hasNext())
                            fifo.removeFirst();
                        addLasts(item);
                        return item;
                    }
                }
                throw new NoSuchElementException();
            }

            private void addLasts(Tree item) {
                List<Tree> children = item.getChildren();
                if (!children.isEmpty())
                    fifo.addLast(children.iterator());
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static List<Tree> postOrder(Tree tree) {
        List<Tree> trees = new ArrayList<>();
        postOrder(tree, trees);
        return trees;
    }

    private static void postOrder(Tree tree, List<Tree> trees) {
        if (!tree.isLeaf())
            for (Tree c: tree.getChildren())
                postOrder(c, trees);
        trees.add(tree);
    }

    public static Iterator<Tree> postOrderIterator(final Tree tree) {
        return new Iterator<Tree>() {
            Deque<Pair<Tree, Iterator<Tree>>> stack = new ArrayDeque<>();
            {
                push(tree);
            }

            @Override
            public boolean hasNext() {
                return stack.size() > 0;
            }

            @Override
            public Tree next() {
                if (stack.isEmpty())
                    throw new NoSuchElementException();
                return selectNextChild(stack.peek().second);
            }

            Tree selectNextChild(Iterator<Tree> it) {
                if (!it.hasNext())
                    return stack.pop().first;
                Tree item = it.next();
                if (item.isLeaf())
                    return item;
                return selectNextChild(push(item));
            }

            private Iterator<Tree> push(Tree item) {
                Iterator<Tree> it = item.getChildren().iterator();
                stack.push(new Pair<>(item, it));
                return it;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static Iterator<Tree> preOrderIterator(Tree tree) {
        return new Iterator<Tree>() {
            Deque<Iterator<Tree>> stack = new ArrayDeque<>();
            {
                push(new FakeTree(tree));
            }

            @Override
            public boolean hasNext() {
                return stack.size() > 0;
            }

            @Override
            public Tree next() {
                Iterator<Tree> it = stack.peek();
                if (it == null)
                    throw new NoSuchElementException();
                Tree t = it.next();
                while (it != null && !it.hasNext()) {
                    stack.pop();
                    it = stack.peek();
                }
                push(t);
                return t;
            }

            private void push(Tree tree) {
                if (!tree.isLeaf())
                    stack.push(tree.getChildren().iterator());
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public static Iterator<Tree> leafIterator(final Iterator<Tree> it) {
        return new Iterator<Tree>() {
            Tree current = it.hasNext() ? it.next() : null;
            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public Tree next() {
                Tree val = current;
                while (it.hasNext()) {
                    current = it.next();
                    if (current.isLeaf())
                        break;
                }
                if (!it.hasNext()) {
                    current = null;
                }
                return val;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}
