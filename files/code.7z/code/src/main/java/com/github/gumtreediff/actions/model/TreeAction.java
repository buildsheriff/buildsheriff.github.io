package com.github.gumtreediff.actions.model;

import com.github.gumtreediff.tree.Tree;

public abstract class TreeAction extends Action {
    public TreeAction(Tree node) {
        super(node);
    }
}
