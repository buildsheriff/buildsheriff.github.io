package com.github.gumtreediff.matchers;

public enum ConfigurationOptions {
    bu_minsim,

    bu_minsize,

    st_minprio,

    st_priocalc,

    cd_labsim,

    cd_maxleaves,

    cd_structsim1,

    cd_structsim2,

    xy_minsim,
}
