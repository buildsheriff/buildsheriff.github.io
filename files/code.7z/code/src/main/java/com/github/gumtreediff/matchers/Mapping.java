package com.github.gumtreediff.matchers;

import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.utils.Pair;

public class Mapping extends Pair<Tree, Tree> {
    public Mapping(Tree a, Tree b) {
        super(a, b);
    }
}
