package com.github.gumtreediff.tree;

import static com.github.gumtreediff.tree.TypeSet.type;

public final class Type {

    public final String name;

    public static final Type NO_TYPE = type("");

    private Type(String value) {
        name = value;
    }

    public boolean isEmpty() {
        return this == NO_TYPE;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    static class TypeFactory {
        protected TypeFactory() {}

        protected Type makeType(String name) {
            return new Type(name);
        }
    }
}

