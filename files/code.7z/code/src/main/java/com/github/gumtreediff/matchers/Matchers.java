package com.github.gumtreediff.matchers;

import com.github.gumtreediff.gen.Registry;
import com.github.gumtreediff.matchers.heuristic.LcsMatcher;

public class Matchers extends Registry<String, Matcher, Register> {

    private static Matchers registry;
    private Factory<? extends Matcher> defaultMatcherFactory; // FIXME shouln't be removed and use priority instead ?

    public static Matchers getInstance() {
        if (registry == null)
            registry = new Matchers();
        return registry;
    }

    private Matchers() {
        install(CompositeMatchers.ClassicGumtree.class);
        install(CompositeMatchers.SimpleGumtree.class);
        install(CompositeMatchers.SimpleIdGumtree.class);
        install(CompositeMatchers.ChangeDistiller.class);
        install(CompositeMatchers.XyMatcher.class);
        install(LcsMatcher.class);
        install(CompositeMatchers.ClassicGumtreeTheta.class);
        install(CompositeMatchers.Theta.class);
        install(CompositeMatchers.ChangeDistillerTheta.class);
        install(CompositeMatchers.SimpleIdGumtreeTheta.class);
    }

    private void install(Class<? extends Matcher> clazz) {
        Register a = clazz.getAnnotation(Register.class);
        if (a == null)
            throw new RuntimeException("Expecting @Register annotation on " + clazz.getName());
        if (defaultMatcherFactory == null && a.defaultMatcher())
            defaultMatcherFactory = defaultFactory(clazz);
        install(clazz, a);
    }

    public Matcher getMatcher(String id) {
        return get(id);
    }

    public Matcher getMatcherWithFallback(String id) {
        if (id == null)
            return getMatcher();

        Matcher matcher = get(id);
        if (matcher != null)
            return matcher;
        else
            return getMatcher();
    }

    public Matcher getMatcher() {
        return defaultMatcherFactory.instantiate(new Object[]{});
    }

    protected String getName(Register annotation, Class<? extends Matcher> clazz) {
        return annotation.id();
    }

    @Override
    protected Entry newEntry(Class<? extends Matcher> clazz, Register annotation) {
        return new Entry(annotation.id(), clazz,
                defaultFactory(clazz), annotation.priority()) {

            @Override
            protected boolean handle(String key) {
                return annotation.id().equals(key); // Fixme remove
            }
        };
    }
}
