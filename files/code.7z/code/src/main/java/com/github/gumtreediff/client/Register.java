package com.github.gumtreediff.client;

import com.github.gumtreediff.gen.Registry;
import org.atteo.classindex.IndexAnnotated;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@IndexAnnotated
public @interface Register {
    String name() default no_value;
    String description() default "";
    int priority() default Registry.Priority.MEDIUM;

    Class<? extends Option.Context> options() default NoOption.class;

    String no_value = "";
    class NoOption implements Option.Context {
        @Override
        public Option[] values() {
            return new Option[]{};
        }
    }
}
