package com.github.gumtreediff.client.diff;

import com.github.gumtreediff.actions.Diff;
import com.github.gumtreediff.client.Option;
import com.github.gumtreediff.gen.Registry;
import com.github.gumtreediff.io.TreeIoUtils;
import com.github.gumtreediff.client.Register;

@Register(name = "axmldiff", description = "Dump annotated xml tree",
        priority = Registry.Priority.LOW, options = AbstractDiffClient.DiffOptions.class)
public class AnnotatedXmlDiff extends AbstractDiffClient<AnnotatedXmlDiff.AnnotatedXmlDiffOptions> {

    public AnnotatedXmlDiff(String[] args) {
        super(args);
    }

    static class AnnotatedXmlDiffOptions extends AbstractDiffClient.DiffOptions {
        protected boolean isSrc = true;

        @Override
        public Option[] values() {
            return Option.Context.addValue(super.values(),
                    new Option("--src", String.format("Dump source tree (default: %s)", isSrc ? "yes" : "no"), 0) {
                        @Override
                        protected void process(String name, String[] args) {
                            isSrc = true;
                        }
                    },
                    new Option("--dst", String.format("Dump destination tree (default: %s)", !isSrc
                                    ? "yes" : "no"), 0) {
                        @Override
                        protected void process(String name, String[] args) {
                            isSrc = false;
                        }
                    }
            );
        }
    }

    @Override
    protected AnnotatedXmlDiffOptions newOptions() {
        return new AnnotatedXmlDiffOptions();
    }

    @Override
    public void run() throws Exception {
        Diff diff = getDiff();
        TreeIoUtils.toAnnotatedXml((opts.isSrc)
                            ? diff.src
                            : diff.dst, opts.isSrc, diff.mappings
        ).writeTo(System.out);
    }
}
