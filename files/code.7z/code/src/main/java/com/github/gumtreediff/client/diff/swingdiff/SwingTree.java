package com.github.gumtreediff.client.diff.swingdiff;

import com.github.gumtreediff.gen.TreeGenerators;
import com.github.gumtreediff.tree.TreeContext;

import javax.swing.*;
import java.io.IOException;

public final class SwingTree {

    public static void main(String[] args) throws IOException {
        final TreeContext t = TreeGenerators.getInstance().getTree(args[0]);
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                createAndShow(t);
            }
        });
    }

    private SwingTree() {
    }

    private static void createAndShow(TreeContext tree) {
        JFrame frame = new JFrame("Tree Viewer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new TreePanel(tree));
        frame.pack();
        frame.setVisible(true);
    }
}