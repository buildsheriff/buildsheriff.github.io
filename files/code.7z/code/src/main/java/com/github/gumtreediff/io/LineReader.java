package com.github.gumtreediff.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;

public class LineReader extends Reader {
    private Reader reader;

    private int currentPos = 0;

    private ArrayList<Integer> lines = new ArrayList<>(Arrays.asList(-1));

    public LineReader(Reader parent) {
        reader = parent;
    }

    @Override
    public int read(char[] cbuf, int off, int len) throws IOException {
        int r = reader.read(cbuf, off, len);
        for (int i = 0; i < len; i ++)
            if (cbuf[off + i] == '\n')
                lines.add(currentPos + i);
        currentPos += len;
        return r;
    }

    public int positionFor(int line, int column) {
        if (lines.size() < line)
            return -1;

        return lines.get(line - 1) + column;
    }

    @Override
    public void close() throws IOException {
        reader.close();
    }
}
