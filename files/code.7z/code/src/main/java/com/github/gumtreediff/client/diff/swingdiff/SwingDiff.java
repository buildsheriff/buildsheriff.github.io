package com.github.gumtreediff.client.diff.swingdiff;

import com.github.gumtreediff.actions.Diff;
import com.github.gumtreediff.client.Register;
import com.github.gumtreediff.client.diff.AbstractDiffClient;

import javax.swing.*;

import java.io.IOException;

@Register(description = "A swing diff client", options = AbstractDiffClient.DiffOptions.class)
public final class SwingDiff extends AbstractDiffClient<AbstractDiffClient.DiffOptions> {

    public SwingDiff(String[] args) {
        super(args);
    }

    @Override
    public void run() throws IOException {
        Diff diff = getDiff();
        javax.swing.SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("GumTree");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new MappingsPanel(opts.srcPath, opts.dstPath, diff));
            frame.pack();
            frame.setVisible(true);
        });
    }

    @Override
    protected DiffOptions newOptions() {
        return new DiffOptions();
    }
}