package com.github.gumtreediff.actions;

import com.github.gumtreediff.actions.model.Action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EditScript implements Iterable<Action> {
    private List<Action> actions;

    public EditScript() {
        actions = new ArrayList<>();
    }

    public Iterator<Action> iterator() {
        return actions.iterator();
    }

    public void add(Action action) {
        actions.add(action);
    }

    public void add(int index, Action action) {
        actions.add(index, action);
    }

    public Action get(int index) {
        return actions.get(index);
    }

    public int size() {
        return actions.size();
    }

    public boolean remove(Action action) {
        return actions.remove(action);
    }

    public Action remove(int index) {
        return actions.remove(index);
    }

    public List<Action> asList() {
        return actions;
    }

    public int lastIndexOf(Action action) {
        return actions.lastIndexOf(action);
    }
}
