package com.github.gumtreediff.actions.model;

import com.github.gumtreediff.tree.Tree;

public class Move extends TreeAddition {
    public Move(Tree node, Tree parent, int pos) {
        super(node, parent, pos);
    }

    @Override
    public String getName() {
        return "move-tree";
    }
}
