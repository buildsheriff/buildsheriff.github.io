package com.github.gumtreediff.matchers;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class GumTreeProperties {
    Map<String, Object> properties = new HashMap<>();

    public void put(ConfigurationOptions option, Object value) {
        if (option != null)
            this.properties.put(option.name(), value);
    }

    public Object get(ConfigurationOptions option) {
        if (option != null)
            return this.properties.get(option.name());
        else
            return null;
    }

    private Object setIfNotPresent(String propertyName, Object value) {
        if (!properties.containsKey(propertyName)) {
            properties.put(propertyName, value);
            return value;
        }
        return properties.get(propertyName);
    }

    public String tryConfigure(ConfigurationOptions propertyName, String value) {
        return tryConfigure(propertyName.name(), value);
    }

    private String tryConfigure(String propertyName, String value) {
        Object property = setIfNotPresent(propertyName, value);
        if (property != null)
            return property.toString();

        return value;
    }

    public int tryConfigure(ConfigurationOptions propertyName, int value) {
        return tryConfigure(propertyName.name(), value);
    }

    private int tryConfigure(String propertyName, int value) {
        Object property = setIfNotPresent(propertyName, value);
        if (property != null) {
            try {
                return Integer.parseInt(property.toString());
            }
            catch (Exception e) {
                throw new IllegalArgumentException(e);
            }
        }
        return value;
    }

    public double tryConfigure(ConfigurationOptions propertyName, double value) {
        return tryConfigure(propertyName.name(), value);
    }

    public double tryConfigure(String propertyName, double value) {
        Object property = setIfNotPresent(propertyName, value);
        if (property != null) {
            try {
                return Double.parseDouble(property.toString());
            }
            catch (Exception e) {
                throw new IllegalArgumentException(e);
            }
        }
        return value;
    }

    public String toString() {
        return properties.keySet().stream()
                .map(key -> key + "=" + properties.get(key))
                .collect(Collectors.joining(", ", "{", "}"));
    }
}
