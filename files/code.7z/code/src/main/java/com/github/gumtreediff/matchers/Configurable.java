package com.github.gumtreediff.matchers;

import java.util.Set;

import com.google.common.collect.Sets;

public interface Configurable {
    default void configure(GumTreeProperties properties) {
    }

    default Set<ConfigurationOptions> getApplicableOptions() {
        return Sets.newHashSet();
    }

    default void setOption(ConfigurationOptions option, Object value) {
        if (!getApplicableOptions().contains(option))
            throw new RuntimeException(
                    "Option " + option.name() + " is not allowed. Applicable options are: " + getApplicableOptions());

        GumTreeProperties properties = new GumTreeProperties();
        properties.put(option, value);
        configure(properties);
    }
}
