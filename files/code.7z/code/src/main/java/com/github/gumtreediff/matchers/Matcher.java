package com.github.gumtreediff.matchers;

import org.atteo.classindex.IndexSubclasses;

import com.github.gumtreediff.tree.Tree;

@IndexSubclasses
public interface Matcher extends Configurable {
    MappingStore match(Tree src, Tree dst, MappingStore mappings);

    default MappingStore match(Tree src, Tree dst) {
        return match(src, dst, new MappingStore(src, dst));
    }
}
