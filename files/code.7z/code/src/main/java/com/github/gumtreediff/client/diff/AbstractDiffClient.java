package com.github.gumtreediff.client.diff;

import com.github.gumtreediff.actions.Diff;
import com.github.gumtreediff.client.Option;
import com.github.gumtreediff.client.Client;
import com.github.gumtreediff.gen.TreeGenerators;
import com.github.gumtreediff.matchers.ConfigurationOptions;
import com.github.gumtreediff.matchers.GumTreeProperties;
import com.github.gumtreediff.matchers.Matchers;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public abstract class AbstractDiffClient<O extends AbstractDiffClient.DiffOptions> extends Client {
    protected final O opts;
    public static final String SYNTAX = "Syntax: [options] srcFile dstFile";

    public static class DiffOptions implements Option.Context {
        public String matcherId;
        public String treeGeneratorId;
        public String srcPath;
        public String dstPath;
        public GumTreeProperties properties = new GumTreeProperties();

        @Override
        public Option[] values() {
            return new Option[] {
                    new Option("-m", "Id of the matcher to use.", 1) {
                        @Override
                        protected void process(String name, String[] args) {
                            matcherId = args[0];
                        }
                    },
                    new Option("-g", "Id of the tree generator to use.", 1) {
                        @Override
                        protected void process(String name, String[] args) {
                            treeGeneratorId = args[0];
                        }
                    },
                    new Option("-M", "Add a matcher property (-M property value). Available: "
                            + Arrays.toString(ConfigurationOptions.values()) + ".", 2) {
                        @Override
                        protected void process(String name, String[] args) {
                            properties.put(ConfigurationOptions.valueOf(args[0]), args[1]);
                        }
                    },
                    new Option.Help(this) {
                        @Override
                        public void process(String name, String[] args) {
                            System.out.println(SYNTAX);
                            super.process(name, args);
                        }
                    }
            };
        }

        void dump(PrintStream out) {
            out.printf("Active path: %s\n", System.getProperty("user.dir"));
            out.printf("Diffed paths: %s %s\n", srcPath, dstPath);
            out.printf("Tree generator id: %s\n", treeGeneratorId);
            out.printf("Matcher id: %s\n", matcherId);
            out.printf("Properties: %s\n", properties.toString());
        }
    }

    protected abstract O newOptions();

    public AbstractDiffClient(String[] args) {
        super(args);
        opts = newOptions();
        args = Option.processCommandLine(args, opts);

        if (args.length < 2)
            throw new Option.OptionException("Two arguments are required. " + SYNTAX, opts);

        opts.srcPath = args[0];
        opts.dstPath = args[1];

        if (Option.Verbose.verbose) {
            opts.dump(System.out);
        }

        if (opts.matcherId != null && Matchers.getInstance().findById(opts.matcherId) == null)
            throw new Option.OptionException("Error loading matcher: " + opts.matcherId);

        if (opts.treeGeneratorId != null && TreeGenerators.getInstance().findById(opts.treeGeneratorId) == null)
            throw new Option.OptionException("Error loading tree generator: " + opts.treeGeneratorId);

        if (!Files.exists(Paths.get(opts.srcPath)))
            throw new Option.OptionException("Error loading file or folder: " + opts.srcPath);

        if (!Files.exists(Paths.get(opts.dstPath)))
            throw new Option.OptionException("Error loading file or folder: " + opts.dstPath);
    }

    protected Diff getDiff() throws IOException {
        return getDiff(opts.srcPath, opts.dstPath);
    }

    protected Diff getDiff(String src, String dst) throws IOException {
        return Diff.compute(src, dst, opts.treeGeneratorId, opts.matcherId, opts.properties);
    }
}
