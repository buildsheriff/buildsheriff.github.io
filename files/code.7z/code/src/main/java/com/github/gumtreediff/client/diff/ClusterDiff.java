package com.github.gumtreediff.client.diff;

import com.github.gumtreediff.actions.ActionClusterFinder;
import com.github.gumtreediff.actions.Diff;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.client.Register;

import java.io.IOException;
import java.util.Set;

@Register(name = "cluster", description = "Extract action clusters",
        options = AbstractDiffClient.DiffOptions.class)
public class ClusterDiff extends AbstractDiffClient<AbstractDiffClient.DiffOptions> {

    public ClusterDiff(String[] args) {
        super(args);
    }

    @Override
    public void run() throws IOException {
        Diff diff = getDiff();
        ActionClusterFinder f = new ActionClusterFinder(diff.editScript);
        for (Set<Action> cluster: f.getClusters()) {
            System.out.println("New cluster:");
            System.out.println(f.getClusterLabel(cluster));
            System.out.println("------------");
            for (Action a: cluster)
                System.out.println(a.toString());
            System.out.println();
        }
    }

    @Override
    protected DiffOptions newOptions() {
        return new DiffOptions();
    }
}
