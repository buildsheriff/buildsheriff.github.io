package com.github.gumtreediff.tree;

import com.github.gumtreediff.utils.Pair;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public interface TreeVisitor {
    static void visitTree(Tree root, TreeVisitor visitor) {
        Deque<Pair<Tree, Iterator<Tree>>> stack = new ArrayDeque<>();
        stack.push(new Pair<>(root, root.getChildren().iterator()));
        visitor.startTree(root);
        while (!stack.isEmpty()) {
            Pair<Tree, Iterator<Tree>> it = stack.peek();

            if (!it.second.hasNext()) {
                visitor.endTree(it.first);
                stack.pop();
            } else {
                Tree child = it.second.next();
                stack.push(new Pair<>(child, child.getChildren().iterator()));
                visitor.startTree(child);
            }
        }
    }

    void startTree(Tree tree);

    void endTree(Tree tree);

    class DefaultTreeVisitor implements TreeVisitor {
        @Override
        public void startTree(Tree tree) {

        }

        @Override
        public void endTree(Tree tree) {

        }
    }

    class InnerNodesAndLeavesVisitor implements TreeVisitor {
        @Override
        public final void startTree(Tree tree) {
            if (tree.isLeaf())
                visitLeave(tree);
            else
                startInnerNode(tree);
        }

        public void startInnerNode(Tree tree) {

        }

        public void visitLeave(Tree tree) {
        }

        @Override
        public final void endTree(Tree tree) {
            if (!tree.isLeaf())
                endInnerNode(tree);
        }

        public void endInnerNode(Tree tree) {

        }
    }
}
