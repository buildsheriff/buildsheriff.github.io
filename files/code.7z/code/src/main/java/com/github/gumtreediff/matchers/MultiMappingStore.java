package com.github.gumtreediff.matchers;

import java.util.*;
import java.util.stream.Collectors;

import com.github.gumtreediff.tree.Tree;

public class MultiMappingStore implements Iterable<Mapping> {
    private Map<Tree, Set<Tree>> srcToDsts;
    private Map<Tree, Set<Tree>> dstToSrcs;

    public MultiMappingStore(Set<Mapping> mappings) {
        this();
        for (Mapping m: mappings)
            addMapping(m.first, m.second);
    }

    public MultiMappingStore() {
        srcToDsts = new  HashMap<>();
        dstToSrcs = new HashMap<>();
    }

    public Set<Mapping> getMappings() {
        Set<Mapping> mappings = new HashSet<>();
        for (Tree src : srcToDsts.keySet())
            for (Tree dst: srcToDsts.get(src))
                mappings.add(new Mapping(src, dst));
        return mappings;
    }

    public void addMapping(Tree src, Tree dst) {
        if (!srcToDsts.containsKey(src))
            srcToDsts.put(src, new HashSet<>());
        srcToDsts.get(src).add(dst);
        if (!dstToSrcs.containsKey(dst))
            dstToSrcs.put(dst, new HashSet<>());
        dstToSrcs.get(dst).add(src);
    }

    public void removeMapping(Tree src, Tree dst) {
        srcToDsts.get(src).remove(dst);
        dstToSrcs.get(dst).remove(src);
    }

    public int size() {
        return getMappings().size();
    }

    public Set<Tree> getDsts(Tree src) {
        return srcToDsts.get(src);
    }

    public Set<Tree> getSrcs(Tree dst) {
        return dstToSrcs.get(dst);
    }

    public Set<Tree> allMappedSrcs() {
        return srcToDsts.keySet();
    }

    public Set<Tree> allMappedDsts() {
        return dstToSrcs.keySet();
    }

    public boolean hasSrc(Tree src) {
        return srcToDsts.containsKey(src);
    }

    public boolean hasDst(Tree dst) {
        return dstToSrcs.containsKey(dst);
    }

    public boolean has(Tree src, Tree dst) {
        return srcToDsts.get(src).contains(dst);
    }

    public boolean isSrcUnique(Tree src) {
        return getDsts(src).size() == 1;
    }

    public boolean isDstUnique(Tree dst) {
        return getSrcs(dst).size() == 1;
    }

    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        for (Tree t : srcToDsts.keySet()) {
            String l = srcToDsts.get(t).stream().map(Object::toString).collect(Collectors.joining(", "));
            b.append(String.format("%s -> %s", t.toString(), l)).append('\n');
        }
        return b.toString();
    }

    @Override
    public Iterator<Mapping> iterator() {
        return getMappings().iterator();
    }
}
