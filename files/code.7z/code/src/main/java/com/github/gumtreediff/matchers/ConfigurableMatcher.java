package com.github.gumtreediff.matchers;

public interface ConfigurableMatcher extends Matcher, Configurable {

}
