package com.github.gumtreediff.gen;

import java.io.Reader;

public class SyntaxException extends RuntimeException {

    public SyntaxException(TreeGenerator g, Reader r) {
        super(String.format("Syntax error on source code %s using generator %s", r, g));
    }

    public SyntaxException(String message, Throwable cause) {
        super(message, cause);
    }

}
