package com.github.gumtreediff.actions;

import com.github.gumtreediff.matchers.MappingStore;

public interface EditScriptGenerator {
    EditScript computeActions(MappingStore mappings);
}
