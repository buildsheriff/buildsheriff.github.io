package com.github.gumtreediff.matchers.heuristic.gt;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.github.gumtreediff.matchers.Mapping;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.Tree;

public abstract class AbstractMappingComparator implements Comparator<Mapping> {
    protected List<Mapping> ambiguousMappings;

    protected Map<Mapping, Double> similarities = new HashMap<>();

    protected int maxTreeSize;

    protected MappingStore mappings;

    public AbstractMappingComparator(List<Mapping> ambiguousMappings, MappingStore mappings, int maxTreeSize) {
        this.maxTreeSize = maxTreeSize;
        this.mappings = mappings;
        this.ambiguousMappings = ambiguousMappings;
    }

    @Override
    public int compare(Mapping m1, Mapping m2) {
        if (similarities.get(m2).compareTo(similarities.get(m1)) != 0) {
            return Double.compare(similarities.get(m2), similarities.get(m1));
        }
        int srcPos = m1.first.getMetrics().position;
        int dstPos = m2.first.getMetrics().position;
        if (srcPos != dstPos) {
            return Integer.compare(srcPos, dstPos);
        }
        return Integer.compare(m1.second.getMetrics().position, m2.second.getMetrics().position);
    }

    protected abstract double similarity(Tree src, Tree dst);

    protected double posInParentSimilarity(Tree src, Tree dst) {
        int posSrc = (src.isRoot()) ? 0 : src.getParent().getChildPosition(src);
        int posDst = (dst.isRoot()) ? 0 : dst.getParent().getChildPosition(dst);
        int maxSrcPos = (src.isRoot()) ? 1 : src.getParent().getChildren().size();
        int maxDstPos = (dst.isRoot()) ? 1 : dst.getParent().getChildren().size();
        int maxPosDiff = Math.max(maxSrcPos, maxDstPos);
        return 1D - ((double) Math.abs(posSrc - posDst) / (double) maxPosDiff);
    }

    protected double numberingSimilarity(Tree src, Tree dst) {
        return 1D - ((double) Math.abs(src.getMetrics().position - dst.getMetrics().position) / (double) maxTreeSize);
    }

}
