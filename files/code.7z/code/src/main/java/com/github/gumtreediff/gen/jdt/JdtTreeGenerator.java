package com.github.gumtreediff.gen.jdt;


import com.github.gumtreediff.gen.Register;
import com.github.gumtreediff.gen.Registry;
import org.eclipse.jdt.core.compiler.IScanner;

@Register(id = "java-jdt", accept = "\\.java$", priority = Registry.Priority.MAXIMUM)
public class JdtTreeGenerator extends AbstractJdtTreeGenerator {

    @Override
    protected AbstractJdtVisitor createVisitor(IScanner scanner) {
        return new JdtVisitor(scanner);
    }

}
