package com.github.gumtreediff.matchers.heuristic.gt;

import java.util.List;
import java.util.stream.Collectors;

import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.SimilarityMetrics;
import com.github.gumtreediff.tree.Tree;

public class CompleteBottomUpMatcher extends AbstractBottomUpMatcher implements Matcher {
    @Override
    public MappingStore match(Tree src, Tree dst, MappingStore mappings) {
        for (Tree t : src.postOrder()) {
            if (t.isRoot()) {
                mappings.addMapping(t, dst);
                lastChanceMatch(mappings, t, dst);
                break;
            } else if (!(mappings.isSrcMapped(t) || t.isLeaf())) {
                List<Tree> srcCandidates = t.getParents().stream().filter(p -> p.getType() == t.getType())
                        .collect(Collectors.toList());

                List<Tree> dstCandidates = getDstCandidates(mappings, t);
                Tree srcBest = null;
                Tree dstBest = null;
                double max = -1D;
                for (Tree srcCand : srcCandidates) {
                    for (Tree dstCand : dstCandidates) {

                        double sim = SimilarityMetrics.jaccardSimilarity(srcCand, dstCand, mappings);
                        if (sim > max && sim >= simThreshold) {
                            max = sim;
                            srcBest = srcCand;
                            dstBest = dstCand;
                        }
                    }
                }

                if (srcBest != null) {
                    lastChanceMatch(mappings, srcBest, dstBest);
                    mappings.addMapping(srcBest, dstBest);
                }
            }
        }
        return mappings;
    }
}
