package com.github.gumtreediff.actions;

import com.github.gumtreediff.tree.Tree;

import java.util.Set;

public interface TreeClassifier {
    Set<Tree> getUpdatedSrcs();

    Set<Tree> getDeletedSrcs();

    Set<Tree> getMovedSrcs();

    Set<Tree> getUpdatedDsts();

    Set<Tree> getInsertedDsts();

    Set<Tree> getMovedDsts();
}
