package fdse.testcaseshow.cluster;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import fdse.testcaseshow.model.Sim;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class StoreSim {
    private BlockingQueue<STSimilarity.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<Sim> outQueue = new ArrayBlockingQueue<>(200);
    private static final int THREAD_NUMBER = 20;

    private void putCoefficient(STSimilarity.Coefficient coefficient) {
        try {
            this.inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void clear() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            session.createQuery("delete Sim ").executeUpdate();

            tx.commit();
        }
    }

    private void initializeThreads(List<Thread> threads, Thread thread, List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new SlaveTask(testCases, inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    public void STSim() {
        clear();
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : testCases) {
            Collection<TestItem> testItems = testCase.getTestItems();
            for (TestItem testItem : testItems) {
                testItem.getTestFrames().size();
            }
        }
        session.close();
        Thread collectThread = new Thread(new CollectTask(outQueue));
        List<Thread> threads = new ArrayList<>();
        initializeThreads(threads, collectThread, testCases);
        for (double c = 0.1; c <= 2.0; c += 0.1) {
            for (int maxDistance = 6; maxDistance < 10; maxDistance += 1) {
                STSimilarity.Coefficient coefficient = new STSimilarity.Coefficient(0.0, c, maxDistance);
                System.out.println(coefficient);
                putCoefficient(coefficient);
            }
        }

        for (int i = 0; i < THREAD_NUMBER; i++) {
            STSimilarity.Coefficient coefficient = new STSimilarity.Coefficient();
            coefficient.setMaxDistance(-1);
            putCoefficient(coefficient);
        }

        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        Sim endSim = new Sim();
        endSim.setType(-1);
        try {
            this.outQueue.put(endSim);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public void ExSim() {
        Thread collectThread = new Thread(new CollectTask(outQueue));
        collectThread.start();
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        ExceptionSimilarity exceptionSimilarity = new ExceptionSimilarity(null, 0.0);
        for (TestCase testCase : testCases) {
            Table<Long, Long, Double> simTable = HashBasedTable.create();
            List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
            for (TestItem testItemA : selectedTestItems) {
                for (TestItem testItemB : selectedTestItems) {
                    if (testItemA.getId() != testItemB.getId() && simTable.get(testItemA.getId(), testItemB.getId()) == null) {
                        double sim = exceptionSimilarity.getSim(testItemA, testItemB);
                        simTable.put(testItemA.getId(), testItemB.getId(), sim);
                        simTable.put(testItemB.getId(), testItemA.getId(), sim);
                    }
                }
            }
            for (Table.Cell<Long, Long, Double> cell : simTable.cellSet()) {
                Sim sim = new Sim();
                sim.setTestCase(testCase);
                sim.setType(Type.ExceptionSimilarity.getValue());
                sim.setTestItemAID(cell.getRowKey());
                sim.setTestItemBID(cell.getColumnKey());
                sim.setSim(cell.getValue());
                try {
                    this.outQueue.put(sim);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        session.close();
        Sim endSim = new Sim();
        endSim.setType(-1);
        try {
            this.outQueue.put(endSim);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public enum Type {
        STSimilarity(0), ExceptionSimilarity(1);
        private int value;
        private Type(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public static void main(String[] args) {
        new StoreSim().ExSim();
    }
}

class SlaveTask implements Runnable {
    private BlockingQueue<STSimilarity.Coefficient> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<Sim> outQueue;
    public SlaveTask(List<TestCase> testCases, BlockingQueue<STSimilarity.Coefficient> inQueue, BlockingQueue<Sim> outQueue) {
        this.inQueue = inQueue;
        this.testCases = testCases;
        this.outQueue = outQueue;
    }

    public STSimilarity.Coefficient getCoefficient() {
        STSimilarity.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    private void putSim(Sim sim) {
        try {
            outQueue.put(sim);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static List<Sim> putSimList(Table<Long, Long, Double> simTable, TestCase testCase, double c, int maxDistance) {
        List<Sim> list = new ArrayList<>();
        for (Table.Cell<Long, Long, Double> cell : simTable.cellSet()) {
            Sim sim = new Sim();
            sim.setTestCase(testCase);
            sim.setType(StoreSim.Type.STSimilarity.getValue());
            sim.setTestItemAID(cell.getRowKey());
            sim.setTestItemBID(cell.getColumnKey());
            sim.setC(String.format("%.2f", c));
            sim.setMaxDistance(maxDistance);
            sim.setSim(cell.getValue());
            list.add(sim);
        }
        return list;
    }

    public void STSimLoop(double c, int maxDistance, List<TestCase> testCases) {
        STSimilarity stSimilarity = new STSimilarity(null, 0.0, c, maxDistance);
        for (TestCase testCase : testCases) {
            Table<Long, Long, Double> simTable = HashBasedTable.create();
            List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
            for (TestItem testItemA : selectedTestItems) {
                for (TestItem testItemB : selectedTestItems) {
                    if (testItemA.getId() != testItemB.getId() && simTable.get(testItemA.getId(), testItemB.getId()) == null) {
                        double sim = stSimilarity.getSim(testItemA, testItemB);
                        simTable.put(testItemA.getId(), testItemB.getId(), sim);
                        simTable.put(testItemB.getId(), testItemA.getId(), sim);
                    }
                }
            }
            List<Sim> list = putSimList(simTable, testCase, c, maxDistance);
            list.forEach(sim -> {putSim(sim);});
        }
    }

    @Override
    public void run() {
        while (true) {
            STSimilarity.Coefficient coefficient = getCoefficient();
            if (coefficient.getMaxDistance() <= -1) {
                break;
            }

            STSimLoop(coefficient.getC(), coefficient.getMaxDistance(), this.testCases);
        }

    }
}

class CollectTask implements Runnable {
    private BlockingQueue<Sim> outQueue;

    public CollectTask(BlockingQueue<Sim> outQueue) {
        this.outQueue = outQueue;
    }

    private Sim takeSim() {
        Sim sim = null;
        try {
            sim = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return sim;
    }

    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        Sim sim = null;
        Object o = session.createQuery("select max(f.id) from Sim f").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            sim = takeSim();
            if (sim.getType() == -1)
                break;
            id++;
            sim.setId(id);
            session.save(sim);
            i++;
            if (i % 1000 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}