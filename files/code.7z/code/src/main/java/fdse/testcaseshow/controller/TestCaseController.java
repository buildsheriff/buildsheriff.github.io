package fdse.testcaseshow.controller;

import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestCaseRepository;
import fdse.testcaseshow.code.PathProcess;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@RestController
@RequestMapping(path="/testCases")
@CrossOrigin(origins="*")
public class TestCaseController {
    private final Path rootLocation = Paths.get(System.getProperty("user.dir"), "resources", "figure");

    private TestCaseRepository testCaseRepository;

    @Autowired
    public TestCaseController(TestCaseRepository testCaseRepository) {
        this.testCaseRepository = testCaseRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TestCase postTestCase(@RequestParam(value = "files", required = false) List<MultipartFile> files,
                                 @RequestParam(value = "repoName", required = false) String repoName,
                                 @RequestParam(value = "jobNumber", required = false) String jobNumber,
                                 @RequestParam(value = "description", required = false) String description,
                                 @RequestParam(value = "includeException", required = false) Boolean includeException,
                                 @RequestParam(value = "includeAssertion", required = false) Boolean includeAssertion,
                                 @RequestParam(value = "causeUrl", required = false) String causeUrl,
                                 @RequestParam(value = "preCommit", required = false) String preCommit,
                                 @RequestParam(value = "currentCommit", required = false) String currentCommit,
                                 @RequestParam(value = "fixUrls", required = false) String fixUrls,
                                 @RequestParam(value = "multipleCrash", required = false) Boolean multipleCrash,
                                 @RequestParam(value = "crashClusterNum", required = false) int crashClusterNum,
                                 @RequestParam(value = "multipleAssertion", required = false) Boolean multipleAssertion,
                                 @RequestParam(value = "assertionClusterNum", required = false) int assertionClusterNum,
                                 @RequestParam(value = "multipleError", required = false) Boolean multipleError,
                                 @RequestParam(value = "clusterNum", required = false) int clusterNum) {

        TestCase testCase = new TestCase();
        testCase.setRepoName(repoName);
        testCase.setJobNumber(jobNumber);
        testCase.setDescription(description);
        testCase.setIncludeAssertion(includeAssertion);
        testCase.setIncludeException(includeException);
        testCase.setCauseUrl(causeUrl);
        testCase.setPreCommit(preCommit);
        testCase.setCurrentCommit(currentCommit);
        testCase.setMultipleCrash(multipleCrash);
        testCase.setCrashClusterNum(crashClusterNum);
        testCase.setMultipleAssertion(multipleAssertion);
        testCase.setAssertionClusterNum(assertionClusterNum);
        testCase.setMultipleError(multipleError);
        testCase.setClusterNum(clusterNum);

        try {
            Files.createDirectories(rootLocation);

            System.out.println("根路径为" + rootLocation);
            files.forEach(f -> {
                System.out.println(f.getOriginalFilename());
                String fileName = f.getOriginalFilename();
                Path target = this.rootLocation.resolve(fileName);
                testCase.getFigs().add(fileName);
                System.out.println(target.toString());
                try {
                    if (target.toFile().exists() == false)
                        Files.copy(f.getInputStream(), target);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        testCaseRepository.save(testCase);
        return null;
    }

    @GetMapping
    public Iterable<TestCase> getTestCases() {
        return testCaseRepository.findAll();
    }


    @GetMapping(value = "/figs/{fileName}", produces = MediaType.IMAGE_JPEG_VALUE)
    public Resource getFigs(@PathVariable("fileName") String fileName) {
        System.out.println(fileName);
        Path filePath = rootLocation.resolve(fileName);
        Resource resource = null;
        try {
            resource = new UrlResource(filePath.toUri());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        if (resource.exists() || resource.isReadable()) {
            return resource;
        }
        return null;
    }

    @PatchMapping(path = "/{orderId}")
    @ResponseStatus(HttpStatus.OK)
    public TestCase patchTestCase(@PathVariable("orderId") Long id,
                                  @RequestParam(value = "files", required = false) List<MultipartFile> files,
                                  @RequestParam(value = "repoName", required = false) String repoName,
                                  @RequestParam(value = "jobNumber", required = false) String jobNumber,
                                  @RequestParam(value = "description", required = false) String description,
                                  @RequestParam(value = "includeException", required = false) Boolean includeException,
                                  @RequestParam(value = "includeAssertion", required = false) Boolean includeAssertion,
                                  @RequestParam(value = "causeUrl", required = false) String causeUrl,
                                  @RequestParam(value = "preCommit", required = false) String preCommit,
                                  @RequestParam(value = "currentCommit", required = false) String currentCommit,
                                  @RequestParam(value = "fixUrls", required = false) String fixUrls,
                                  @RequestParam(value = "multipleCrash", required = false) Boolean multipleCrash,
                                  @RequestParam(value = "crashClusterNum", required = false) Integer crashClusterNum,
                                  @RequestParam(value = "multipleAssertion", required = false) Boolean multipleAssertion,
                                  @RequestParam(value = "assertionClusterNum", required = false) Integer assertionClusterNum,
                                  @RequestParam(value = "multipleError", required = false) Boolean multipleError,
                                  @RequestParam(value = "clusterNum", required = false) Integer clusterNum
    ) {
        TestCase testCase = testCaseRepository.findById(id).get();
        if (repoName != null) {
            testCase.setRepoName(repoName);
        }
        if (jobNumber != null) {
            testCase.setJobNumber(jobNumber);
        }
        if (description != null) {
            testCase.setDescription(description);
        }
        if (includeException != null) {
            testCase.setIncludeException(includeException);
        }
        if (includeAssertion != null) {
            testCase.setIncludeAssertion(includeAssertion);
        }
        if (causeUrl != null) {
            testCase.setCauseUrl(causeUrl);
        }
        if (preCommit != null) {
            testCase.setPreCommit(preCommit);
        }
        if (currentCommit != null) {
            testCase.setCurrentCommit(currentCommit);
        }
        if (multipleCrash != null) {
            testCase.setMultipleCrash(multipleCrash);
        }
        if (crashClusterNum != null) {
            testCase.setCrashClusterNum(crashClusterNum);
        }
        if (multipleAssertion != null) {
            testCase.setMultipleAssertion(multipleAssertion);
        }
        if (assertionClusterNum != null) {
            testCase.setAssertionClusterNum(assertionClusterNum);
        }
        if (multipleError != null) {
            testCase.setMultipleError(multipleError);
        }
        if (clusterNum != null) {
            testCase.setClusterNum(clusterNum);
        }
        if (files != null) {
            files.forEach(f -> {
                System.out.println(f.getOriginalFilename());
                String fileName = f.getOriginalFilename();
                Path target = this.rootLocation.resolve(fileName);
                testCase.getFigs().add(fileName);
                System.out.println(target.toString());
                try {
                    if (target.toFile().exists() == false)
                        Files.copy(f.getInputStream(), target);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
        return testCaseRepository.save(testCase);
    }

    @DeleteMapping
    public boolean deletePicture(@RequestParam(value = "id") long id,
                                 @RequestParam(value = "filepath") String filepath) {

        String path = PathProcess.pathProcessing(filepath);
        System.out.println("FILEPath::::"+filepath);
        System.out.println("Path::::"+path);

        TestCase testCase = testCaseRepository.findById(id).get();
        Path target = this.rootLocation.resolve(path);
        System.out.println("target::::"+target);
        try{
            if(Files.deleteIfExists(target)){
                System.out.println("！");

                List<String> lt = testCase.getFigs();
                System.out.println(lt);

                Iterator<String> iterator = lt.iterator();
                while (iterator.hasNext()) {
                    String s = iterator.next();
                    if("".equals(s)){
                        iterator.remove();
                    }
                    if (path.equals(s)) {
                        System.out.println("\n："+path);
                        iterator.remove();
                    }
                }
                testCase.setFigs(lt);
                testCaseRepository.save(testCase);
                return true;
            }
            return false;
        }
        catch (Exception e){
            System.out.println("删除图片错误，异常："+e);
            return false;
        }
    }


    @PatchMapping(path = "/changeName/{orderId}")
    @ResponseStatus(HttpStatus.OK)
    public boolean changefilename(@PathVariable(value = "orderId") long id,
                                  @RequestParam(value = "newfigname") String newfigname,
                                  @RequestParam(value = "figpath") String figpath){

        TestCase testCase = testCaseRepository.findById(id).get();

        System.out.println("figgggggpath::::::::"+figpath);
        String path = PathProcess.pathProcessing(figpath);

        List<String> lt = testCase.getFigs();
        Iterator<String> iterator = lt.iterator();

        Path target = this.rootLocation.resolve(path);
        newfigname = newfigname+".png";

        try{
            Files.move(target, target.resolveSibling(newfigname));
            //开始修改数据库
            boolean flag = false;
            while (iterator.hasNext()) {
                String s = iterator.next();
                if("".equals(s)){
                    iterator.remove();
                }
                if (path.equals(s)) {
                    System.out.println("\n："+path);
                    iterator.remove();
                    flag = true;//
                }
            }
            if(flag){
                lt.add(newfigname);
                testCase.setFigs(lt);
                testCaseRepository.save(testCase);
                return true;//
            }
            else{
                return false;
            }
        }
        catch (Exception e){
            System.out.println("："+e);
            return false;
        }
    }
}
