package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.*;

public class CrossValidation {
    public void exception() {
        List<TestCase> testCases = null;
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false ", TestCase.class);
            testCases = query.list();
        }
        List<Long> ids = getIds(testCases);
        List<Long> trainIds = getTrainingIds(testCases, 2, 80, 20);
        List<Long> testIds = getTestIds(ids, trainIds);
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false ", TestCase.class);
            testCases = query.list();
        }
    }
    public void assertion() {

    }

    public ResultSummary testSTSimilarity() {
        return null;
    }

    public List<ResultSummary> tuningSTSimilarity(List<Long> trainIds) {
        STSimilarityMaster similarityMaster = new STSimilarityMaster();
        similarityMaster.tuning(trainIds);
        System.out.println(similarityMaster.getResultSummaryList().size());
        return similarityMaster.getResultSummaryList();
    }

    public List<Long> getIds(List<TestCase> testCases) {
        List<Long> ids = new ArrayList<>();
        for (TestCase testCase : testCases) {
            ids.add(testCase.getId());
        }
        return ids;
    }

    public List<Long> getTestIds(List<Long> ids, List<Long> trainIds) {
        List<Long> testIds = new ArrayList<>();
        for (Long id : ids) {
            if (trainIds.contains(id) == false) {
                testIds.add(id);
            }
        }
        return testIds;
    }

    public List<Long> getTrainingIds(List<TestCase> testCases, int k, int oneNumber, int moreNumber) {
        int oneBound = oneNumber * k / 10;
        int moreBound = moreNumber * k / 10;
        List<Long> oneIds = new LinkedList<>();
        List<Long> moreIds = new LinkedList<>();
        for (TestCase testCase : testCases) {
            if (testCase.getCrashClusterNum() == 1) {
                oneIds.add(testCase.getId());
            } else {
                moreIds.add(testCase.getId());
            }
        }
        List<Long> ids = new ArrayList<>();
        Random r = new Random();
        for (int i = 0; i < oneBound; i++) {
            int ri = r.nextInt(oneIds.size());
            ids.add(oneIds.remove(i));
        }
        for (int i = 0; i < moreBound; i++) {
            int ri = r.nextInt(moreIds.size());
            ids.add(moreIds.remove(i));
        }
        return ids;

    }
    public static void main(String[] args) {
        new CrossValidation().exception();
    }

}
