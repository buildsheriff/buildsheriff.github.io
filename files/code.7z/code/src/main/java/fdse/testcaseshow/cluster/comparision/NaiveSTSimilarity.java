package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.AHCluster;
import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.NaiveSTSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.log.STLength;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.FileUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class NaiveSTSimilarity extends AHCluster {
    private double c;

    public NaiveSTSimilarity(List<DataPoint> dataPoints, double sMax) {
        super(dataPoints, sMax);
    }

    public List<String> getFrames(String stackTrace) {
        List<String> list = new ArrayList<>();
        String[] array = stackTrace.split("\n");
        for (String line : array) {
            String s = line.trim();
            if (s.startsWith("at") && STLength.frameValidity(s) ) {
                list.add(s);
            }
        }
        return list;
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {
        Collection<String> framesA = getFrames(tiA.getStackTrace());
        Collection<String> framesB = getFrames(tiB.getStackTrace());
        if (framesA.size() == 0 || framesB.size() == 0) {
            return 0.0;
        }
        Collection<String> intersection = FileUtil.intersection(framesA, framesB);

        return 2.0 * intersection.size() / (framesA.size() + framesB.size());
    }

    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }


    public static List<Cluster> clusterBuild(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new NaiveSTSimilarity(dataPoints, sMax).startCluster();
    }

    public static List<Cluster> clusterBuild(double sMax, TestCase testCase) {
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        return clusterBuild(sMax, selectedTestItems);
    }

    public static void main(String[] args) throws FileNotFoundException {
        try (Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id <= 307 and multipleCrash = true and crashIgnore = false", TestCase.class);
            List<TestCase> testCases = query.list();
            StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.NAIVESTSIMILARITY, true, null);
            for (double sMax = 0.51; sMax < 1.0001; sMax += 0.01) {
                System.out.println(sMax);
                ResultSummary resultSummary = new NaiveSTSimilarityResultSummary(sMax);
                for (TestCase testCase : testCases) {
                    List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                    List<Cluster> clusters = NaiveSTSimilarity.clusterBuild(sMax, selectedTestItems);
                    resultSummary.addSingleResult(testCase, clusters, true);
                }
                storeResultSummary.write(resultSummary);
            }
            storeResultSummary.close();
        }

    }
}
