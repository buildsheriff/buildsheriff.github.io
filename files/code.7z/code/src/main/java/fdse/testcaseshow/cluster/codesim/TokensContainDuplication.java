package fdse.testcaseshow.cluster.codesim;

import java.util.Collection;

public class TokensContainDuplication implements ITokensDuplication {
    private volatile static TokensContainDuplication tokensContainDuplication;
    private TokensContainDuplication() { }

    public static TokensContainDuplication getInstance() {
        if (tokensContainDuplication == null) {
            synchronized (TokensContainDuplication.class) {
                if (tokensContainDuplication == null) {
                    tokensContainDuplication = new TokensContainDuplication();
                }
            }
        }
        return tokensContainDuplication;
    }

    @Override
    public Collection<String> processTokens(Collection<String> collection) {
        return collection;
    }
}
