package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.cluster.*;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.evaluation.CombineRatioResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class CombineRatioSlave implements Runnable {
    private BlockingQueue<CombineMethod.Coefficient> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<ResultSummary> outQueue;
    private CombineRatioMaster.CombineMark combineMark;
    public CombineRatioSlave(List<TestCase> testCases, BlockingQueue<CombineMethod.Coefficient> inQueue, BlockingQueue<ResultSummary> outQueue, CombineRatioMaster.CombineMark combineMark) {
        this.inQueue = inQueue;
        this.testCases = testCases;
        this.outQueue = outQueue;
        this.combineMark = combineMark;
    }

    public CombineMethod.Coefficient getCoefficient() {
        CombineMethod.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true) {
            CombineMethod.Coefficient coefficient = getCoefficient();
            if (coefficient.getCoefficientA() == null && coefficient.getCoefficientB() == null) {
                break;
            }
            ResultSummary resultSummary = new CombineRatioResultSummary(coefficient);
            for (TestCase testCase : testCases) {
                if (combineMark == CombineRatioMaster.CombineMark.STSimilarity_Exception) {
                    List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                    List<Cluster> clusters = CombineMethod.clusterBuildOfSTAndEx(selectedTestItems, (STSimilarity.Coefficient) coefficient.getCoefficientA(), coefficient.getRatio(), coefficient.getSMax());
                    resultSummary.addSingleResult(testCase, clusters, true);
                } else if (combineMark == CombineRatioMaster.CombineMark.CodeSimilarity_Assertion) {
                    List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
                    List<Cluster> clusters = CombineMethod.clusterBuildOfCodeAndAssertion(selectedTestItems, testCase, (CodeSimilarity.Coefficient) coefficient.getCoefficientA(), coefficient.getRatio(), coefficient.getSMax());
                    resultSummary.addSingleResult(testCase, clusters, false);
                }
            }
            putResult(resultSummary);

        }

    }
}
