package fdse.testcaseshow.log;

import fdse.testcaseshow.model.ChangedFile;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.Collection;
import java.util.List;

public class STLength {

    public static boolean frameValidity(String s) {
        boolean flag = false;
        return flag;
    }

    public static int getDelLength(TestItem testItem) {
        if (testItem.getStackTrace() == null)
            return 0;
        String[] lines = testItem.getStackTrace().split("\\n");
        int count = 0;
        for (String line : lines) {
            String s = line.trim();
            if (frameValidity(s)) {
                count++;
            }
        }
        return count;
    }
    public static void setDelLength() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            Query<TestItem> query = session.createQuery("from TestItem", TestItem.class);
            List<TestItem> testItems = query.list();
            for (TestItem testItem : testItems) {
                System.out.println(testItem.getId());
                int count = 0;
                if (testItem.getStackTrace() == null) {
                    count = Integer.MIN_VALUE;
                } else {
                    String[] lines = testItem.getStackTrace().split("\\n");
                    for (String line : lines) {
                        String s = line.trim();
                        if (frameValidity(s)) {
                            System.out.println(s);
                            count++;
                        }
                    }
                }
                testItem.setDelLength(count);
            }
            tx.commit();
        }
    }

    public static void setLength() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx =session.beginTransaction();
            Query<TestItem> query = session.createQuery("from TestItem", TestItem.class);
            List<TestItem> testItems = query.list();
            for (TestItem testItem : testItems) {
                int count = 0;
                if (testItem.getStackTrace() == null)
                    continue;
                String[] lines = testItem.getStackTrace().split("\\n");
                for (String line : lines) {
                    String s = line.trim();
                    if (s.startsWith("at")) {
                        count++;
                    }
                }
                testItem.setLength(count);
            }
            tx.commit();
        }
    }

    public static int getTestCaseLength(TestCase testCase) {
        int max_length = 0;
        Collection<TestItem> testItems = testCase.getTestItems();
        for (TestItem testItem : testItems) {
            if (testItem.isCrash() && testItem.getDelLength() > max_length) {
                max_length = testItem.getDelLength();
            }
        }

        if (testCase.getLength() != null) {
            if (testCase.getLength() != max_length) {
                System.out.println(testCase.getId() + "->" + testCase.getLength() + "->" + max_length);
            }
        }
        return max_length;
    }

    public static void setTestCaseLength() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx =session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id > 0 ", TestCase.class);
            List<TestCase> testCases = query.list();
            for (TestCase testCase : testCases) {
                int max_length = getTestCaseLength(testCase);
                testCase.setLength(max_length);
            }
            tx.commit();
        }
    }

    public static void setChangeConfigFile() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx =session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id > 0", TestCase.class);
            List<TestCase> testCases = query.list();
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                Collection<ChangedFile> changedFiles = testCase.getChangedFiles();
                for (ChangedFile changedFile : changedFiles) {
                    String filePath = changedFile.getCurrentFilePath();
                    if (filePath.contains("pom.xml") || filePath.contains("travis.yml") || filePath.contains(".html")) {
                        testCase.setConfigChanged(true);
                        break;
                    }
                }
            }
            tx.commit();
        }
    }

    public static int getAssertionTestItemLength(TestItem testItem) {
        if (testItem.getStackTrace() == null)
            return 0;
        String[] lines = testItem.getStackTrace().split("\\n");
        int count = 0;
        for (String line : lines) {
            String s = line.trim();
            if (s.startsWith("at")) {
                count++;
            }
        }
        return count;
    }
    public static int getAssertionTestCaseLength(TestCase testCase) {
        int max_length = 0;
        Collection<TestItem> testItems = testCase.getTestItems();
        for (TestItem testItem : testItems) {
            if (testItem.isCrash() == false) {
                int tmpLength = getAssertionTestItemLength(testItem);
                if (tmpLength > max_length)
                    max_length = tmpLength;
            }
        }

        System.out.println(testCase.getId() + "->" + max_length);

        return max_length;
    }
    public static void setAssertionLength() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx =session.beginTransaction();
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            for (TestCase testCase : testCases) {
                int max_length = getAssertionTestCaseLength(testCase);
                testCase.setAssertionLength(max_length);
            }
            tx.commit();
        }
    }

    public static void main(String[] args) {
        //setLength();
        //setDelLength();
        //setTestCaseLength();
        setAssertionLength();
    }
}

