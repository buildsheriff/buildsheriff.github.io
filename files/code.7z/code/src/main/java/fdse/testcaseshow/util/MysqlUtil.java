package fdse.testcaseshow.util;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class MysqlUtil {
    public static List<TestCase> getCrashTestCases(Session session) {
        Query<TestCase> crashQuery = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false", TestCase.class);
        List<TestCase> crashTestCases = crashQuery.list();
        return crashTestCases;
    }

    public static List<TestCase> getCrashTestCases() {
        try (Session session = SessionUtil.getSession()) {
            return getCrashTestCases(session);
        }
    }

    public static List<TestCase> getAssertionTestCases(Session session) {
        Query<TestCase> crashQuery = session.createQuery("from TestCase where multipleAssertion = true and assertionIgnore = false", TestCase.class);
        List<TestCase> assertionTestCases = crashQuery.list();
        return assertionTestCases;
    }

    public static List<TestCase> getAssertionTestCases() {
        try (Session session = SessionUtil.getSession()) {
            return getAssertionTestCases(session);
        }
    }

    public static List<TestCase> getTestCases() {
        List<TestCase> list = null;
        try(Session session = SessionUtil.getSession()) {
            list = getTestCases(session);
        }
        return list;
    }

    public static List<TestCase> getTestCases(Session session) {
        List<TestCase> list = null;
        list = session.createQuery("from TestCase", TestCase.class).list();
        return list;
    }

    public static TestCase getTestCaseById(int id) {
        TestCase testCase = null;
        try(Session session = SessionUtil.getSession()) {
            testCase = getTestCaseById(session, id);
        }
        return testCase;
    }

    public static TestCase getTestCaseById(Session session, long id) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase t where t.id=:id",
                TestCase.class);
        query.setParameter("id", id);
        testCase = query.uniqueResult();
        return testCase;
    }

    public static TestItem getTestItemById(int id) {
        TestItem testItem = null;
        try(Session session = SessionUtil.getSession()) {
            testItem = getTestItemById(session, id);
        }
        return testItem;
    }

    public static TestItem getTestItemById(Session session, long id) {
        TestItem testItem = null;
        Query<TestItem> query = session.createQuery("from TestItem t where t.id=:id",
                TestItem.class);
        query.setParameter("id", id);
        testItem = query.uniqueResult();
        return testItem;
    }

    public static JavaFile getJavaFileById(long id) {
        JavaFile javaFile = null;
        try(Session session = SessionUtil.getSession()) {
            javaFile = getJavaFileById(session, id);
        }
        return javaFile;
    }

    public static JavaFile getJavaFileById(Session session, long id) {
        JavaFile javaFile = null;
        Query<JavaFile> query = session.createQuery("from JavaFile t where t.id=:id",
                JavaFile.class);
        query.setParameter("id", id);
        javaFile = query.uniqueResult();
        return javaFile;
    }

}
