package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.cluster.*;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.codesim.CodeSimilarityByToken;
import fdse.testcaseshow.cluster.codesim.TokensContainDuplication;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

public class CombineMethod extends AHCluster {
    private double ratio;
    private SimInterface similarityA;
    private SimInterface similarityB;
    public CombineMethod(List<DataPoint> dataPoints, SimInterface similarityA, SimInterface similarityB, double ratio, double sMax) {
        super(dataPoints, sMax);
        this.ratio = ratio;
        this.similarityA = similarityA;
        this.similarityB = similarityB;
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {
        double simA = similarityA.getSim(testItem1, testItem2);
        double simB = similarityB.getSim(testItem1, testItem2);
        return this.ratio * simA + (1 - this.ratio) * simB;
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(List<TestItem> testItems, STSimilarity stSimilarity, ExceptionSimilarity exceptionSimilarity, double ratio, double sMax) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new CombineMethod(dataPoints, stSimilarity, exceptionSimilarity, ratio, sMax).startCluster();
    }

    public static List<Cluster> clusterBuildOfSTAndEx(List<TestItem> testItems, STSimilarity.Coefficient stCoefficient, double ratio, double sMax) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        STSimilarity stSimilarity = new STSimilarity(null, 0.0, stCoefficient.getC(), stCoefficient.getMaxDistance());
        ExceptionSimilarity exceptionSimilarity = new ExceptionSimilarity(null, 0.0);
        return new CombineMethod(dataPoints, stSimilarity, exceptionSimilarity, ratio, sMax).startCluster();
    }

    public static List<Cluster> clusterBuildOfCodeAndAssertion(List<TestItem> testItems, TestCase testCase, CodeSimilarity.Coefficient codeCoefficient, double ratio, double sMax) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(testItems, testCase.getJavaFileTokens(), codeCoefficient, TokensContainDuplication.getInstance());
        AssertionMessage assertionMessage = new AssertionMessage(null, 0.0);
        return new CombineMethod(dataPoints, codeSimilarity, assertionMessage, ratio, sMax).startCluster();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private CoefficientInterface coefficientA;
        private CoefficientInterface coefficientB;
        private double ratio;
        private double sMax;
    }
}
