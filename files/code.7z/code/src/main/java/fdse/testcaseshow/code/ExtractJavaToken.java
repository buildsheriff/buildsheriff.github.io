package fdse.testcaseshow.code;

import fdse.testcaseshow.model.ChangedToken;
import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.FileUtil;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ExtractJavaToken {

    private BlockingQueue<JavaFile> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<JavaFileToken> outQueue = new ArrayBlockingQueue<>(20);

    private static final int THREAD_NUMBER = 20;
    private List<Thread> calculationThreads = new ArrayList<>();
    private Thread storeThread = null;
    public static Path getAbsoluteFilePath(String filePath) {
        return FileUtil.codeDirectoryPath.resolve(filePath);
    }

    private void clear() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete JavaFileToken";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            tx.commit();
        }
    }

    private void putJavaFile(JavaFile javaFile) {
        try {
            inQueue.put(javaFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void initThreads() {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new ExtractJavaTokenTask(inQueue, outQueue));
            calculationThreads.add(tmpThread);
            tmpThread.start();
        }
        storeThread = new Thread(new StoreJavaTokenTask(outQueue));
        storeThread.start();
    }

    private void terminateThreads() {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            JavaFile javaFile = new JavaFile();
            javaFile.setId(-1L);
            putJavaFile(javaFile);
        }
        calculationThreads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            JavaFileToken javaFileToken = new JavaFileToken();
            javaFileToken.setDistance(-1);
            outQueue.put(javaFileToken);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void setZero() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getTestCases(session);
        for (TestCase testCase : testCases) {
            System.out.println(testCase.getId());
            Transaction tx = session.beginTransaction();
            Collection<JavaFileToken> javaFileTokens = testCase.getJavaFileTokens();
            Collection<ChangedToken> changedTokens = testCase.getChangedTokens();
            for (JavaFileToken javaFileToken : javaFileTokens) {
                if (javaFileToken.getDistance() == 1) {
                    for (ChangedToken changedToken : changedTokens) {
                        if (changedToken.getName().equals(javaFileToken.getName()) && changedToken.getType() == javaFileToken.getType()) {
                            javaFileToken.setDistance(0);
                        }
                    }
                }
            }
            tx.commit();
        }
        session.close();
    }

    public void run() {
        clear();
        initThreads();
        Session session = SessionUtil.getSession();
        Transaction tx = session.beginTransaction();
        List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
        System.out.println(testCases.size());
        for (TestCase testCase : testCases) {
            System.out.println(testCase.getId());
            Collection<JavaFile> javaFiles = testCase.getJavaFiles();
            for (JavaFile javaFile : javaFiles) {
                javaFile.getDistances().size();
                putJavaFile(javaFile);
            }
        }
        tx.commit();
        session.close();
        terminateThreads();
    }

    public static void main(String[] args) throws IOException {
        Instant start = Instant.now();
        ExtractJavaToken extractJavaToken = new ExtractJavaToken();
        extractJavaToken.run();
        Instant end = Instant.now();
    }
}
