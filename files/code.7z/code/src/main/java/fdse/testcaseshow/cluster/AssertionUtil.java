package fdse.testcaseshow.cluster;

import fdse.testcaseshow.log.LogUtil;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AssertionUtil {
    private static List<Pattern> patterns = new ArrayList<>();
    public static final Pattern pattern1 = Pattern.compile("expected:[\\s]*<(.*)> but was:[\\s]*<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern2 = Pattern.compile("Expecting:[\n\\s]*<(.*)>[\n\\s]*to be an instance of:[\n\\s]*<(.*)>[\n\\s]*but was instance of:[\n\\s]*<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern3 = Pattern.compile("<'(.*)'> should contain the String:<'(.*)'>", Pattern.DOTALL);
    public static final Pattern pattern4 = Pattern.compile("Expecting message:[\n\\s]*<\"(.*)\">[\n\\s]*but was:[\n\\s]*<\"(.*)\">", Pattern.DOTALL);
    public static final Pattern pattern5 = Pattern.compile("org\\.junit\\.Assert\\.assertTrue|org\\.testng\\.AssertJUnit\\.assertTrue|junit\\.framework\\.Assert\\.assertTrue", Pattern.DOTALL);
    public static final Pattern pattern6 = Pattern.compile("expected (.*), but was:<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern7 = Pattern.compile("array lengths differed, (expected.length=\\d+) (actual.length=\\d+)", Pattern.DOTALL);
    public static final Pattern pattern8 = Pattern.compile(" expected \\[(.*)\\] but found \\[(.*)\\]", Pattern.DOTALL);
    public static final Pattern pattern9 = Pattern.compile("Expected: is <(.*)>[\n\\s]*but: was <(.*)>", Pattern.DOTALL);
    public static final Pattern pattern10 = Pattern.compile("Expecting:[\n\\s]*<(.*)>[\n\\s]*to contain only:[\n\\s]*<(.*)>[\n\\s]*but the following elements were unexpected:[\n\\s]*<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern11 = Pattern.compile("Expected size:<(.*)> but was:<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern12 = Pattern.compile("Expecting:[\n\\s]*<(.*)>[\n\\s]*to be exactly an instance of:[\n\\s]*<(.*)>[\n\\s]*but was an instance of:[\n\\s]*<(.*)>", Pattern.DOTALL);
    public static final Pattern pattern13 = Pattern.compile("Expected: not null[\n\\s]*but: was null", Pattern.DOTALL);
    public static final Pattern pattern14 = Pattern.compile("Expecting actual not to be null", Pattern.DOTALL);


    static {
        patterns.add(pattern1);
        patterns.add(pattern2);
        patterns.add(pattern3);
        patterns.add(pattern4);
        patterns.add(pattern5);
        patterns.add(pattern6);
        patterns.add(pattern7);
        patterns.add(pattern8);
        patterns.add(pattern9);
        patterns.add(pattern10);
        patterns.add(pattern11);
        patterns.add(pattern12);
        patterns.add(pattern13);
        patterns.add(pattern14);
    }
    public static AssertionMessage getAssertionMessage(TestItem testItem) {
        String summmary = testItem.getSummary();
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(summmary);
            if (matcher.find()) {
                if (pattern == pattern1) {
                    return new AssertionMessage(matcher.group(1), matcher.group(2));
                }
                if (pattern == pattern7) {
                    return new AssertionMessage(matcher.group(1), matcher.group(2));
                }
                if (pattern == pattern8) {
                    return new AssertionMessage(matcher.group(1), matcher.group(2));
                }
            }
        }
        String stackTrace = testItem.getStackTrace();
        if (stackTrace != null) {
            for (Pattern pattern : patterns) {
                Matcher matcher = pattern.matcher(stackTrace);
                if (matcher.find()) {
                    if (pattern == pattern1) {
                        return new AssertionMessage(matcher.group(1), matcher.group(2));
                    }
                    if (pattern == pattern2) {
                        return new AssertionMessage(matcher.group(2), matcher.group(3));
                    }
                    if (pattern == pattern4) {
                        return new AssertionMessage(matcher.group(1), matcher.group(2));
                    }
                    if (pattern == pattern5) {
                        return new AssertionMessage("true", "false");
                    }
                    if (pattern == pattern6) {
                        return new AssertionMessage(matcher.group(1), matcher.group(2));
                    }
                    if (pattern == pattern9) {
                        return new AssertionMessage(matcher.group(1), matcher.group(2));
                    }
                    if (pattern == pattern10) {
                        return new AssertionMessage(matcher.group(2), matcher.group(1));
                    }

                    if (pattern == pattern11) {
                        return new AssertionMessage(matcher.group(2), matcher.group(1));
                    }
                    if (pattern == pattern12) {
                        return new AssertionMessage(matcher.group(2), matcher.group(3));
                    }
                    if (pattern == pattern13) {
                        return new AssertionMessage("not null", "null");
                    }
                }
            }
        }
        return null;
    }
    @Data
    @AllArgsConstructor
    public static class AssertionMessage {
        private String expected;
        private String actual;
    }
}
