package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.FileUtil;
import org.javatuples.Pair;
import org.javatuples.Quartet;
import org.javatuples.Triplet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ClusterEvaluation {
    //
    public static List<List<TestItem>> intArrayToTestItemList(int[][] array) {
        List<List<TestItem>> testItemListList = new ArrayList<>();
        Random random = new Random();
        Long testItemId = Long.valueOf(random.nextInt(100));
        for (int[] subarray : array) {
            List<TestItem> testItemList = new ArrayList<>();
            for (int categoryId : subarray) {
                TestItem testItem = new TestItem();
                testItem.setId(testItemId);
                testItem.setClusterType(categoryId);
                testItemList.add(testItem);
            }
            testItemListList.add(testItemList);
        }
        return testItemListList;
    }

    public static List<Cluster> testItemListListToClusterList(List<List<TestItem>> testItemListList) {
        //System.out.println(testItemListList.size());
        List<List<DataPoint>> dataPointsList = new ArrayList<>();
        for (List<TestItem> testItems : testItemListList) {
            List<DataPoint> dataPoints = new ArrayList<>();
            for (TestItem testItem : testItems) {
                dataPoints.add(new DataPoint(testItem.getId(), testItem));
            }
            dataPointsList.add(dataPoints);
        }
        //System.out.println(dataPointsList.size());

        List<Cluster> originalClusters = new ArrayList<>();
        for (int i = 0; i < dataPointsList.size(); i++) {
            List<DataPoint> tempDataPoints = dataPointsList.get(i);
            Cluster tempCluster = new Cluster();
            tempCluster.setClusterName("Cluster " + String.valueOf(i));
            tempCluster.setClusterID(i);
            tempCluster.setDataPoints(tempDataPoints);
            for (DataPoint tempDataPoint : tempDataPoints) {
                tempDataPoint.setCluster(tempCluster);
            }
            originalClusters.add(tempCluster);
        }
        // System.out.println(originalClusters.size());
        return originalClusters;
    }

    public static List<Cluster> intArrayToClusterList(int[][] array) {
        List<List<TestItem>> testItemListList = intArrayToTestItemList(array);
        return testItemListListToClusterList(testItemListList);
    }


    private static void convertToMyDataPoint(Long testItemId, int categoryId, int clusterId, List<MyCluster> categories, List<MyCluster> clusters, List<MyDataPoint> myDataPoints) {
        MyCluster category = new MyCluster(categoryId);
        MyCluster cluster = new MyCluster(clusterId);
        int categoryIndex = categories.indexOf(category);
        if (categoryIndex == -1) {
            categories.add(category);
        } else {
            category = categories.get(categoryIndex);
        }
        int clusterIndex = clusters.indexOf(cluster);
        if (clusterIndex == -1) {
            clusters.add(cluster);
        } else {
            cluster = clusters.get(clusterIndex);
        }
        MyDataPoint myDataPoint = new MyDataPoint(testItemId, category, cluster);
        category.getMyDataPoints().add(myDataPoint);
        cluster.getMyDataPoints().add(myDataPoint);
        myDataPoints.add(myDataPoint);
    }

    public static Quartet<List<MyCluster>, List<MyCluster>, List<MyDataPoint>, Integer> clusterListToMyDataPointList(List<Cluster> ahClusters) {
        List<MyCluster> categories = new ArrayList<>();
        List<MyCluster> clusters = new ArrayList<>();
        List<MyDataPoint> myDataPoints = new ArrayList<>();
        for (Cluster ahCluster : ahClusters) {
            for (DataPoint dataPoint : ahCluster.getDataPoints()) {
                Long testItemId = dataPoint.getTestItem().getId();
                int categoryId = dataPoint.getTestItem().getClusterType();
                int clusterId = ahCluster.getClusterID();
                //System.out.println("TestItem: " +testItemId + " categoryId: " + categoryId + "clusterId: " + clusterId);
                convertToMyDataPoint(testItemId, categoryId, clusterId, categories, clusters, myDataPoints);
            }
        }
        int N = myDataPoints.size();
        return Quartet.with(categories, clusters, myDataPoints, N);
    }


    public static List<List<Integer>> aHClusterListToClusterList(List<Cluster> ahClusters) {
        int minCategoryId = Integer.MAX_VALUE;
        for (Cluster ahCluster : ahClusters) {
            for (DataPoint dataPoint : ahCluster.getDataPoints()) {
                if (minCategoryId > dataPoint.getTestItem().getClusterType())
                    minCategoryId = dataPoint.getTestItem().getClusterType();
            }
        }
        List<List<Integer>> intList = new ArrayList<>();
        for (Cluster ahCluster : ahClusters) {
            List<Integer> list = new ArrayList<>();
            for (DataPoint dataPoint : ahCluster.getDataPoints()) {
                int categoryId = 0;
                if (minCategoryId == 0) {
                    categoryId = dataPoint.getTestItem().getClusterType();
                } else if (minCategoryId == 1) {
                    categoryId = dataPoint.getTestItem().getClusterType() - 1;
                } else {
                }
                list.add(categoryId);
            }
            intList.add(list);
        }
        return intList;
    }

    public static List<List<Integer>> clusterListToCategoryList(List<List<Integer>> clusterList) {
        int maxCategoryId = 0;
        for (List<Integer> intList : clusterList) {
            int temp = Collections.max(intList);
            if (temp > maxCategoryId)
                maxCategoryId = temp;
        }
        List<List<Integer>> categoryList = new ArrayList<>();
        for (int i = 0; i <= maxCategoryId; i++) {
            categoryList.add(new ArrayList<>());
        }
        for (int i = 0; i < clusterList.size(); i++) {
            int clusterId = i;
            for (int categoryId : clusterList.get(clusterId)) {
                categoryList.get(categoryId).add(i);
            }
        }
        return categoryList;
    }

    public static int getIntersectionNumber(List<Integer> list, int value) {
        int count = 0;
        for (Integer i : list) {
            if (i == value)
                count++;
        }
        return count;
    }

    public static int countEqualIntNumInList(List<Integer> list, int i) {
        int count = 0;
        for (int l : list) {
            if (l == i)
                count++;
        }
        return count;
    }

    public static int countNotEqualIntNumInList(List<Integer> list, int i) {
        int count = 0;
        for (int l : list) {
            if (l != i)
                count++;
        }
        return count;
    }



}
