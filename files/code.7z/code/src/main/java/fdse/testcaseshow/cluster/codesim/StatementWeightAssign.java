package fdse.testcaseshow.cluster.codesim;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StatementWeightAssign implements IStatementWeight {
    private volatile static StatementWeightAssign statementWeightAssign;
    private StatementWeightAssign() { }

    public static StatementWeightAssign getInstance() {
        if (statementWeightAssign == null) {
            synchronized (StatementWeightAssign.class) {
                if (statementWeightAssign == null) {
                    statementWeightAssign = new StatementWeightAssign();
                }
            }
        }
        return statementWeightAssign;
    }

    @Override
    public void setStatementInfoWeight(CodeSimilarityByStatement.StatementInfo statementInfo, Map<String, Integer> distanceMap, CodeSimilarity.Coefficient coefficient) {
        Collection<String> tokens = statementInfo.getTokens();
        Set<String> set = new HashSet<String>(tokens);
        int minDistance = coefficient.getMaxDistance();
        for (int distance : distanceMap.values()) {
            if (distance < minDistance) {
                minDistance = distance;
            }
        }
        statementInfo.setWeight(Math.exp(-1 * coefficient.getCComplete() * minDistance));
    }
}