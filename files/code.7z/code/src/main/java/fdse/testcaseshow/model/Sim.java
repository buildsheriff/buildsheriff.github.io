package fdse.testcaseshow.model;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Data
@RequiredArgsConstructor
@Entity
@Table(name = "sim")
public class Sim {
    @Id
    private Long id;

    @Column(name = "type")
    private int type;

    @Column(name = "testItemAID")
    private long testItemAID;

    @Column(name = "testItemBID")
    private long testItemBID;

    @Column(name = "c")
    private String c;

    @Column(name = "maxDistance")
    private int maxDistance;

    @Column(name = "sim")
    private double sim;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;
}