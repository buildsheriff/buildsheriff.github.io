package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.combine.SimInterface;
import fdse.testcaseshow.cluster.evaluation.ExceptionSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.Session;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class AssertionMessage extends AHCluster implements SimInterface {
    public AssertionMessage(List<DataPoint> dataPoints, double sMax) {
        super(dataPoints, sMax);
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {

        String msg1 = getAssertionMessage(testItem1);
        String msg2 = getAssertionMessage(testItem2);
        if (msg1 == null || msg2 == null)
            return 0.0;
        double sim = EditDistance.getsimilarity(msg1, msg2);

        return sim;
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static String getAssertionMessage(TestItem testItem) {
        if (testItem.getStackTrace() == null && testItem.getErrorMessage() == null)
            return null;
        String msg = null;
        if (testItem.getStackTrace() != null) {
            String[] list = testItem.getStackTrace().split("\n");
            List<String> result = new ArrayList<>();
            boolean flag = false;
            for (String s : list) {
                if (s.trim().startsWith("at")) {
                    flag = false;
                }
                if (flag) {
                    result.add(s.trim());
                }
                if (s.contains("Time elapsed:")) {
                    flag = true;
                }
            }
            msg = String.join(" ", result);
        } else {
            msg = testItem.getErrorMessage();
        }
        msg = msg.replaceAll(":", " ");
        msg = msg.replaceAll("\\s+", " ");
        return msg.trim();
    }

    public static List<Cluster> clusterBuild(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new AssertionMessage(dataPoints, sMax).startCluster();
    }

    public static ResultSummary getResultSummary(double sMax, List<TestCase> testCases) {
        ResultSummary resultSummary = new ExceptionSimilarityResultSummary(new ExceptionSimilarity.Coefficient(sMax));
        for (TestCase testCase : testCases) {
            List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
            List<Cluster> clusters = AssertionMessage.clusterBuild(sMax, selectedTestItems);
            resultSummary.addSingleResult(testCase, clusters, false);
        }
        return resultSummary;
    }

    public static void run() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.ASSERTIONMESSAGE, true, null)) {
                for (double sMax = 0.51; sMax < 1.0001; sMax += 0.01) {
                    System.out.println("sMax: " + sMax);
                    ResultSummary resultSummary = getResultSummary(sMax, testCases);
                    storeResultSummary.write(resultSummary);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        AssertionMessage.run();
    }
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private double sMax;
    }
}
