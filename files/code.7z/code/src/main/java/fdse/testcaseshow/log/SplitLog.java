package fdse.testcaseshow.log;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.SessionUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class SplitLog {

    private BlockingQueue<TestCase> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<TestItemMap> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 1;

    private void clear() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete TestItem";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            int autoIncrement = session.createSQLQuery("ALTER TABLE test_items AUTO_INCREMENT = 1").executeUpdate();

            tx.commit();
        }
    }

    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new ExtractTestItemTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }
    private void putTestCase(TestCase testCase) {
        try {
            inQueue.put(testCase);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void splitLogInfoIntoTestItems() {
        clear();
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreTestItemTask(outQueue));
        initializeThreads(threads, storeThread);
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id >= 0", TestCase.class);
            List<TestCase> testCases = query.list();
            System.out.println(testCases.size());
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                testCase.getTestLog().getLog();
                // Transaction tx = session.beginTransaction();
                // testCase.getTestItems().clear();
                // testCase.getTestFrames().clear();
                // tx.commit();
                putTestCase(testCase);
            }

            for (int i = 0; i < THREAD_NUMBER; i++) {
                TestCase sentry = new TestCase();
                sentry.setId(-1L);
                putTestCase(sentry);
            }
            threads.forEach(thread -> {
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            try {
                TestItemMap testItemMap = new TestItemMap(-1L, null);
                outQueue.put(testItemMap);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                storeThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    public void storeTestFrame() {
        Session session = SessionUtil.getSession();
        Query<TestItem> query = session.createQuery("from TestItem where id > 0", TestItem.class);
        List<TestItem> testItems = query.getResultList();
        long count = 1;
        Transaction tx = session.beginTransaction();
        for (TestItem testItem : testItems) {
            if (testItem.getStackTrace() == null)
                continue;
            String[] stackTraces = testItem.getStackTrace().split("\n");
            for (int j = 0; j < stackTraces.length; j++) {
                TestFrame frame = new TestFrame();
                frame.setId(count);
                count++;
                frame.setTestItem(testItem);
                frame.setOrder(j);
                frame.setFrame(stackTraces[j]);
                frame.setTestCase(testItem.getTestCase());
                LogUtil.polulateTestFrame(frame);
                session.save(frame);
                if (count % 100 == 0) {
                    session.flush();
                    session.clear();
                }
            }

        }
        tx.commit();
        session.close();
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
         SplitLog splitLog = new SplitLog();
         splitLog.splitLogInfoIntoTestItems();
        Instant end = Instant.now();
        System.out.println("" + Duration.between(start, end));
    }
    @Data
    @AllArgsConstructor
    public static class TestItemMap {
    private Long testCaseId;
    private TestItem testItem;
    }
}
