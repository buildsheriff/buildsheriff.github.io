package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.codesim.ITokensDuplication;
import fdse.testcaseshow.cluster.codesim.TokensContainDuplication;
import fdse.testcaseshow.cluster.evaluation.CodeSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class CodeSimilarityWithoutDistanceMaster {
    private BlockingQueue<CodeSimilarity.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);

    private List<Thread> slaveThreads = new ArrayList<>();
    private Thread collectThread = null;

    private static final int THREAD_NUMBER = 20;

    private List<CodeSimilarity.Coefficient> coefficients;
    private ITokensDuplication iTokensDuplication;
    private String outFileName;

    public CodeSimilarityWithoutDistanceMaster(List<CodeSimilarity.Coefficient> coefficients, ITokensDuplication iTokensDuplication, String outFileName) {
        this.coefficients = coefficients;
        this.iTokensDuplication = iTokensDuplication;
        this.outFileName = outFileName;
    }

    private void initThreads(List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new CodeSimilarityWithoutDistanceSlave(testCases, this.inQueue, this.outQueue, this.iTokensDuplication));
            slaveThreads.add(tmpThread);
            tmpThread.start();
        }
        collectThread = new Thread(new CodeSimilarityWithoutDistanceCollect(this.outQueue, this.outFileName));
        collectThread.start();
    }

    public void putCoefficient(CodeSimilarity.Coefficient coefficient) {
        try {
            inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void finishThreads() {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient();
            coefficient.setMaxDistance(-1);
            putCoefficient(coefficient);
        }
        slaveThreads.forEach(slaveThread -> {
            try {
                slaveThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        try {
            ResultSummary resultSummary = new CodeSimilarityResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void loadResourcesFromMysql(TestCase testCase) {
        testCase.getJavaFileTokens().size();
        testCase.getChangedFiles().size();
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        //List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        for (TestItem testItem : selectedTestItems) {
            testItem.getTestCodeStatements().size();
        }
    }

    public void tuning() {
        List<TestCase> testCases = null;
        try(Session session = SessionUtil.getSession()) {
            testCases = MysqlUtil.getAssertionTestCases(session);
            for (TestCase testCase : testCases) {
                loadResourcesFromMysql(testCase);
            }
        }
        initThreads(testCases);

        coefficients.forEach(coefficient -> putCoefficient(coefficient));

        finishThreads();
    }

    public static void byTokenWithoutDistance() {
        List<CodeSimilarity.Coefficient> coefficients = new ArrayList<>();
        ITokensDuplication iTokensDuplication = TokensContainDuplication.getInstance();
        //String outFileName = "ExceptionByTokenWithoutDistance";
        String outFileName = "ByTokenWithoutDistance";
        for (double cAll = 0.1; cAll < 2.0001; cAll += 0.1) {
            for (double sMax = 0.51; sMax < 1.00001; sMax += 0.01) {
                CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0.0, cAll, 16, 0.0, sMax);
                coefficients.add(coefficient);
            }
        }

        new CodeSimilarityWithoutDistanceMaster(coefficients, iTokensDuplication, outFileName).tuning();
    }

    public static void main(String[] args) {
        byTokenWithoutDistance();
    }
}
