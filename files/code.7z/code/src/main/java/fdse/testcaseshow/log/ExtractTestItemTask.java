package fdse.testcaseshow.log;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExtractTestItemTask implements Runnable {
    private BlockingQueue<TestCase> inQueue;
    private BlockingQueue<SplitLog.TestItemMap> outQueue;
    private List<Pattern> patterns = new ArrayList<>();
    public TestCase testCase = null;
    public static final Pattern pattern1 = Pattern.compile(String.format("(%s)\\((%s)\\)(.*)", LogUtil.METHOD_NAME_REGEX, LogUtil.FULL_CLASS_NAME_REGEX), Pattern.DOTALL);
    public static final Pattern pattern2 = Pattern.compile("([_.$\\w]+)#([_\\w]+) (.*)", Pattern.DOTALL);
    public static final Pattern pattern3 = Pattern.compile(String.format("((%s)>)?((%s)\\.(%s):\\d+->)?(((%s\\.)?%s:\\d+->)*)((%s)\\.)?(%s):\\d+( (.*))?",
            LogUtil.CLASS_NAME_REGEX, LogUtil.CLASS_NAME_REGEX, LogUtil.METHOD_NAME_REGEX,
            LogUtil.CLASS_NAME_REGEX, LogUtil.METHOD_NAME_REGEX,
            LogUtil.CLASS_NAME_REGEX, LogUtil.METHOD_NAME_REGEX), Pattern.DOTALL);
    public static final Pattern pattern4 = Pattern.compile(String.format("(%s)\\.(%s) (.*)", LogUtil.CLASS_NAME_REGEX, LogUtil.METHOD_NAME_REGEX), Pattern.DOTALL);

    public ExtractTestItemTask(BlockingQueue<TestCase> inQueue, BlockingQueue<SplitLog.TestItemMap> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
        patterns.add(pattern1);
        patterns.add(pattern2);
        patterns.add(pattern3);

        patterns.add(pattern4);
    }
    public static String mark1 = "[INFO] --- maven-javadoc-plugin:2.10.4:jar (attach-javadocs) @ appearance-plugin-ui ---";
    public static String nonCrashMark = "Failed tests:";
    public static String crashMark = "Tests in error:";
    public static String hyphenMark = "---";
    public static String summaryMark = "Tests run:";

    public List<TestItem> extract(String content) {
        if (content == null)
            return null;
        List<String> list = LogUtil.stringToList(content);
        return extract(list);
    }

    public List<TestItem> extract(List<String> content) {
        List<TestItem> out = new ArrayList<>();
        List<List<String>> sections = contentSplit(content);
        for(List<String> section : sections) {
            out.addAll(extractItems(section));
        }
        return out;
    }
    public List<List<String>> contentSplit(List<String> content) {
        List<List<String>> list = new ArrayList<>();
        String stringTESTS = "T E S T S";
        int flag = 0;
        List<String> tempList = new ArrayList<>();
        for(String s : content) {
            // System.out.println(s);
            if(s.contains(stringTESTS) || s.contains(mark1)) {
                if (flag > 0) {
                    list.add(tempList);
                    tempList = new ArrayList<>();
                }
                flag++;
            }
            tempList.add(s);
        }
        list.add(tempList);
        return list;
    }

    public List<TestItem> extractItems(List<String> section) {
        List<TestItem> result = new ArrayList<>();
        List<String> nonCrashSummary = getNonCrashSummary(section);
        List<String> crashSummary = getCrashSummary(section);

        if(nonCrashSummary.size() > 0) {
            List<TestItem> nonCrashTestItems = splitSummary(nonCrashSummary, false);
            if (nonCrashTestItems != null)
                result.addAll(nonCrashTestItems);
        }
        if(crashSummary.size() > 0) {
            List<TestItem> crashTestItems = splitSummary(crashSummary, true);
            if (crashTestItems != null)
                result.addAll(crashTestItems);
        }
        if(nonCrashSummary.size() <= 0 && crashSummary.size() <= 0) {
            result.addAll(extractSpecialItems(section));
        }

        List<List<String>> stackTraces = extractStackTrace(section);
        setStackTrace(result, stackTraces);
        return result;
    }

    public List<String> getNonCrashSummary(List<String> section) {
        List<String> nonCrashSection = new ArrayList<>();
        boolean nonCrashFlag = false;
        for (String s : section) {
            if (s.contains(nonCrashMark) && s.contains("Invoke") == false) nonCrashFlag = true;
            if (nonCrashFlag == true && (s.contains(summaryMark) || s.contains(crashMark) || s.contains(hyphenMark)))
                nonCrashFlag = false;
            if (nonCrashFlag == true) nonCrashSection.add(s);
        }
        return nonCrashSection;
    }

    public List<String> getCrashSummary(List<String> section) {
        List<String> crashSection = new ArrayList<>();
        boolean crashFlag = false;
        for (String s : section) {
            if (s.contains(crashMark)) crashFlag = true;
            if (crashFlag == true && (s.contains(summaryMark) || s.contains(hyphenMark)))
                crashFlag = false;
            if (crashFlag == true) crashSection.add(s);
        }
        return crashSection;
    }


    public List<TestItem> extractSpecialItems(List<String> section) {
//        String resultMark = "[INFO] Results:";
//        String errorMark = "[ERROR] Errors:";
//        String failureMark = "[ERROR] Failures:";
        String resultMark = "Results:";
        String errorMark = "Errors:";
        String failureMark = "Failures:";
        String hyphenMark = "---";
        String summaryMark = "Tests run:";
        List<String> crashSection = new ArrayList<>();
        List<String> nonCrashSection = new ArrayList<>();
        boolean resultFlag = false;
        boolean errorFlag = false;
        boolean failureFlag = false;
        for(String s : section) {
            //System.out.println(s);
            if(s.contains(resultMark)) resultFlag = true;

            if (resultFlag && s.contains(failureMark)) failureFlag = true;
            if (failureFlag == true && (s.contains(errorMark) || s.contains(summaryMark) || s.contains(hyphenMark))) failureFlag = false;
            if (failureFlag == true) nonCrashSection.add(s);

            if(resultFlag && s.contains(errorMark)) errorFlag = true;
            if(errorFlag == true && (s.contains(summaryMark) || s.contains(hyphenMark))) errorFlag = false;
            if(errorFlag == true) crashSection.add(s);

        }
        List<TestItem> testItems = new ArrayList<>();
        //crashSection.forEach(System.out::println);
        if (nonCrashSection.size() > 0) {
            List<TestItem> nonCrashTestItems = splitSummary(nonCrashSection, false);
            if (nonCrashTestItems != null)
                testItems.addAll(nonCrashTestItems);
        }
        if (crashSection.size() > 0) {
            List<TestItem> crashTestItems = splitSummary(crashSection, true);
            if (crashTestItems != null)
                testItems.addAll(crashTestItems);
        }
        // List<TestItem> crashTestItems = splitSummary(crashSection, true);
        return testItems;
    }

    public List<List<String>> extractStackTrace(List<String> section) {
        String mark = "Time elapsed";
        boolean flag = false;
        List<List<String>> stackTraces = new ArrayList<>();
        List<String> stackTrace = new ArrayList<>();
        for(String s : section) {
            //System.out.println(s);
            if(flag == true && stackTrace.size() > 0 && (s.contains(mark) || s.contains("Running") || s.contains("Results :")/*s.equals("")*/)) {
                flag = false;
                stackTraces.add(stackTrace);
                stackTrace = new ArrayList<>();
            }
            if(s.contains(mark)) flag = true;
            if(flag == true && (!s.isEmpty())) {
                // System.out.println(s);
                stackTrace.add(s);
            }
        }
        if (stackTrace.size() > 0) {
            stackTraces.add(stackTrace);
        }
        return stackTraces;
    }

    public List<TestItem> splitSummary(List<String> summary, boolean isCrash) {
        Pattern pattern = getPattern(summary);
        List<String> items = splitSummary(summary, pattern);
        List<TestItem> testItems = new ArrayList<>();
        for(String s : items) {
            TestItem tempTestItem = stringToTestItem(s, isCrash, pattern);
            testItems.add(tempTestItem);
        }
        specialExtractTestItems(testItems, summary, isCrash);
        return testItems;
    }

    public void specialExtractTestItems(List<TestItem> testItems, List<String> summary, boolean isCrash) {
        if (testCase == null)
            return;
    }

    public Pattern getPattern(List<String> summary) {
        if (this.testCase != null && this.testCase.getId() == 220)
            return pattern3;
        Map<Pattern, Integer> map = new HashMap<>();
        for(String s : summary) {
            for (Pattern pattern : patterns) {
                if (pattern.matcher(s).find()) {
                    if (map.containsKey(pattern)) {
                        map.put(pattern, map.get(pattern) + 1);
                    } else {
                        map.put(pattern, 1);
                    }
                }
                if (map.get(pattern) != null && map.get(pattern) > 1){
                    System.out.println(pattern.toString() + ": " + map.get(pattern));
                    return pattern;
                }

            }
        }
        for (Pattern pattern : patterns) {
            if (map.get(pattern) != null){
                return pattern;
            }

        }
        return null;
    }

    public List<String> splitSummary(List<String> section, Pattern pattern) {
        if (pattern == null)
            return new ArrayList<>();
        List<String> items = new ArrayList<>();
        List<String> tempItem = null;

        for(String s : section) {
            if(pattern.matcher(s).find() && s.trim().startsWith("at ") == false) {
                if(tempItem != null && tempItem.size() > 0) {
                    items.add(String.join("\n", tempItem).trim());
                }
                tempItem = new ArrayList<>();
            }
            if(tempItem != null) tempItem.add(s);
        }
        if(tempItem != null && tempItem.size() > 0) items.add(String.join("\n", tempItem).trim());

        return items;
    }


    public TestItem stringToTestItem(String item, boolean isCrash, Pattern pattern) {
        String className = null;
        String superClassName = null;
        String methodName = null;
        String errorMessage = null;
        String tempString = null;
        Matcher matcher = pattern.matcher(item);
        if(matcher.find()) {
            if (pattern.equals(pattern1)) {
                className = matcher.group(2);
                methodName = matcher.group(1);
                tempString = matcher.group(4);
            }

            if (pattern.equals(pattern2)) {
                className = matcher.group(1);
                methodName = matcher.group(2);
                tempString = matcher.group(3);
            }

            if (pattern.equals(pattern3)) {
                if (matcher.group(2) != null && matcher.group(4) != null && matcher.group(5) != null) {
                    className = matcher.group(4);
                    methodName = matcher.group(5);
                } if (matcher.group(2) != null && matcher.group(4) == null && matcher.group(5) == null) {
                    className = matcher.group(2);
                    methodName = null;
                } else if (matcher.group(3) != null){
                    className = matcher.group(4);
                    methodName = matcher.group(5);
                } else if (matcher.group(10) != null){
                    className = matcher.group(10);
                    methodName = matcher.group(11);
                }
                tempString = matcher.group(13);
            }

            if (pattern.equals(pattern4)) {
                className = matcher.group(1);
                methodName = matcher.group(2);
                tempString = matcher.group(3);
            }
            if(tempString == null || tempString.length() == 0){
                errorMessage = null;
            } else {
                errorMessage = tempString.trim();
            }
        }

        TestItem tempTestItem = new TestItem();
        tempTestItem.setSummary(item);
        tempTestItem.setClassName(className);
        tempTestItem.setMethodName(methodName);
        tempTestItem.setErrorMessage(errorMessage);
        tempTestItem.setCrash(isCrash);
        return tempTestItem;
    }
    public static List<String> fileToStringList(Path path) {
        List<String> list = null;
        try (Stream<String> lines = Files.lines(path)){
            list = lines.collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<String> result = new ArrayList<>();
        list.forEach(l -> result.add(l.trim()));
        return result;
    }

    private TestCase getTestCase() {
        TestCase testCase = null;
        try {
            testCase = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testCase;
    }

    public void setStackTrace(List<TestItem> testItems, List<List<String>> stackTraces) {
        for(int i = 0; i < testItems.size(); i ++){
            setStackTraceOfTestItemThroughTopMatch(testItems.get(i), stackTraces);
        }

        for(int i = 0; i < testItems.size(); i ++){
            setStackTraceOfTestItemThroughMidMatch(testItems.get(i), stackTraces);
        }

        for(int i = 0; i < testItems.size(); i ++){
            setStackTraceOfTestItemThroughClassName(testItems.get(i), stackTraces);
        }

        for(int i = 0; i < testItems.size(); i ++){
            setStackTraceOfTestItemThroughMethodName(testItems.get(i), stackTraces);
        }
    }

    public void setStackTraceOfTestItemThroughTopMatch(TestItem testItem, List<List<String>> stackTraces) {
        if (testItem.getStackTrace() != null)
            return;
        Pattern STPattern = Pattern.compile(testItem.getMethodName() + "\\(.*" + testItem.getClassName() + ".*Time elapsed");

        Iterator<List<String>> iterator = stackTraces.iterator();
        while (iterator.hasNext()) {
            List<String> list = iterator.next();
            for (String s : list) {
                if (STPattern.matcher(s).find()) {
                    testItem.setStackTrace(String.join("\n", list));
                    iterator.remove();
                    break;
                }
            }
            if (testItem.getStackTrace() != null)
                break;
        }
    }

    public void setStackTraceOfTestItemThroughMidMatch(TestItem testItem, List<List<String>> stackTraces) {
        if (testItem.getStackTrace() != null)
            return;
        Iterator<List<String>> iterator = stackTraces.iterator();
        while (iterator.hasNext()) {
            List<String> list = iterator.next();
            for (String s : list) {
                if (testItem.getClassName()!= null && testItem.getMethodName() != null && s.contains(testItem.getClassName()) && s.contains(testItem.getMethodName())) {
                    testItem.setStackTrace(String.join("\n", list));
                    iterator.remove();
                    break;
                }
            }
            if (testItem.getStackTrace() != null)
                break;
        }
    }

    public void setStackTraceOfTestItemThroughClassName(TestItem testItem, List<List<String>> stackTraces) {
        if (testItem.getStackTrace() != null)
            return;
        Iterator<List<String>> iterator = stackTraces.iterator();
        while (iterator.hasNext()) {
            List<String> list = iterator.next();
            for (String s : list) {
                if (testItem.getClassName() != null && s.contains(testItem.getClassName()) && s.contains("Tests run:") == false) {
                    testItem.setStackTrace(String.join("\n", list));
                    iterator.remove();
                    break;
                }
            }
            if (testItem.getStackTrace() != null)
                break;
        }
    }

    public void setStackTraceOfTestItemThroughMethodName(TestItem testItem, List<List<String>> stackTraces) {
        if (testItem.getStackTrace() != null)
            return;
        Iterator<List<String>> iterator = stackTraces.iterator();
        while (iterator.hasNext()) {
            List<String> list = iterator.next();
            for (String s : list) {
                if (testItem.getMethodName() != null && s.contains(testItem.getMethodName()) && s.contains("Time elapsed:")) {
                    testItem.setStackTrace(String.join("\n", list));
                    iterator.remove();
                    break;
                }
            }
            if (testItem.getStackTrace() != null)
                break;
        }
    }
    private void putTestItemMap(SplitLog.TestItemMap testItemMap) {
        try {
            outQueue.put(testItemMap);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void setTestCase(TestCase testCase) {
        this.testCase = testCase;
    }

    @Override
    public void run() {
        try(Session session = SessionUtil.getSession()) {
            while (true) {
                TestCase testCase = getTestCase();
                if (testCase.getId() < 0)
                    break;
                this.testCase = testCase;
                String log = testCase.getTestLog().getLog();
                String repoName = testCase.getRepoName().trim();
                String jobNumber = testCase.getJobNumber().trim();
                if (log == null) {
                    System.out.println(testCase.getId() + "");
                    continue;
                }
                List<TestItem> list = extract(log);
                if (list == null) {
                    System.out.println(testCase.getId() + "");
                    continue;
                }
                List<SplitLog.TestItemMap> maps = new ArrayList<>();
                list.forEach(i -> {
                    maps.add(new SplitLog.TestItemMap(testCase.getId(), i));
                });
                maps.forEach(i -> {
                    putTestItemMap(i);
                });
            }
        }
    }
}
