package fdse.testcaseshow.feature;

import fdse.testcaseshow.code.ExtractJavaToken;
import fdse.testcaseshow.model.ChangedToken;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

public class ChangedInfoFactory {
    private Hashtable<Long, ChangedInfo> ht;

    private ChangedInfoFactory() {
        ht = new Hashtable<>();
    }

    private static class HolderClass {
        private final static ChangedInfoFactory instance = new ChangedInfoFactory();
    }

    public static ChangedInfoFactory getInstance() {
        return HolderClass.instance;
    }

    public ChangedInfo getChangedInfo(TestCase testCase) {
        long id = testCase.getId();
        if (ht.containsKey(id)) {
            return ht.get(id);
        } else {
            ChangedInfo changedInfo = new ChangedInfo(testCase);
            ht.put(id, changedInfo);
            return changedInfo;
        }
    }

    public static void saveChangedTokens() {
        Session session = SessionUtil.getSession();
        Transaction tx = session.beginTransaction();
        List<TestCase> testCases = MysqlUtil.getTestCases(session);
        long id = 1;
        for (TestCase testCase : testCases) {
            ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
            Set<Token> tokens = changedInfo.getChangedTokens();
            for (Token token : tokens) {
                ChangedToken changedToken = new ChangedToken();
                changedToken.setId(id++);
                changedToken.setName(token.getName());
                changedToken.setType(token.getType().getValue());
                changedToken.setStatus(token.getStatus().getValue());
                changedToken.setTestCase(testCase);
                session.save(changedToken);
            }
        }
        tx.commit();
        session.close();
    }

    public static void main(String[] args) throws IOException {
        ChangedInfoFactory.saveChangedTokens();
    }
}
