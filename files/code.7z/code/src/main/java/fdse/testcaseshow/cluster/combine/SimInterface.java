package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.model.TestItem;

public interface SimInterface {
    double getSim(TestItem testItem1, TestItem testItem2);
}
