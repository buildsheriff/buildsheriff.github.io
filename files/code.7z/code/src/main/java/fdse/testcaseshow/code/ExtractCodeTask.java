package fdse.testcaseshow.code;

import fdse.testcaseshow.log.LogUtil;
import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.FileUtil;
import fdse.testcaseshow.util.SessionUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.jdt.core.dom.*;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.javatuples.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractCodeTask implements Runnable {
    private BlockingQueue<TestItem> inQueue;
    private BlockingQueue<TestCode> outQueue;
    private BlockingQueue<TestCodeStatement> outQueue1;

    public static final Pattern pattern1 = Pattern.compile("(.*)\\((.*)\\)  Time elapsed:", Pattern.DOTALL);

    public ExtractCodeTask(BlockingQueue<TestItem> inQueue, BlockingQueue<TestCode> outQueue, BlockingQueue<TestCodeStatement> outQueue1) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
        this.outQueue1 = outQueue1;
    }

    private TestItem getTestItem() {
        TestItem testItem = null;
        try {
            testItem = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testItem;
    }
    private void putTestCode(TestCode testCode) {
        try {
            outQueue.put(testCode);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private void putTestCodeStatement(TestCodeStatement testCodeStatement) {
        try {
            outQueue1.put(testCodeStatement);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void replaceSecure(TestItem testItem) {
        String replaceString = null;
        if (testItem.getTestCase().getId() == 269L) {
            replaceString = "mazi";
        } else if (testItem.getTestCase().getId() == 314L) {
            replaceString = "yammer";
        } else if (testItem.getTestCase().getId() == 316L) {
            replaceString = "graphaware";
        } else {
            return;
        }
        String secure = "\\[secure\\]";
        if (testItem.getSummary() != null) {
            testItem.setSummary(testItem.getSummary().replace(secure, replaceString));
        }
        if (testItem.getClassName() != null) {
            testItem.setClassName(testItem.getClassName().replace(secure, replaceString));
        }
        if (testItem.getStackTrace() != null) {
            testItem.setStackTrace(testItem.getStackTrace().replaceAll(secure, replaceString));
        }
    }

    public static List<String> getFrameList(String[] list) {
        List<String> result = new ArrayList<>();
        for (String s : list) {
            if (s.contains("at ") && s.contains("org.junit") == false
                    && s.contains("org.hamcrest") == false
                    && s.contains("junit.framework") == false
                    && s.contains("sun.reflect") == false
                    && s.contains("java.lang") == false
                    && s.contains("org.fest.assertions") == false
                    && s.contains("org.testng") == false
                    && s.contains("org.springframework") == false
                    && s.contains("org.custommonkey.xmlunit.XMLAssert") == false
                    && s.contains("org.apache.maven") == false
                    && s.contains("org.apache.http") == false
                    && s.contains("java.net") == false
                    && s.contains("java.util") == false
                    && s.contains("com.github.restdriver") == false) {
                result.add(s);
            }
            if (s.contains("sun.reflect"))
                break;
        }
        return result;
    }

    public static Pair<String, String> splitClassFullName(String classFullName) {
        int pos = classFullName.lastIndexOf(".");
        String packageName = classFullName.substring(0, pos);
        String className = classFullName.substring(pos + 1);
        return new Pair<>(packageName, className);
    }

    public static List<FrameInfo> getFrameInfoListFromStackTrace(TestItem testItem) {
        String stackTrace = testItem.getStackTrace();
        List<FrameInfo> frameInfoList = new ArrayList<>();
        String[] list = stackTrace.split("\n");
        List<String> frameList =  null;

        frameList = getFrameList(list);
        for (String s : frameList) {
            Matcher matcher = LogUtil.framePattern.matcher(s);
            if (matcher.find()) {
                FrameInfo frameInfo = new FrameInfo();
                String packageName = matcher.group(1);
                frameInfo.setPackageName(packageName.substring(0, packageName.length() - 1));
                frameInfo.setClassName(matcher.group(3));
                frameInfo.setMethodName(matcher.group(4));
                frameInfo.setFileName(matcher.group(5));
                frameInfo.setNum(Integer.parseInt(matcher.group(6)));
                frameInfoList.add(frameInfo);
            }
        }

        if (frameInfoList.size() <= 0) {
            for (String s : list) {
                Matcher matcher = pattern1.matcher(s);
                if (matcher.find()) {
                    FrameInfo frameInfo = new FrameInfo();
                    frameInfo.setMethodName(matcher.group(1));
                    String classFullName = matcher.group(2);
                    if (classFullName.contains(".")) {
                        Pair<String, String> pair = splitClassFullName(classFullName);
                        frameInfo.setPackageName(pair.getValue0());
                        frameInfo.setClassName(pair.getValue1());
                        frameInfoList.add(frameInfo);
                    }
                }
            }
        }
        return frameInfoList;
    }

    public static List<FrameInfo> getFrameInfoList(TestItem testItem) {
        List<FrameInfo> frameInfoList = new ArrayList<>();
        if (testItem.getStackTrace() != null) {
            frameInfoList.addAll(getFrameInfoListFromStackTrace(testItem));
        }
        if (frameInfoList.size() <= 0) {
            FrameInfo frameInfo = new FrameInfo();
            String classFullName = testItem.getClassName();
            frameInfo.setMethodName(testItem.getMethodName());
            if (classFullName.contains(".")) {
                Pair<String, String> pair = splitClassFullName(classFullName);
                frameInfo.setPackageName(pair.getValue0());
                frameInfo.setClassName(pair.getValue1());
            } else {
                frameInfo.setClassName(classFullName);
            }
            frameInfoList.add(frameInfo);
        }
        return frameInfoList;
    }
    public boolean findTheMethodDeclaration(TestItem testItem, ExtractCode.MethodInfo methodInfo, FrameInfo frameInfo) {
        String methodNameOfCode = methodInfo.getMethodDeclaration().getName().getFullyQualifiedName();
        if (testItem.getTestCase().getRepoName().equals("geoserver/geoserver")
                && testItem.getTestCase().getJobNumber().equals("1001.2")
                && testItem.getClassName().equals("org.geoserver.wfs.json.GeoJSONTest")) {
            frameInfo.setNum(0);
        }

        if (methodNameOfCode.equals(frameInfo.getMethodName())) {
            if (frameInfo.getNum() == 0) {
                return true;
            }

            if (methodInfo.getStartLineNumber() <= frameInfo.getNum() && methodInfo.getEndLineNumber() >= frameInfo.getNum()) {
                return true;
            }
        }
        return false;
    }

    public MethodInfo extractTestCode(TestItem testItem, FrameInfo frameInfo, Session session) {
        Query<JavaFile> query = null;
        if (frameInfo.getNum() != 0) {
            query = session.createQuery("from JavaFile j where testCase = :testCase and packageName = :packageName and fileName = :fileName", JavaFile.class)
                    .setParameter("testCase", testItem.getTestCase())
                    .setParameter("packageName", frameInfo.getPackageName())
                    .setParameter("fileName", frameInfo.getFileName());
        } else if (frameInfo.getPackageName() != null){
            query = session.createQuery("from JavaFile j where testCase = :testCase and packageName = :packageName and fileName = :fileName", JavaFile.class)
                    .setParameter("testCase", testItem.getTestCase())
                    .setParameter("packageName", frameInfo.getPackageName())
                    .setParameter("fileName", frameInfo.getClassName() + ".java");
        } else {
            query = session.createQuery("from JavaFile j where testCase = :testCase and fileName = :fileName", JavaFile.class)
                    .setParameter("testCase", testItem.getTestCase())
                    .setParameter("fileName", frameInfo.getClassName() + ".java");
        }

        List<JavaFile> javaFiles = query.getResultList();
        TestCode testCode = null;
        for (JavaFile javaFile : javaFiles) {
            String filePath = FileUtil.getFileAbsolutePath(javaFile.getFilePath());
            JavaVisitor javaVisitor = FileUtil.getJavaFileInfo(filePath);
            List<ExtractCode.MethodInfo> methodInfos = javaVisitor.getMethodInfos();
            for (ExtractCode.MethodInfo methodInfo : methodInfos) {
                MethodDeclaration md = methodInfo.getMethodDeclaration();
                if (findTheMethodDeclaration(testItem, methodInfo, frameInfo)) {
                    testCode = new TestCode();
                    testCode.setCode(md.toString());
                    testCode.setStartNumber(methodInfo.getStartLineNumber());
                    testCode.setEndNumber(methodInfo.getEndLineNumber());
                    testCode.setTestItem(testItem);
                    testCode.setCompleteFileName(javaFile.getCompleteFileName());
                    if (md.parameters().size() > 0) {
                        List<String> stringList = new ArrayList<>();
                        for (Object o : md.parameters()) {
                            SingleVariableDeclaration singleVariableDeclaration = (SingleVariableDeclaration) o;
                            stringList.add(singleVariableDeclaration.getType().toString());
                            stringList.add(singleVariableDeclaration.getName().toString());
                        }
                        testCode.setParameters(String.join(" ", stringList));
                    }
                    return new MethodInfo(testCode, md, javaVisitor);
                }
            }
        }
        return null;
    }

    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        while (true) {
            TestItem testItem = getTestItem();
            if (testItem.getId() < 0)
                break;
            System.out.println(testItem.getId());
            replaceSecure(testItem);
            List<FrameInfo> frameInfoList = getFrameInfoList(testItem);


            MethodInfo methodInfo = extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);

            if (methodInfo == null) {
            } else {
                putTestCode(methodInfo.getTestCode());
                int boundary = getLineNumber(testItem);
                List<TestCodeStatement> testCodeStatements = extractTestCodeStatement(methodInfo, testItem, boundary);
                testCodeStatements.forEach(testCodeStatement -> {
                    putTestCodeStatement(testCodeStatement);
                });
            }
        }
        session.close();
    }


    public List<TestCodeStatement> extractTestCodeStatement(MethodInfo methodInfo, TestItem testItem, int boundary) {
        List<TestCodeStatement> testCodeStatements = new ArrayList<>();
        JavaVisitor javaVisitor = methodInfo.getJavaVisitor();
        List<Statement> list = methodInfo.getMethodDeclaration().getBody().statements();
        list.forEach(statement -> {
                TestCodeStatement testCodeStatement = new TestCodeStatement();
                testCodeStatement.setStatement(statement.toString());
                testCodeStatement.setStartNumber(FileUtil.getStartLineNumber(javaVisitor, statement));
                testCodeStatement.setEndNumber(FileUtil.getEndLineNumber(javaVisitor, statement));
                testCodeStatement.setTestItem(testItem);
                if (boundary == 0 || boundary < methodInfo.getTestCode().getStartNumber() || testCodeStatement.getStartNumber() <= boundary) {
                    testCodeStatements.add(testCodeStatement);
                }
        });
        return testCodeStatements;
    }

    public int getLineNumber(TestItem testItem) {
        if (testItem.getStackTrace() != null) {
            String[] st = testItem.getStackTrace().split("\n");
            for (int i = st.length - 1; i >= 0; i--) {
                if (testItem.getClassName() != null && testItem.getMethodName() != null && st[i].contains(testItem.getClassName()) && st[i].contains(testItem.getMethodName())) {
                    Pattern pattern = Pattern.compile(":(\\d+)\\)");
                    Matcher matcher = pattern.matcher(st[i]);
                    if (matcher.find()) {
                        return Integer.parseInt(matcher.group(1));
                    }
                }
            }
        }
        String msg = testItem.getErrorMessage();
        if (msg != null) {
            Pattern pattern = Pattern.compile(":(\\d+)");
            Matcher matcher = pattern.matcher(msg);
            if (matcher.find()) {
                return Integer.parseInt(matcher.group(1));
            }
        }
        return 0;
    }
}

@Data
@AllArgsConstructor
@NoArgsConstructor
class FrameInfo {
    private String packageName;
    private String className;
    private String methodName;
    private String fileName;
    private int num;
}

@Data
@AllArgsConstructor
class MethodInfo {
    private TestCode testCode;
    private MethodDeclaration methodDeclaration;
    private JavaVisitor javaVisitor;
}