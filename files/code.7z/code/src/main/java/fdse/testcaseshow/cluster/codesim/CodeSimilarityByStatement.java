package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.model.TestCodeStatement;
import fdse.testcaseshow.model.TestItem;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;

public class CodeSimilarityByStatement extends CodeSimilarity {
    private ITokensDuplication tokensDuplication;
    private IStatementMatch iStatementMatch;
    private IStatementWeight iStatementWeight;

    public CodeSimilarityByStatement(List<TestItem> testItems, Collection<JavaFileToken> javaFileTokens, Coefficient coefficient, ITokensDuplication tokensDuplication, IStatementMatch iStatementMatch, IStatementWeight iStatementWeight) {
        super(testItems, javaFileTokens, coefficient);
        this.tokensDuplication = tokensDuplication;
        this.iStatementMatch = iStatementMatch;
        this.iStatementWeight = iStatementWeight;
    }

    public boolean isMatch(Collection<String> statementTokens, Collection<Collection<String>> statementTokensList) {
        return iStatementMatch.isMatch(statementTokens, statementTokensList, CodeSimilarity.getDistanceMap(this.testCaseId), coefficient.getMatchThreshold(), coefficient.getCStatement());
    }

    public Collection<Collection<String>> getStatementTokensList(Collection<StatementInfo> statementInfos) {
        Collection<Collection<String>> statementTokensList = new ArrayList<>();
        for (StatementInfo statementInfo : statementInfos) {
            statementTokensList.add(statementInfo.getTokens());
        }
        return statementTokensList;
    }

    public void setMatch(Collection<StatementInfo> statementInfos, Collection<Collection<String>> statementTokensList) {
        for (StatementInfo statementInfo : statementInfos) {
            boolean isMatch = isMatch(statementInfo.getTokens(), statementTokensList);
            statementInfo.setMatch(isMatch);
        }
    }

    public void setBothMatch(Collection<StatementInfo> statementInfosA, Collection<StatementInfo> statementInfosB) {
        Collection<Collection<String>> statementTokensListB = getStatementTokensList(statementInfosB);
        Collection<Collection<String>> statementTokensListA = getStatementTokensList(statementInfosA);
        /*
        Collection<String> collection = new HashSet<>();
        statementTokensListA.forEach(collection::addAll);
        statementTokensListB.forEach(collection::addAll);
        */
        setMatch(statementInfosA, statementTokensListB);
        setMatch(statementInfosB, statementTokensListA);
    }

    public Collection<StatementInfo> getStatementInfos(TestItem testItem) {
        Collection<StatementInfo> statementInfos = new ArrayList<>();
        Collection<TestCodeStatement> testCodeStatements = CodeSimilarity.getTestCodeStatements(testItem);
        for (TestCodeStatement testCodeStatement : testCodeStatements) {
            StatementInfo statementInfo = new StatementInfo();
            Collection<String> statementTokens = CodeSimilarity.getStatementTokens(testCodeStatement);
            statementTokens = tokensDuplication.processTokens(statementTokens);
            statementInfo.setTokens(statementTokens);
            statementInfos.add(statementInfo);
        }
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(this.testCaseId);
        String methodName = testItem.getMethodName();
        if (distanceMap.get(methodName) != null) {
            StatementInfo methodNameStatementInfo = new StatementInfo();
            methodNameStatementInfo.setTokens(Arrays.asList(methodName));
            statementInfos.add(methodNameStatementInfo);
        }

        return statementInfos;
    }

    public void setStatementInfoWeight(StatementInfo statementInfo) {
        iStatementWeight.setStatementInfoWeight(statementInfo, CodeSimilarity.getDistanceMap(this.testCaseId), coefficient);
    }

    public void setStatementInfosWeight(Collection<StatementInfo> statementInfos) {
        for (StatementInfo statementInfo : statementInfos) {
            setStatementInfoWeight(statementInfo);
        }
    }

    public double getSimByStatement(TestItem tiA, TestItem tiB) {
        Collection<StatementInfo> statementInfosA = getStatementInfos(tiA);
        Collection<StatementInfo> statementInfosB = getStatementInfos(tiB);
        setBothMatch(statementInfosA, statementInfosB);
        setStatementInfosWeight(statementInfosA);
        setStatementInfosWeight(statementInfosB);
        statementInfosA.addAll(statementInfosB);
        int dividend = 0;
        int divisor = 0;
        for (StatementInfo statementInfo : statementInfosA) {
            if (statementInfo.isMatch() == true)
                dividend += statementInfo.getWeight();
            divisor += statementInfo.getWeight();
        }
        return 1.0 * dividend / divisor;
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {
        return getSimByStatement(tiA, tiB);
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class StatementInfo {
        private Collection<String> tokens;
        private double weight = 0.0;
        private boolean isMatch = false;
    }
}
