package fdse.testcaseshow.log;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreTestItemTask implements Runnable {
    private BlockingQueue<SplitLog.TestItemMap> outQueue;

    public StoreTestItemTask(BlockingQueue<SplitLog.TestItemMap> outQueue) {
        this.outQueue = outQueue;
    }

    private SplitLog.TestItemMap getTestItemMap() {
        SplitLog.TestItemMap testItemMap = null;
        try {
            testItemMap = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testItemMap;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        SplitLog.TestItemMap testItemMap = null;
        Object o = session.createQuery("select max(t.id) from TestItem t").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            try {
                testItemMap = outQueue.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (testItemMap.getTestCaseId() < 0)
                break;
            long testCaseId = testItemMap.getTestCaseId();
            TestCase testCase = session.load(TestCase.class, testCaseId);
            TestItem testItem = testItemMap.getTestItem();
            testItem.setTestCase(testCase);
            id++;
            testItem.setId(id);
            session.save(testItem);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
