package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Quartet;
import org.javatuples.Triplet;

import java.util.List;

public class BcubedMetrics {
    public static int correctness(MyDataPoint myDataPointA, MyDataPoint myDataPointB) {
        if (myDataPointA.getCategory() == myDataPointB.getCategory() && myDataPointA.getCluster() == myDataPointB.getCluster())
            return 1;
        return 0;
    }
    public static double bcubedPrecision(MyDataPoint myDataPointA) {
        double sum = 0.0;
        MyCluster cluster = myDataPointA.getCluster();
        for (MyDataPoint myDataPointB : cluster.getMyDataPoints()) {
            sum += correctness(myDataPointA, myDataPointB);
            // System.out.println(sum);
        }
        // return sum / (cluster.getClusterSize() -1);
        return sum / cluster.getClusterSize();
    }

    public static double bcubedRecall(MyDataPoint myDataPointA) {
        double sum = 0.0;
        MyCluster category = myDataPointA.getCategory();
        for (MyDataPoint myDataPointB : category.getMyDataPoints()) {
            sum += correctness(myDataPointA, myDataPointB);
        }
        return sum / category.getClusterSize();
    }

    public static double bcubedPrecision(List<MyDataPoint> myDataPoints, int N) {
        double sum = 0.0;
        for (MyDataPoint myDataPoint : myDataPoints) {
            sum += bcubedPrecision(myDataPoint);
        }
        return sum / N;
    }

    public static double bcubedRecall(List<MyDataPoint> myDataPoints, int N) {
        double sum = 0.0;
        for (MyDataPoint myDataPoint : myDataPoints) {
            sum += bcubedRecall(myDataPoint);
        }
        return sum / N;
    }

    public static double getFMeasure(double precison, double recall) {
        return 2 * precison * recall / (precison + recall);
    }

    public static Triplet<Double, Double, Double> getBcubedMetrics(List<Cluster> ahClusters) {
        Quartet<List<MyCluster>, List<MyCluster>, List<MyDataPoint>, Integer> quartet = ClusterEvaluation.clusterListToMyDataPointList(ahClusters);
        List<MyDataPoint> myDataPoints = quartet.getValue2();
        int N = quartet.getValue3();
        double bcubedPrecision = bcubedPrecision(myDataPoints, N);
        double bcubedRecall = bcubedRecall(myDataPoints, N);
        double bcubedFMeasure = getFMeasure(bcubedPrecision, bcubedRecall);
        return Triplet.with(bcubedPrecision, bcubedRecall, bcubedFMeasure);
    }
}
