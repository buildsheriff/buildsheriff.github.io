package fdse.testcaseshow.log;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestLog;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class CutLog {
    private BlockingQueue<TestCase> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<CaseLogMap> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 20;

    public CutLog() {
    }

    private void clearTestLog() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete TestLog";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            int autoIncrement = session.createSQLQuery("ALTER TABLE test_logs AUTO_INCREMENT = 1").executeUpdate();

            tx.commit();
        }
    }

    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new ExtractTestInfoTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }
    public void run() {
        // clearTestLog();
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreTestLogTask(outQueue));
        initializeThreads(threads, storeThread);

        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id >= 0", TestCase.class);
            List<TestCase> testCases = query.list();
            System.out.println(testCases.size());
            // Transaction tx = session.beginTransaction();
            for (TestCase testCase : testCases) {
                try {
                    inQueue.put(testCase);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                }
            }

            for (int i = 0; i < THREAD_NUMBER; i++) {
                TestCase sentry = new TestCase();
                sentry.setId(-1L);
                try {
                    inQueue.put(sentry);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            threads.forEach(thread -> {
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            try {
                CaseLogMap caseLogMap = new CaseLogMap(null, null);
                outQueue.put(caseLogMap);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                System.out.println(storeThread);
                storeThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // tx.commit();
        }
    }
    @Data
    @AllArgsConstructor
    public static class CaseLogMap {
        private TestCase testCase;
        private TestLog testLog;
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        new CutLog().run();
        Instant end = Instant.now();
        System.out.println("" + Duration.between(start, end));
    }
}
