package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.*;
import fdse.testcaseshow.cluster.evaluation.ExceptionSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.code.ExtractJavaFile;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class EqualExceptionSimilarity extends AHCluster {

    public EqualExceptionSimilarity(List<DataPoint> dataPoints) {
        super(dataPoints, 0.5);
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {

        if (testItem1.getClassName() != null && testItem1.getMethodName() != null && testItem2.getClassName() != null && testItem2.getMethodName() != null
                && testItem1.getClassName().equals(testItem2.getClassName())
                && testItem1.getMethodName().equals(testItem2.getMethodName())) {
            return 1.0;
        }

        String msg1 = ExceptionSimilarity.getExceptionMessage(testItem1);
        String msg2 = ExceptionSimilarity.getExceptionMessage(testItem2);
        if (msg1 == null || msg2 == null)
            return 0.0;

        if (msg1.equals(msg2)) {
            return 1.0;
        } else {
            return 0.0;
        }
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new EqualExceptionSimilarity(dataPoints).startCluster();
    }

    public static void run() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.EQUALEXCEPTIONSIMILARITY, true, null)) {
                ResultSummary resultSummary = new ExceptionSimilarityResultSummary(new ExceptionSimilarity.Coefficient(1.0));
                for (TestCase testCase : testCases) {
                    System.out.println(testCase.getId());
                    List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                    List<Cluster> clusters = EqualExceptionSimilarity.clusterBuild(selectedTestItems);
                    resultSummary.addSingleResult(testCase, clusters, true);
                }
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws IOException {
        EqualExceptionSimilarity.run();
    }
}
