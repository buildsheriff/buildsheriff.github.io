package fdse.testcaseshow.code;

import fdse.testcaseshow.model.FileToFile;
import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.util.FileUtil;
import org.eclipse.jdt.core.dom.ImportDeclaration;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.*;
import java.util.concurrent.BlockingQueue;

public class JavaFileLinkTask implements Runnable {
    private BlockingQueue<JavaFile> inQueue;
    private BlockingQueue<FileToFile> outQueue;
    public JavaFileLinkTask(BlockingQueue<JavaFile> inQueue, BlockingQueue<FileToFile> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }

    private JavaFile getJavaFile() {
        JavaFile javaFile = null;
        try {
            javaFile = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return javaFile;
    }

    private void putFileToFile(FileToFile fileToFile) {
        try {
            outQueue.put(fileToFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public JavaVisitor getJavaVisitor(String relativeFilePath) {
        String absoluteFilePath = FileUtil.getFileAbsolutePath(relativeFilePath);
        return FileUtil.getJavaFileInfo(absoluteFilePath);
    }

    public List<String> getPackageNames(JavaVisitor javaVisitor) {
        Set<String> packageNames = new LinkedHashSet<>();
        packageNames.add(javaVisitor.getPackageName());
        Set<ImportDeclaration> imports = javaVisitor.getImports();
        for (ImportDeclaration i : imports) {
            if (i.isOnDemand() && i.isStatic() == false) {
                packageNames.add(i.getName().getFullyQualifiedName());
            }
        }
        return new ArrayList<String>(packageNames);
    }

    public List<String> getClassNames(JavaVisitor javaVisitor) {
        Set<String> classNames = new LinkedHashSet<>();
        Set<ImportDeclaration> imports = javaVisitor.getImports();
        for (ImportDeclaration i : imports) {
            if (i.isStatic()) {
                if (i.isOnDemand()) {
                    classNames.add(i.getName().getFullyQualifiedName());
                } else {
                    String tmpName = i.getName().getFullyQualifiedName();
                    classNames.add(FileUtil.extractClassNameFromStaticImport(tmpName));
                }

            } else {
                if (i.isOnDemand()) {
                } else {
                    classNames.add(i.getName().getFullyQualifiedName());
                }
            }
        }
        return new ArrayList<String>(classNames);
    }

    List<JavaFile> getUsedJavaFiles(Session session, long id, long testCaseId, List<String> packageNames, List<String> classNames) {
        String query = "select j from JavaFile j join j.typeNames t where j.id != :id " +
                "and j.testCase.id = :testCaseId " +
                "and (j.packageName in (:pnlist) or t in (:tnlist))";
        Query<JavaFile> q = session.createQuery(query, JavaFile.class);
        q.setParameter("id", id).setParameter("testCaseId", testCaseId).setParameterList("pnlist", packageNames).setParameterList("tnlist", classNames);
        return q.list();
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        while (true) {
            JavaFile javaFile = getJavaFile();
            if (javaFile.getId() < 0)
                break;
            long id = javaFile.getId();
            long testCaseId = javaFile.getTestCase().getId();
            JavaVisitor visitor = getJavaVisitor(javaFile.getFilePath());
            List<String> packageNames = getPackageNames(visitor);
            List<String> classNames = getClassNames(visitor);
            List<JavaFile> usedJavaFiles = getUsedJavaFiles(session, id, testCaseId, packageNames, classNames);
            Set<Long> usedIdSet = new LinkedHashSet<>();
            for (JavaFile jf : usedJavaFiles) {
                usedIdSet.add(jf.getId());
            }

            for (Long usedId : usedIdSet) {
                FileToFile fileToFile = new FileToFile();
                fileToFile.setUsingId(id);
                fileToFile.setUsedId(usedId);
                putFileToFile(fileToFile);
            }
        }
        session.close();
    }
}
