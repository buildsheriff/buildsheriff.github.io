package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.*;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "java_files")
public class JavaFile {
    @Id
    private long id;

    @Column(name = "file_path")
    private String filePath;

    @Column(name = "complete_file_name")
    private String completeFileName;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "package_name")
    private String packageName;

    @Column(name = "changed")
    private Boolean changed;

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
            name = "java_file_type_names",
            joinColumns = @JoinColumn(name = "java_file_id")
    )
    @Column(name = "type_name")
private Collection<String> typeNames = new ArrayList<>();

    @OneToMany(targetEntity = JavaFileDistance.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "javaFile")
    private Collection<JavaFileDistance> distances = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;

    @OneToMany(mappedBy = "javaFile")
    private Collection<TestFrame> testFrames = new ArrayList<>();

    @OneToMany(targetEntity = JavaFileToken.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="javaFile")
    private Collection<JavaFileToken> javaFileTokens = new ArrayList<>();
}

