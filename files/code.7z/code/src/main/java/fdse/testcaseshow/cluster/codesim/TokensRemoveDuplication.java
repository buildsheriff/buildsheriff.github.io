package fdse.testcaseshow.cluster.codesim;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class TokensRemoveDuplication implements ITokensDuplication {
    private volatile static TokensRemoveDuplication tokensRemoveDuplication;
    private TokensRemoveDuplication() { }
    public static TokensRemoveDuplication getInstance() {
        if (tokensRemoveDuplication == null) {
            synchronized (TokensRemoveDuplication.class) {
                if (tokensRemoveDuplication == null) {
                    tokensRemoveDuplication = new TokensRemoveDuplication();
                }
            }
        }
        return tokensRemoveDuplication;
    }

    @Override
    public Collection<String> processTokens(Collection<String> collection) {
        Set<String> set = new HashSet<>(collection);
        return set;
    }
}
