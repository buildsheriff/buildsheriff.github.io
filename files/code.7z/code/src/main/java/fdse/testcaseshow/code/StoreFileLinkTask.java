package fdse.testcaseshow.code;

import fdse.testcaseshow.model.FileToFile;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreFileLinkTask implements Runnable {
    private BlockingQueue<FileToFile> outQueue;

    public StoreFileLinkTask(BlockingQueue<FileToFile> outQueue) {
        this.outQueue = outQueue;
    }

    private FileToFile getFileToFile() {
        FileToFile fileToFile = null;
        try {
            fileToFile = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return fileToFile;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        FileToFile fileToFile = null;
        Object o = session.createQuery("select max(f.id) from FileToFile f").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            fileToFile = getFileToFile();
            if (fileToFile.getUsingId() < 0)
                break;
            id++;
            fileToFile.setId(id);
            session.save(fileToFile);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
