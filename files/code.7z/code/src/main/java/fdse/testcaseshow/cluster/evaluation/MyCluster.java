package fdse.testcaseshow.cluster.evaluation;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MyCluster {
    @Getter
    private List<MyDataPoint> myDataPoints = new ArrayList<>();
    @Getter
    private int myClusterId;

    public MyCluster(int myClusterId) {
        this.myClusterId = myClusterId;
    }

    public int getClusterSize() { return myDataPoints.size(); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MyCluster myCluster = (MyCluster) o;
        return myClusterId == myCluster.myClusterId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(myClusterId);
    }
}
