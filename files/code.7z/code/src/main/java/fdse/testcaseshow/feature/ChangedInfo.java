package fdse.testcaseshow.feature;

import com.github.gumtreediff.actions.EditScript;
import com.github.gumtreediff.actions.EditScriptGenerator;
import com.github.gumtreediff.actions.SimplifiedChawatheScriptGenerator;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.actions.model.Delete;
import com.github.gumtreediff.actions.model.Insert;
import com.github.gumtreediff.actions.model.Move;
import com.github.gumtreediff.actions.model.TreeDelete;
import com.github.gumtreediff.actions.model.TreeInsert;
import com.github.gumtreediff.actions.model.Update;
import com.github.gumtreediff.client.Run;
import com.github.gumtreediff.gen.TreeGenerators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.Tree;
import fdse.testcaseshow.model.ChangedFile;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.FileUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.javatuples.Quintet;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ChangedInfo {

    public static String TYPE_DECLARATION_MARK = "TypeDeclaration";
    public static String METHOD_DECLARATION_MARK = "MethodDeclaration";
    public static String FIELD_DECLARATION_MARK = "FieldDeclaration";

    private TestCase testCase;
    private List<ChangedFileInfo> changedFileInfos;
    private List<Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript>> diffFileASTInfos;
    private Set<Token> changedNames;
    private Set<Token> changedJavaNames;
    private Set<Token> changedResourceNames;
    private Set<Token> changedClassNames;
    private Set<Token> changedMethodNames;
    private Set<Token> changedFieldNames;

    public ChangedInfo(long id, Session session) {
        Query<TestCase> query = session.createQuery("from TestCase where id = :id", TestCase.class);
        query.setParameter("id", id);
        this.testCase = query.getSingleResult();
        run();
    }

    public ChangedInfo(TestCase testCase) {
        this.testCase = testCase;
        run();
    }

    public void run() {
        setDiffFileInfos();
        try {
            setDiffFileASTInfos();
        } catch (IOException e) {
            System.err.println("提取文件diff信息发生错误");
            e.printStackTrace();
        }
    }

    public List<ChangedFileInfo> getDiffFileInfos() {
        if (changedFileInfos == null) {
            setDiffFileInfos();
        }
        return changedFileInfos;
    }

    public void setDiffFileInfos() {
        changedFileInfos = new ArrayList<>();
        String preCommit = testCase.getPreCommit().trim();
        String currentCommit = testCase.getCurrentCommit().trim();
        String preRepoPath = FileUtil.getRepoPath(preCommit);
        String currentRepoPath = FileUtil.getRepoPath(currentCommit);
        if (preRepoPath == null || currentRepoPath == null) {
            System.out.println(testCase.getId() + "找不到代码仓库: ");
            return;
        }
        for (ChangedFile changedFile : testCase.getChangedFiles()) {
            String status = changedFile.getStatus();
            String preFilePath = Paths.get(preRepoPath, changedFile.getPreFilePath()).toString();
            String currentFilePath = Paths.get(currentRepoPath, changedFile.getCurrentFilePath()).toString();
            changedFileInfos.add(new ChangedFileInfo(status, preFilePath, currentFilePath));
        }
    }

    public void setDiffFileASTInfos() throws IOException {
        diffFileASTInfos = new ArrayList<>();
        Run.initGenerators();
        for (ChangedFileInfo changedFileInfo : changedFileInfos) {
            Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> astInfo = createASTInfo(changedFileInfo);
            diffFileASTInfos.add(astInfo);
        }
    }

    public List<Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript>> getDiffFileASTInfos() throws IOException {
        if (diffFileASTInfos == null) {
            setDiffFileASTInfos();
        }
        return diffFileASTInfos;
    }

    public Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> createASTInfo(String preFilePath, String currentFilePath, String status) throws IOException {
        if (currentFilePath.endsWith(".java") == false) {
            return Quintet.with(null, null, null, null, null);
        }
        Tree src = null;
        Tree dst = null;
        MappingStore mappings = null;
        EditScript actions = null;

        if (status.equals("modified") || status.equals("renamed")) {
            src = TreeGenerators.getInstance().getTree(preFilePath).getRoot();
            dst = TreeGenerators.getInstance().getTree(currentFilePath).getRoot();
        } else if (status.equals("added")) {
            dst = TreeGenerators.getInstance().getTree(currentFilePath).getRoot();
        } else if (status.equals("removed")) {
            src = TreeGenerators.getInstance().getTree(preFilePath).getRoot();
        }

        if (src != null && dst != null) {
            Matcher defaultMatcher = Matchers.getInstance().getMatcher();
            mappings = defaultMatcher.match(src, dst);
            EditScriptGenerator editScriptGenerator = new SimplifiedChawatheScriptGenerator();
            actions = editScriptGenerator.computeActions(mappings);
        }
        return Quintet.with(null, src, dst, mappings, actions);
    }

    public Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> createASTInfo(ChangedFileInfo changedFileInfo) throws IOException {
        Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> astInfo = createASTInfo(changedFileInfo.getPreFilePath(), changedFileInfo.getCurrentFilePath(), changedFileInfo.getStatus());
        return astInfo.setAt0(changedFileInfo);
    }

    public Set<Token> getChangedResourceNames() {
        if (changedResourceNames == null) {
            changedResourceNames = new HashSet<>();
            for (ChangedFileInfo changedFileInfo : changedFileInfos) {
                // System.out.println(diffFileInfo.getCurrentFilePath());
                if (changedFileInfo.getCurrentFilePath().endsWith(".txt") || changedFileInfo.getCurrentFilePath().endsWith(".html")) {
                    changedResourceNames.add(Token.create(FileUtil.getFileName(changedFileInfo.getCurrentFilePath()), TokenType.RESOURCE_NAME, TokenStatus.MODIFIED));
                }
            }
        }
        return changedResourceNames;
    }

    public List<Tree> getTreesOfTypeDeclarationMethodDeclarationFieldDeclaration(Tree root) {
        List<Tree> trees = new ArrayList<>();
        for (Tree tree : root.preOrder()) {
            if (tree.getType().toString().equals(TYPE_DECLARATION_MARK) || tree.getType().toString().equals(METHOD_DECLARATION_MARK) || tree.getType().toString().equals(FIELD_DECLARATION_MARK)) {
                trees.add(tree);
            }
        }
        return trees;
    }

    public List<Tree> getIgnoredTrees(Tree root) {
        List<Tree> trees = new ArrayList<>();
        for (Tree tree : root.preOrder()) {
            if (tree.getType().toString().equals("Javadoc") || tree.getType().toString().equals("ImportDeclaration")) {
                trees.add(tree);
            }
        }
        return trees;
    }

    public Set<Token> getTokensOfAddedJavaFile(Tree dst) {
        Set<Token> set = new HashSet<>();
        if (dst == null)
            return set;
        for (Tree tree : dst.preOrder()) {
            if (tree.getType().toString().equals(TYPE_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.CLASS_NAME, TokenStatus.ADDED));
            } else if (tree.getType().toString().equals(METHOD_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.METHOD_NAME, TokenStatus.ADDED));
            } else if (tree.getType().toString().equals(FIELD_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.FIELD_NAME, TokenStatus.ADDED));
            }
        }
        return set;
    }
    public Set<Token> getTokensOfDeletedJavaFile(Tree src) {
        Set<Token> set = new HashSet<>();
        if (src == null)
            return set;
        for (Tree tree : src.preOrder()) {
            if (tree.getType().toString().equals(TYPE_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.CLASS_NAME, TokenStatus.DELETED));
            } else if (tree.getType().toString().equals(METHOD_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.METHOD_NAME, TokenStatus.DELETED));
            } else if (tree.getType().toString().equals(FIELD_DECLARATION_MARK)) {
                set.add(Token.create((String) tree.getMetadata("name"), TokenType.FIELD_NAME, TokenStatus.DELETED));
            }
        }
        return set;
    }

    public Map<Tree, TokenStatus> getTreesMapOfActions(MappingStore mappings, List<Action> selectedActions) {
        // List<Tree> changedDstTrees = new ArrayList<>();
        Map<Tree, TokenStatus> map = new HashMap<>();
        for (Action action : selectedActions) {
            if (action.getClass() == Insert.class) {
                map.put(action.getNode(), TokenStatus.ADDED);
                // changedDstTrees.add(action.getNode());
            } else if (action.getClass() == TreeInsert.class) {
                map.put(action.getNode(), TokenStatus.ADDED);
                // changedDstTrees.add(action.getNode());
            } else if (action.getClass() == Update.class) {
                map.put(mappings.getDstForSrc(action.getNode()), TokenStatus.MODIFIED);
                // changedDstTrees.add(mappings.getDstForSrc(action.getNode()));
            } else if (action.getClass() == Move.class) {
                Move move = (Move) action;
                map.put(mappings.getDstForSrc(move.getNode()), TokenStatus.MODIFIED);
                map.put(mappings.getDstForSrc(move.getParent()), TokenStatus.MODIFIED);
                // changedDstTrees.add(mappings.getDstForSrc(move.getNode()));
                // changedDstTrees.add(mappings.getDstForSrc(move.getParent()));
            } else if (action.getClass() == Delete.class) {
                map.put(mappings.getDstForSrc(action.getNode().getParent()), TokenStatus.MODIFIED);
                // changedDstTrees.add(mappings.getDstForSrc(action.getNode().getParent()));
            } else if (action.getClass() == TreeDelete.class) {
                map.put(mappings.getDstForSrc(action.getNode().getParent()), TokenStatus.MODIFIED);
                map.put(action.getNode(), TokenStatus.DELETED);
                // changedDstTrees.add(mappings.getDstForSrc(action.getNode().getParent()));
            }
        }
        // changedDstTrees.removeIf(i -> i == null);
        map.remove(null);
        return map;
    }

    public Token getTokenByCompareRangeOfTrees(Tree tree, Map.Entry<Tree, TokenStatus> entry) {
        Tree changedTree = entry.getKey();
        TokenStatus status = entry.getValue();
        if (tree.getPos() > changedTree.getPos() || tree.getEndPos() < changedTree.getEndPos())
            return null;
        TokenStatus tokenStatus = TokenStatus.MODIFIED;
        if (tree.getPos() == changedTree.getPos() && tree.getEndPos() == changedTree.getEndPos()) {
            if (status == TokenStatus.ADDED) {
                tokenStatus = TokenStatus.ADDED;
            } else if (status == TokenStatus.DELETED) {
                tokenStatus = TokenStatus.DELETED;
            }
        } else {
            tokenStatus = TokenStatus.MODIFIED;
        }
        TokenType tokenType = null;
        if (tree.getType().toString().equals(TYPE_DECLARATION_MARK)) {
            tokenType = TokenType.CLASS_NAME;
        } else if (tree.getType().toString().equals(METHOD_DECLARATION_MARK)) {
            tokenType = TokenType.METHOD_NAME;
        } else if (tree.getType().toString().equals(FIELD_DECLARATION_MARK)) {
            tokenType = TokenType.FIELD_NAME;
        }
        return Token.create((String) tree.getMetadata("name"), tokenType, tokenStatus);
    }

    public List<Action> getValidatedActions(Tree src, Tree dst, MappingStore mappings, EditScript editScript) {
        List<Action> selectedActions = new ArrayList<>();
        List<Tree> ignoredSrcTrees = getIgnoredTrees(src);
        List<Tree> ignoredDstTrees = getIgnoredTrees(dst);
        for (Action action : editScript) {
            List<Tree> changedSrcTrees = new ArrayList<>();
            List<Tree> changedDstTrees = new ArrayList<>();
            if (action.getClass() == Insert.class) {
                changedDstTrees.add(action.getNode());
            } else if (action.getClass() == TreeInsert.class) {
                changedDstTrees.add(action.getNode());
            } else if (action.getClass() == Update.class){
                changedSrcTrees.add(action.getNode());
            } else if (action.getClass() == Move.class){
                Move move = (Move) action;
                changedSrcTrees.add(move.getNode());
                changedSrcTrees.add(move.getParent());
            } else if (action.getClass() == Delete.class) {
                changedSrcTrees.add(action.getNode());
            } else if (action.getClass() == TreeDelete.class) {
                changedSrcTrees.add(action.getNode());
            }
            boolean flag = true;
            for (Tree ignoredTree : ignoredSrcTrees) {
                for (Tree changedTree : changedSrcTrees) {
                    if (changedTree.getPos() >= ignoredTree.getPos() && changedTree.getEndPos() <= ignoredTree.getEndPos()) {
                        flag = false;
                        break;
                    }
                }
            }
            for (Tree ignoredTree : ignoredDstTrees) {
                for (Tree changedTree : changedDstTrees) {
                    if (changedTree.getPos() >= ignoredTree.getPos() && changedTree.getEndPos() <= ignoredTree.getEndPos()) {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag) {
                selectedActions.add(action);
            }
        }
        return selectedActions;
    }

    public Set<Token> getTokensOfModifiedJavaFile(Tree src, Tree dst, MappingStore mappings, List<Action> selectedActions) {
        Set<Token> set = new HashSet<>();
        List<Tree> srcTrees = getTreesOfTypeDeclarationMethodDeclarationFieldDeclaration(src);
        List<Tree> dstTrees = getTreesOfTypeDeclarationMethodDeclarationFieldDeclaration(dst);
        Map<Tree, TokenStatus> map = getTreesMapOfActions(mappings, selectedActions);
        for (Tree tree : dstTrees) {
            for (Map.Entry<Tree, TokenStatus> entry : map.entrySet()) {
                if (entry.getValue() == TokenStatus.DELETED) {

                } else {
                    set.add(getTokenByCompareRangeOfTrees(tree, entry));
                }
            }
        }
        for (Tree tree : srcTrees) {
            for (Map.Entry<Tree, TokenStatus> entry : map.entrySet()) {
                if (entry.getValue() == TokenStatus.DELETED) {
                    set.add(getTokenByCompareRangeOfTrees(tree, entry));
                } else {

                }
            }
        }
        set.remove(null);
        return set;
    }

    public Set<Token> getTokensOfModifiedJavaFile(Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> astInfo) {
        List<Action> selectedActions = getValidatedActions(astInfo.getValue1(), astInfo.getValue2(), astInfo.getValue3(), astInfo.getValue4());
        return getTokensOfModifiedJavaFile(astInfo.getValue1(), astInfo.getValue2(), astInfo.getValue3(), selectedActions);
    }

    public Set<Token> getTokensOfJavaFile(Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> astInfo) {
        Set<Token> set = new HashSet<>();
        if (astInfo.getValue0().getStatus().equals("added")) {
            Tree dst = astInfo.getValue2();
            set.addAll(getTokensOfAddedJavaFile(dst));
        } else if (astInfo.getValue0().getStatus().equals("modified") || astInfo.getValue0().getStatus().equals("renamed")) {
            set.addAll(getTokensOfModifiedJavaFile(astInfo));
        } else if (astInfo.getValue0().getStatus().equals("removed")) {
            set.addAll(getTokensOfDeletedJavaFile(astInfo.getValue1()));
        }
        return set;
    }

    public Set<Token> getChangedJavaTokens() {
        if (changedJavaNames == null) {
            changedJavaNames = new HashSet<>();
            for (Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> astInfo : diffFileASTInfos) {
                if (astInfo.getValue0().getCurrentFilePath().endsWith(".java") == true) {
                    changedJavaNames.addAll(getTokensOfJavaFile(astInfo));
                }
            }
        }
        return changedJavaNames;
    }

    public Set<Token> getChangedClassTokens() {
        if (changedClassNames == null) {
            changedClassNames = new HashSet<>();
            getChangedJavaTokens().forEach(item -> {
                if (item.getType() == TokenType.CLASS_NAME) {
                    changedClassNames.add(item);
                }
            });
        }
        return changedClassNames;
    }

    public Set<Token> getChangedMethodTokens() {
        if (changedMethodNames == null) {
            changedMethodNames = new HashSet<>();
            getChangedJavaTokens().forEach(item -> {
                if (item.getType() == TokenType.METHOD_NAME) {
                    changedMethodNames.add(item);
                }
            });
        }
        return changedMethodNames;
    }

    public Set<Token> getChangedFieldTokens() {
        if (changedFieldNames == null) {
            changedFieldNames = new HashSet<>();
            getChangedJavaTokens().forEach(item -> {
                if (item.getType() == TokenType.FIELD_NAME) {
                    changedFieldNames.add(item);
                }
            });
        }
        return changedFieldNames;
    }

    public Set<Token> getChangedTokens() {
        if (changedNames == null) {
            changedNames = new HashSet<>();
            getChangedJavaTokens().forEach(item -> changedNames.add(item));
            getChangedResourceNames().forEach(item -> changedNames.add(item));
        }
        return changedNames;
    }

}
