package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Rebucket {
    public static List<MatchFrame> LCS(List<String> xList, List<String> yList) {
        List<MatchFrame> lcs = new ArrayList<>();
        int xLength = xList.size();
        int yLength = yList.size();
        int[][] cTable = new int[xLength + 1][yLength + 1];
        for(int i = 0; i < xLength + 1; i++) {
            cTable[i][0] = 0;
        }
        for(int j = 0; j < yLength + 1; j++) {
            cTable[0][j] = 0;
        }

        for(int i = 1; i < xLength + 1; i++) {
            for(int j = 1; j < yLength + 1; j++) {
                int x = i - 1;
                int y = j - 1;
                if(xList.get(x).equals(yList.get(y))) {
                    cTable[i][j] = cTable[i - 1][j - 1] + 1;
                    lcs.add(new MatchFrame(x, y, xList.get(x)));
                } else if(cTable[i - 1][j] >= cTable[i][j - 1]) {
                    cTable[i][j] = cTable[i - 1][j];
                } else {
                    cTable[i][j] = cTable[i][j - 1];
                }
            }
        }
        return lcs;
    }

    public  static void printLSC(List<String> xList, List<String> yList, List<MatchFrame> lcs) {
        int[] xMatch = lcs.stream().mapToInt(e -> e.getX()).toArray();
        int[] yMatch = lcs.stream().mapToInt(e -> e.getY()).toArray();
        int length = xList.size() >= yList.size() ? xList.size() : yList.size();
        for (int i = 0; i < length; i++) {
            final int j = i;
            if (i < xList.size()) {
                System.out.printf("%80s", xList.get(i));
            } else {
                System.out.printf("%80s", "");
            }
            if (ArrayUtils.contains(xMatch, i)) {
                System.out.print("##");
            }

            if (i < yList.size()) {
                System.out.printf("%80s", yList.get(i));
            } else {
                System.out.printf("%80s", "");
            }

            if (ArrayUtils.contains(yMatch, i)) {
                System.out.print("##");
            }
            System.out.println();
        }
    }

    public static double getSimilarity(double coC, double coO, List<String> aList, List<String> bList) {
        List<String> aFrames = aList;
        List<String> bFrames = bList;
        List<MatchFrame> matchFrames = LCS(aFrames, bFrames);
        int l = aFrames.size() <= bFrames.size() ? aFrames.size() : bFrames.size();
        double Q = 0.0;
        for(MatchFrame m : matchFrames) {
            int coCV = m.getX() <= m.getY() ? m.getX() : m.getY();
            int coOV = Math.abs(m.getX() - m.getY());
            Q += Math.exp(-coC * coCV) * Math.exp(-coO * coOV);
        }
        double denominator = 0.0;
        for(int i = 0; i <= l; i++) {
            denominator += Math.exp(-coC * i);
        }
        return Q / denominator;
    }

    public static double getSimilarity(double coC, double coO, TestItem tiA, TestItem tiB) {
        List<String> aList = getFrameList(tiA);
        List<String> bList = getFrameList(tiB);
        if (aList.size() == 0 || bList.size() == 0)
            return 0.0;

        double sim = getSimilarity(coC, coO, aList, bList);
        return sim;
    }

    public static List<String> getFrameList(TestItem testItem) {
        if (testItem.getStackTrace() == null)
            return new ArrayList<>();
        List<String> list = Arrays.asList(testItem.getStackTrace().split("\\n"));
        List<String> result = new ArrayList<>();
        list.forEach(f -> {
            String s = f.trim();
            if (s.startsWith("at") ) {
                result.add(s);
            }
        });
        return result;
    }

    @Data
    @AllArgsConstructor
    public static class MatchFrame {
        private int x;
        private int y;
        private String frame;
    }
    public static class RebucketTask implements Runnable {

        private double coC;
        private double coO;
        private double sMax;
        private List<TestCase> testCases;
        public RebucketTask(double coC, double coO, double sMax, List<TestCase> testCases) {
            this.coC = coC;
            this.coO = coO;
            this.sMax = sMax;
            this.testCases = testCases;
        }

        @Override
        public void run() {
            int count = 0;
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                List<TestItem> selectedTestItems = new ArrayList<>();
                testItems.forEach(e -> {
                    if (e.isCrash() && e.getStackTrace().length() > 5)
                        selectedTestItems.add(e);
                });
                List<Cluster> clusters = AHClusterOld.clusterBuild(coC, coO, sMax, selectedTestItems);
                if (clusters.size() == testCase.getCrashClusterNum())
                    count++;
            }
        }
    }

    public static void run1() {
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id > 200 and crashClusterNum >= 1", TestCase.class);
            List<TestCase> testCases = query.list();
            for (TestCase testCase : testCases) {
                testCase.getTestItems().size();
            }
            System.out.println("start");
            ExecutorService service = Executors.newFixedThreadPool(50);
            for (double coC = 0; coC <= 2; coC += 0.1) {
                for (double coO = 0; coO <= 2; coO += 0.1) {
                    for (double cMax = 0; cMax <= 1; cMax += 0.01) {
                        service.submit(new RebucketTask(coC, coO, cMax, testCases));
                    }
                }
            }
            service.shutdown();
        }
    }

    public static boolean stacktraceLegal(List<TestItem> testItems) {
        boolean flag = true;
        for (TestItem testItem : testItems) {
            if (testItem.getStackTrace() == null) {
                flag = false;
                break;
            }
            String[] lines = testItem.getStackTrace().split("\\n");
            boolean atMark = false;
            for (String line : lines) {
                String s = line.trim();
                if (s.startsWith("at")) {
                    atMark = true;
                    break;
                }
            }
            if (atMark == false) {
                flag = false;
            }
        }
        return flag;
    }

    public static void run2(List<TestCase> testCases, double coC, double coO, double sMax) {
        int countOne = 0;
        int countEqualOne = 0;
        int countMore = 0;
        int countEqualMore = 0;
        for (TestCase testCase : testCases) {
            Collection<TestItem> testItems = testCase.getTestItems();
            List<TestItem> selectedTestItems = new ArrayList<>();
            testItems.forEach(e -> {
                if (e.isCrash())
                    selectedTestItems.add(e);
            });
            int clusterNum = Integer.MIN_VALUE;

            if (stacktraceLegal(selectedTestItems)) {
                List<Cluster> clusters = AHClusterOld.clusterBuild(coC, coO, sMax, selectedTestItems);
                clusterNum = clusters.size();
            } else {
            }
            if (testCase.getCrashClusterNum() == null) {

            } else if (testCase.getCrashClusterNum() == 1) {
                countOne += 1;
                if (testCase.getCrashClusterNum() == clusterNum) {
                    countEqualOne++;
                }
            } else if (testCase.getCrashClusterNum() > 1) {
                countMore += 1;
                if (testCase.getCrashClusterNum() == clusterNum) {
                    countEqualMore++;
                }
            }
            if (testCase.getRebucket() != clusterNum) {
                System.out.println(testCase.getId() + "->" + testCase.getCrashClusterNum() + "->" + testCase.getRebucket() + "->" + clusterNum);
            }
        }
        double result = 0.5 * countEqualOne / countOne + 0.5 * countEqualMore / countMore;
        System.out.printf("sMax: %.2f coC: %.2f coO: %.2f result: %.2f countOne: %d countEqualOne: %d countMore: %d countEqualMore: %d\n",
                sMax, coC, coO, result, countOne, countEqualOne, countMore, countEqualMore);
    }

    public static void coeffiecient() {
        Session session = SessionUtil.getSession();
        Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false ", TestCase.class);
        List<TestCase> testCases = query.list();
        run2(testCases, 2.0, 0.30, 0.54);
        session.close();
    }

    public static void main(String[] args) {
        Rebucket.coeffiecient();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private double sMax;
        private double coC;
        private double coO;
    }
}
