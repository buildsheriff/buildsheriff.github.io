package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access= AccessLevel.PUBLIC, force=true)
@Entity
@Table(name = "test_code_statements")
public class TestCodeStatement {
    @Id
    private long id;

    @Column(name = "statement")
    private String statement;

    @Column(name = "start_number")
    private Integer startNumber;

    @Column(name = "end_number")
    private Integer endNumber;

    @ManyToOne
    @JoinColumn(name="test_item_id")
    private TestItem testItem;
}

