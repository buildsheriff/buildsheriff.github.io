package fdse.testcaseshow.cluster.evaluation;

public class NaiveSTSimilarityResultSummary  extends ResultSummary {
    private double sMax;
    public NaiveSTSimilarityResultSummary(double sMax) {
        this.sMax = sMax;
    }
    @Override
    public String toString() {
        String s = String.format("NaiveSTSimilarity parameters\nsMax: %.2f\n", sMax);
        s += super.toString();
        return s;
    }
}
