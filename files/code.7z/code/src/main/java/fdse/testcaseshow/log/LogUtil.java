package fdse.testcaseshow.log;

import fdse.testcaseshow.model.TestFrame;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogUtil {
    public static final Pattern framePattern = Pattern.compile("at (([\\w$]+\\.)*)([\\w$]+)\\.([\\w$<>]+)\\((\\w+\\.java):(\\d+)\\)", Pattern.DOTALL);
    public static final String CLASS_NAME_REGEX = "[a-zA-Z_$][a-zA-Z\\d_$]*";
    public static final String METHOD_NAME_REGEX = "[a-zA-Z0-9_$]+";
    public static final String FULL_CLASS_NAME_REGEX = "([a-zA-Z_$][a-zA-Z\\d_$]*\\.)*[a-zA-Z_$][a-zA-Z\\d_$]*";

    public static void polulateTestFrame(TestFrame testFrame) {
        String frame = testFrame.getFrame().trim();
        Matcher matcher = framePattern.matcher(frame);
        if (matcher.find()) {
            testFrame.setPackageName(matcher.group(1).substring(0, matcher.group(1).length()-1));
            testFrame.setTypeName(matcher.group(3));
            testFrame.setMethodName(matcher.group(4));
            testFrame.setFileName(matcher.group(5));
            testFrame.setLineNum(Integer.parseInt(matcher.group(6)));
        }
    }

    public static List<String> stringToList(String s) {
        return Arrays.asList(s.split("\n"));
    }

    public static void main(String[] args) {
        String s = "at org.apache.commons.pool2.impl.GenericObjectPool.create(GenericObjectPool.java:819)";

        Matcher matcher = framePattern.matcher(s);
        if (matcher.find()) {
            System.out.println(matcher.group(0));
            System.out.println(matcher.group(1));

            System.out.println(matcher.group(2));

            System.out.println(matcher.group(3));

            System.out.println(matcher.group(4));
            System.out.println(matcher.group(5));
            System.out.println(matcher.group(6));

        }
    }
}
