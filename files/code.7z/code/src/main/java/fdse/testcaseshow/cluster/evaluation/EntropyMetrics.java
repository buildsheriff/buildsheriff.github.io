package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Quartet;

import java.util.List;

public class EntropyMetrics {
    public static double getEntropy(List<List<Integer>> clusterList, List<List<Integer>> categoryList, int N) {
        double result = 0.0;
        for (int j = 0; j < clusterList.size(); j++) {
            int nj = clusterList.get(j).size();
            double entropyj = 0.0;
            for (int i = 0; i < categoryList.size(); i++) {
                int ij = ClusterEvaluation.countEqualIntNumInList(categoryList.get(i), j);
                double pij = 1.0 * ij / clusterList.get(j).size();
                if (Math.abs(pij - 0.0) < 0.00001) {

                } else {
                    entropyj += pij * Math.log(pij) / Math.log(2);
                }
            }
            result += nj * entropyj;
        }
        return -1 * result / N;
    }

    public static double getClassEntropy(List<List<Integer>> clusterList, List<List<Integer>> categoryList, int N) {
        double result = 0.0;
        for (int i = 0; i < categoryList.size(); i++) {
            int ni = categoryList.get(i).size();
            double entropyi = 0.0;
            for (int j = 0; j < clusterList.size(); j++) {
                final int clusterId = j;
                int ji = ClusterEvaluation.countEqualIntNumInList(clusterList.get(j), i);
                double pji = 1.0 * ji / categoryList.get(i).size();
                if (Math.abs(pji - 0.0) < 0.00001) {

                } else {
                    entropyi += pji * Math.log(pji) / Math.log(2);
                }
            }
            result += ni * entropyi;
        }
        return -1 * result / N;
    }
    public static double getMutualInformation(List<List<Integer>> clusterList, List<List<Integer>> categoryList, int N) {
        double result = 0.0;
        //System.out.println("clusterList: " + clusterList.size() + " categoryList: " + categoryList.size());
        for (int j = 0; j < clusterList.size(); j++) {
            for (int i = 0; i < categoryList.size(); i++) {
                int clusterSize = clusterList.get(j).size();
                int categorySize = categoryList.get(i).size();
                int intersectionSize = ClusterEvaluation.countEqualIntNumInList(clusterList.get(j), i);
                //System.out.println("clusterSize: " + clusterSize + " categorySize: " + categorySize + " intersectionSize: " + intersectionSize);
                if (intersectionSize == 0) {

                } else {
                    result += 1.0 * intersectionSize / N * Math.log(1.0 * N * intersectionSize / (clusterSize * categorySize)) / Math.log(2);
                }
                //System.out.println(result);

            }
        }
        return result;
    }

    public static double getEntropy(List<List<Integer>> listList, int N) {
        double result = 0.0;
        for (List<Integer> list : listList) {
            double p = 1.0 * list.size() / N;
            result += p * Math.log(p) / Math.log(2);
        }
        return -1.0 * result;
    }

    public static double getVI(List<List<Integer>> clusterList, List<List<Integer>> categoryList, int N) {
        double hA = getEntropy(clusterList, N);
        double hB = getEntropy(categoryList, N);
        return getEntropy(clusterList, N) + getEntropy(categoryList, N) - 2 * getMutualInformation(clusterList, categoryList, N);
    }

    public static Quartet<Double, Double, Double, Double> getEntropyMetrics(List<Cluster> ahClusters) {
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        List<List<Integer>> categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        int N = 0;
        for (List<Integer> cluster : clusterList) {
            N += cluster.size();
        }
        double entropy = getEntropy(clusterList, categoryList, N);
        double classEntropy = getClassEntropy(clusterList, categoryList, N);
        double mutualInformation = getMutualInformation(clusterList, categoryList, N);
        double vi = getVI(clusterList, categoryList, N);
        return Quartet.with(entropy, classEntropy, mutualInformation, vi);
    }

}
