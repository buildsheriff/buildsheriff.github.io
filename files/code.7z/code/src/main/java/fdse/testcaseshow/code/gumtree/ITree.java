package fdse.testcaseshow.code.gumtree;

import org.eclipse.jdt.core.dom.ASTNode;

import java.util.ArrayList;
import java.util.List;

public interface ITree {

    String OPEN_SYMBOL = "[(";
    String CLOSE_SYMBOL = ")]";
    String SEPARATE_SYMBOL = "@@";
    int NO_ID = Integer.MIN_VALUE;
    String NO_LABEL = "";
    int NO_VALUE = -1;


  
    public ArrayList<ITree> getPreOrderTreeNodeList();
    public ArrayList<ITree> getPostOrderTreeNodeList();
    public ArrayList<ITree> getBreadthFirstTreeNodeList();
    void addChild(ITree t);

    int getChildPosition(ITree child);

    ITree getChild(int position);

    List<ITree> getChildren();

    List<ITree> getDescendants();

    void setParent(ITree parent);

    void setParentAndUpdateChildren(ITree parent);
    public void setNodeTypeNumber(int nodeTypeNumber);

    public int getNodeTypeNumber();

    public void setNodeTypeName(String nodeTypeName);

    public String getNodeTypeName();

    public void setNodeLabel(String nodeLabel);

    public String getNodeLabel();

    public void setStartPosition(int startPosition);

    public int getStartPosition();

    public void setLength(int length);

    public int getLength();

    public void setHeight(int height);

    public int getHeight();

    public void setSize(int size);

    public int getSize();

    public void setDepth(int depth);

    public int getDepth();

    public void setId(int id);

    public int getId();

    public void setHash(int hash);

    public int getHash();

    public int getPositionInParent();

    default List<ITree> getParents() {
        List<ITree> parents = new ArrayList<>();
        if (getParent() == null)
            return parents;
        else {
            parents.add(getParent());
            parents.addAll(getParent().getParents());
        }
        return parents;
    }

    public ASTNode getASTNode();
    boolean isLeaf();
    boolean isRoot();

    ITree getParent();
    ITree deepCopy();
    boolean isSameType(ITree t);
    boolean isIsomorphicTo(ITree tree);
    void refresh();
    String toStaticHashString();
    String toShortString();
}
