package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import lombok.*;
import org.javatuples.Quartet;
import org.javatuples.Triplet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class SingleResult {
    private Long id;
    private int length;
    private int expected;
    private int actual;

    private double purity;
    private double inversePurity;
    private double VRFMeasure;

    private double randStatisticR;
    private double jaccardCoefficientJ;
    private double folkesAndMallowsFM;

    private double entropy;
    private double classEntropy;
    private double mutualInformation;
    private double vi;

    private int dist;

    private double bcubedPrecioson;
    private double bcubedRecall;
    private double bcubedFMeasure;

    private List<List<Integer>> clusterList;
    private List<List<TestItem>> testItemListList = new ArrayList<>();

    private boolean ok;

    private static void setSingleResultMetrics(SingleResult singleResult, List<Cluster> ahClusters) {
        setSetMatchingMetrics(singleResult, ahClusters);
        setCountingPairsMetrics(singleResult, ahClusters);
        setEntropyMetrics(singleResult, ahClusters);
        setEditDistance(singleResult, ahClusters);
        setBcubedMetrics(singleResult, ahClusters);

        singleResult.setClusterList(ClusterEvaluation.aHClusterListToClusterList(ahClusters));
        setTestItemListList(singleResult, ahClusters);

        setOKK(singleResult);
    }

    public static void setSetMatchingMetrics(SingleResult singleResult, List<Cluster> ahClusters) {
        Triplet<Double, Double, Double> setMatchingMetrics = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        singleResult.setPurity(setMatchingMetrics.getValue0());
        singleResult.setInversePurity(setMatchingMetrics.getValue1());
        singleResult.setVRFMeasure(setMatchingMetrics.getValue2());
    }

    public static void setCountingPairsMetrics(SingleResult singleResult, List<Cluster> ahClusters) {
        Triplet<Double, Double, Double> countingPairMetrics = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        singleResult.setRandStatisticR(countingPairMetrics.getValue0());
        singleResult.setJaccardCoefficientJ(countingPairMetrics.getValue1());
        singleResult.setFolkesAndMallowsFM(countingPairMetrics.getValue2());
    }

    public static void setEntropyMetrics(SingleResult singleResult, List<Cluster> ahClusters) {
        Quartet<Double, Double, Double, Double> entropyMetrics = EntropyMetrics.getEntropyMetrics(ahClusters);
        singleResult.setEntropy(entropyMetrics.getValue0());
        singleResult.setClassEntropy(entropyMetrics.getValue1());
        singleResult.setMutualInformation(entropyMetrics.getValue2());
        singleResult.setVi(entropyMetrics.getValue3());
    }

    public static void setBcubedMetrics(SingleResult singleResult, List<Cluster> ahClusters) {
        Triplet<Double, Double, Double> bcubedMetrics = BcubedMetrics.getBcubedMetrics(ahClusters);
        singleResult.setBcubedPrecioson(bcubedMetrics.getValue0());
        singleResult.setBcubedRecall(bcubedMetrics.getValue1());
        singleResult.setBcubedFMeasure(bcubedMetrics.getValue2());

    }

    public static void setEditDistance(SingleResult singleResult, List<Cluster> ahClusters) {
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        singleResult.setDist(dist);
    }

    public static void setTestItemListList(SingleResult singleResult, List<Cluster> ahClusters) {
        for (Cluster cluster : ahClusters) {
            List<TestItem> list = new ArrayList<>();
            for (DataPoint dataPoint : cluster.getDataPoints()) {
                list.add(dataPoint.getTestItem());
            }
            singleResult.getTestItemListList().add(list);
        }
    }

    public static void setOKK(SingleResult singleResult) {
        boolean flag = true;
        List<List<Integer>> clusterList = singleResult.getClusterList();
        for (List<Integer> list : clusterList) {
            Set<Integer> set = new HashSet<>(list);
            if (set.size() > 1) {
                flag = false;
                break;
            }
        }
        if (singleResult.getExpected() != singleResult.getActual()) {
            flag = false;
        }
        singleResult.setOk(flag);
    }
    public static SingleResult getSingleResult(TestCase testCase, List<Cluster> ahClusters, boolean isCrash) {
        SingleResult singleResult = new SingleResult();
        int length = 0;
        if (isCrash == true) {
            if (testCase.getLength() != null) {
                length = testCase.getLength();
            }

        } else {
            if (testCase.getAssertionLength() != null) {
                length = testCase.getAssertionLength();
            }
        }
        if (length < 0) {
            length = 0;
        }
        singleResult.setId(testCase.getId());
        singleResult.setLength(length);
        if (isCrash) {
            singleResult.setExpected(testCase.getCrashClusterNum());
        } else {
            singleResult.setExpected(testCase.getAssertionClusterNum());
        }
        singleResult.setActual(ahClusters.size());

        setSingleResultMetrics(singleResult, ahClusters);
        return singleResult;
    }

    public String toStringOfClusterResult() {
        String s = "";
        s += "id: " + getId() + "\n";
        for (List<TestItem> list : getTestItemListList()) {
            s += "[";
            for (TestItem testItem : list) {
                s += "(" + testItem.getId() + ", " + testItem.getClusterType() + ")";
            }
            s += "]\n";
        }
        s += "\n";
        return s;
    }

    @Override
    public String toString() {
        return String.format("id: %d length: %d expected: %d actual: %d ok: %b " +
                        "purity: %.2f inversePurity: %.2f VRFMeasure: %.2f " +
                        "randStatisticR: %.2f jaccardCoefficientJ: %.2f folkesAndMallowsFM: %.2f " +
                        "entropy: %.2f classEntropy: %.2f mutualInformation: %.2f vi: %.2f " +
                        "dist: %d " +
                        "bcubedPrecioson: %.2f bcubedRecall: %.2f bcubedFMeasure: %.2f\n",
                getId(), getLength(), getExpected(), getActual(), isOk(),
                getPurity(), getInversePurity(), getVRFMeasure(),
                getRandStatisticR(), getJaccardCoefficientJ(), getFolkesAndMallowsFM(),
                getEntropy(), getClassEntropy(), getMutualInformation(), getVi(),
                getDist(),
                getBcubedPrecioson(), getBcubedRecall(), getBcubedFMeasure());
    }
}
