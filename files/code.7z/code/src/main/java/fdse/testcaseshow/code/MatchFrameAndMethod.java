package fdse.testcaseshow.code;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatchFrameAndMethod {
    public static Pattern pattern = Pattern.compile("\\w+\\.java", Pattern.DOTALL);

    public void run() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id >= 0 ", TestCase.class);
            List<TestCase> testCases = query.list();
            System.out.println(testCases.size());
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                Collection<TestFrame> frames = testCase.getTestFrames();
                Map<String, List<ChangedMethod>> methodMap = getMethodMap(testCase);
                setDistance(frames, methodMap, testCase.getJavaFiles());
            }

            tx.commit();
        }

    }
    public Map<String, List<ChangedMethod>> getMethodMap(TestCase testCase) {
        Map<String, List<ChangedMethod>> methodMap = new HashMap<>();
        for (ChangedFile changedFile:testCase.getChangedFiles()) {
            Matcher matcher = pattern.matcher(changedFile.getCurrentFilePath());
            if (matcher.find()) {
                String fileName = matcher.group();
                methodMap.put(fileName, new ArrayList<ChangedMethod>());
                for (ChangedMethod changedMethod:changedFile.getChangedMethods()) {
                    methodMap.get(fileName).add(changedMethod);
                }
            }
        }
        return methodMap;
    }

    public void setDistance(Collection<TestFrame> frames, Map<String, List<ChangedMethod>> methodMap, Collection<JavaFile> javaFiles) {
        for (TestFrame testFrame : frames) {
            int dis = Integer.MAX_VALUE;
            for (String fileName:methodMap.keySet()) {
                if (fileName.equals(testFrame.getFileName())) {
                    for (ChangedMethod cm:methodMap.get(fileName)) {
                        if (testFrame.getLineNum() >= cm.getStartLineNumber() && testFrame.getLineNum() <= cm.getEndLineNumber()) {
                            dis = 0;
                            break;
                        }
                    }
                }
                if (dis == 0) {
                    testFrame.setDistance(dis);
                    break;
                }
            }
            if (dis == 0) {
                continue;
            }
            for (JavaFile javaFile : javaFiles) {
                if (testFrame.getFileName() != null && testFrame.getPackageName() != null && testFrame.getPackageName().equals(javaFile.getPackageName()) && testFrame.getFileName().equals(javaFile.getFileName())) {
                    for (JavaFileDistance javaFileDistance : javaFile.getDistances()) {
                        if (dis > javaFileDistance.getDistance()) {
                            dis = javaFileDistance.getDistance();
                        }
                    }
                    break;
                }
            }
            testFrame.setDistance(dis);
        }
    }
    public void setTestFrameDistance() {
        Session session = SessionUtil.getSession();
        Query<TestFrame> query = session.createQuery("from TestFrame where id > 0", TestFrame.class);
        List<TestFrame> testFrames = query.getResultList();
        for (TestFrame testFrame : testFrames) {
        }
        session.close();
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        new MatchFrameAndMethod().run();
        Instant end = Instant.now();
        System.out.println("" + Duration.between(start, end));
    }
}
