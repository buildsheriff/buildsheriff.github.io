package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.util.FileUtil;
import org.javatuples.Pair;
import org.javatuples.Triplet;

import java.util.List;

public class SetMatchingMetrics {
    public static double getPurityOrInversePurity(List<List<Integer>> listList, int N) {
        double sum = 0.0;
        for (List<Integer> list : listList) {
            sum += FileUtil.mode(list).getValue1();
        }
        return sum / N;
    }

    public static double getVRFMeasure(List<List<Integer>> categoryList, List<List<Integer>> clusterList, int N) {
        double sum = 0.0;
        for (int categoryId = 0; categoryId < categoryList.size(); categoryId++) {
            List<Integer> category = categoryList.get(categoryId);
            double maxFM = 0.0;
            for (int clusterId = 0; clusterId < clusterList.size(); clusterId++) {
                int intersectionSize = ClusterEvaluation.countEqualIntNumInList(category, clusterId);
                if (intersectionSize > 0) {
                    double fm = 2.0 * intersectionSize / (category.size() + clusterList.get(clusterId).size());
                    if (fm > maxFM) {
                        maxFM = fm;
                    }
                }
            }
            sum += category.size() * maxFM;
            /*
            int maxI = 0;
            Pair<Integer, Integer> pair = FileUtil.mode(categoryList.get(categoryId));
            int clusterId = pair.getValue0();
            int maxIntersectionSize = pair.getValue1();
            int categorySize = categoryList.get(categoryId).size();
            int clusterSize = clusterList.get(clusterId).size();
            sum += 2.0 * maxIntersectionSize * categorySize / (categorySize + clusterSize);
            */
        }
        return sum / N;
    }

    public static Triplet<Double, Double, Double> getSetMatchingMetrics(List<List<Integer>> categoryList, List<List<Integer>> clusterList, int N) {
        double purity = getPurityOrInversePurity(clusterList, N);
        double inversePurity = getPurityOrInversePurity(categoryList, N);
        double vrFMeasure = getVRFMeasure(categoryList, clusterList, N);
        return Triplet.with(purity, inversePurity, vrFMeasure);
    }

    public static Triplet<Double, Double, Double> getSetMatchingMetrics(List<Cluster> ahClusters) {
        int N =0;
        for (Cluster cluster : ahClusters) {
            N += cluster.getSize();
        }
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        List<List<Integer>> categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        return getSetMatchingMetrics(categoryList, clusterList, N);
    }
}
