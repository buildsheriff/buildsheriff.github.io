package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.model.TestCase;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

public class ResultSummary {
    @Getter
    private List<SingleResult> singleResultList = new ArrayList<>();

    public void addSingleResult(TestCase testCase, List<Cluster> ahClusters, boolean isCrash) {
        SingleResult singleResult = SingleResult.getSingleResult(testCase, ahClusters, isCrash);
        singleResultList.add(singleResult);
    }

    public int getOkNum() {
        int count = 0;
        for (SingleResult singleResult : singleResultList) {
            if (singleResult.isOk()) {
                count++;
            }
        }
        return count;
    }

    public List<Double> getPurityList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getPurity());
        }
        return list;
    }

    public List<Double> getInversePurityList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getInversePurity());
        }
        return list;
    }

    public List<Double> getVRFMeasureList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getVRFMeasure());
        }
        return list;
    }

    public List<Double> getRandStatisticRList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getRandStatisticR());
        }
        return list;
    }

    public List<Double> getJaccardCoefficientJList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getJaccardCoefficientJ());
        }
        return list;
    }

    public List<Double> getFolkesAndMallowsFMList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getFolkesAndMallowsFM());
        }
        return list;
    }

    public List<Double> getEntropyList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getEntropy());
        }
        return list;
    }

    public List<Double> getClassEntropyList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getClassEntropy());
        }
        return list;
    }

    public List<Double> getMutualInformationList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getMutualInformation());
        }
        return list;
    }

    public List<Double> getViList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getVi());
        }
        return list;
    }

    public List<Double> getDistList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add((double) singleResult.getDist());
        }
        return list;
    }

    public List<Double> getBcubedPreciosonList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getBcubedPrecioson());
        }
        return list;
    }

    public List<Double> getBcubedRecallList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getBcubedRecall());
        }
        return list;
    }

    public List<Double> getBcubedFMeasureList() {
        List<Double> list = new ArrayList<>();
        for (SingleResult singleResult : singleResultList) {
            list.add(singleResult.getBcubedFMeasure());
        }
        return list;
    }

    public static double averge(List<Double> list) {
        double sum = 0.0;
        double count = 0;
        for (double i : list) {
            if (Double.isNaN(i) == false) {
                sum += i;
                count++;
            }
        }
        return sum / count;
    }

    public String getStatistics() {
        int ok = getOkNum();

        double purity = averge(getPurityList());
        double inversePurity = averge(getInversePurityList());
        double VRFMeasure = averge(getVRFMeasureList());

        double randStatisticR = averge(getRandStatisticRList());
        double jaccardCoefficientJ = averge(getJaccardCoefficientJList());
        double folkesAndMallowsFM = averge(getFolkesAndMallowsFMList());

        double entropy = averge(getEntropyList());
        double classEntropy = averge(getClassEntropyList());
        double mutualInformation = averge(getMutualInformationList());
        double vi = averge(getViList());

        double dist = averge(getDistList());

        double bcubedPrecioson = averge(getBcubedPreciosonList());
        double bcubedRecall = averge(getBcubedRecallList());
        double bcubedFMeasure = averge(getBcubedFMeasureList());
        String s = String.format("Result Summary:\nok: %d purity: %.2f inversePurity: %.2f VRFMeasure: %.2f " +
                        "randStatisticR: %.2f jaccardCoefficientJ: %.2f folkesAndMallowsFM: %.2f " +
                        "entropy: %.2f classEntropy: %.2f mutualInformation: %.2f vi: %.2f " +
                        "dist: %.2f " +
                        "bcubedPrecioson: %.2f bcubedRecall: %.2f bcubedFMeasure: %.2f\n",
                ok, purity, inversePurity, VRFMeasure,
                randStatisticR, jaccardCoefficientJ, folkesAndMallowsFM,
                entropy, classEntropy, mutualInformation, vi,
                dist,
                bcubedPrecioson, bcubedRecall, bcubedFMeasure);
        return s;
    }

    @Override
    public String toString() {
        String s = getStatistics();
        for (SingleResult singleResult : singleResultList) {
            s += singleResult.toString();
        }
        s += "======================================";
        return s;
    }
}
