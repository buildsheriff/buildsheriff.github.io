package fdse.testcaseshow.cluster;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.Collection;
import java.util.List;

public class AssertionCluster {

    public static void setIncludeAssertion() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id > 0 ", TestCase.class);

            List<TestCase> testCases = query.list();
            int count = 0;
            for (TestCase testCase : testCases) {
                int c = 0;
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    if (testItem.isCrash() == false) {
                        c++;
                    }
                    if (c >= 2) {
                        count ++;
                        System.out.print(testCase.getId() + ", ");
                        break;
                    }
                }
            }
            System.out.println(count);
            tx.commit();
        }
    }

    public static void matchAssertion() {
        try (Session session = SessionUtil.getSession()) {
            Query<TestItem> query = session.createQuery("from TestItem where id > 0 and isCrash = false ", TestItem.class);
            List<TestItem> testItems = query.list();
            for (TestItem testItem : testItems) {
                AssertionUtil.AssertionMessage assertionMessage = AssertionUtil.getAssertionMessage(testItem);
                System.out.println(testItem.getId());
                if (assertionMessage == null) {
                } else {
                }
            }
        }
    }
    public static void main(String[] args) {
        setIncludeAssertion();
    }
}
