package fdse.testcaseshow.feature;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ChangedFileInfo {
    private String status;
    private String preFilePath;
    private String currentFilePath;
}
