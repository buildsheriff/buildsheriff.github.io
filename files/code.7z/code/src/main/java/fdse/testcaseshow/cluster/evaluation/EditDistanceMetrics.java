package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.util.FileUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EditDistanceMetrics {
    private static int calculateEditDistance(List<List<Integer>> clusterList) {
        int dist = 0;
        int maxCategoryId = 0;
        for (List<Integer> intList : clusterList) {
            int temp = Collections.max(intList);
            if (temp > maxCategoryId)
                maxCategoryId = temp;
        }
        List<List<Integer>> fakeCategoryList = new ArrayList<>();
        for (int i = 0; i <= maxCategoryId; i++) {
            fakeCategoryList.add(new ArrayList<>());
        }
        for (List<Integer> cluster : clusterList) {
            int assignedCategoryId = FileUtil.mode(cluster).getValue0();
            fakeCategoryList.get(assignedCategoryId).addAll(cluster);
            dist += 1;
        }
        for (int i = 0; i < fakeCategoryList.size(); i++) {
            dist += ClusterEvaluation.countNotEqualIntNumInList(fakeCategoryList.get(i), i);
        }
        return dist;
    }
    public static int getEditDistance(List<Cluster> ahClusters) {
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        return calculateEditDistance(clusterList);
    }

    public static double getEditDistanceMetrics(List<Cluster> ahClusters) {
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        int N = 0;
        for (List<Integer> cluster : clusterList) {
            N += cluster.size();
        }
        int dist = calculateEditDistance(clusterList);
        return 1 - 1.0 * dist / N;
    }
}
