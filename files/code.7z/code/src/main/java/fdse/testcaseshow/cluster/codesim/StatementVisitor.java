package fdse.testcaseshow.cluster.codesim;

import com.github.gumtreediff.client.diff.AnnotatedXmlDiff;
import org.eclipse.jdt.core.dom.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StatementVisitor extends ASTVisitor {

    private List<String> invokedMethodNames = new ArrayList<>();
    private Set<String> simpleNames = new HashSet<>();


    private List<String> names = new ArrayList<>();

    public List<String> getInvokedMethodNames() {
        return invokedMethodNames;
    }
    public Set<String> getSimpleNames() {
        return simpleNames;
    }

    public List<String> getNames() {
        return names;
    }
    @Override
    public boolean visit(MethodInvocation node) {
        invokedMethodNames.add(node.getName().toString());
        return super.visit(node);
    }

    @Override
    public boolean visit(QualifiedName node) {
        return super.visit(node);
    }

    @Override
    public boolean visit(SimpleName node) {
        String s = node.getFullyQualifiedName();
            simpleNames.add(s);
            names.add(s);
        return super.visit(node);
    }

    @Override
    public boolean visit(PrimitiveType node) {
        names.add(node.toString());
        return super.visit(node);
    }

    @Override
    public boolean visit(ClassInstanceCreation node) {
        names.add("new");
        return super.visit(node);
    }

    @Override
    public boolean visit(TryStatement node) {
        names.add("try");
        if (node.catchClauses().size() > 0)
            names.add("catch");
        if (node.getFinally() != null)
            names.add("finally");
        return super.visit(node);
    }

    @Override
    public boolean visit(ContinueStatement node) {
        names.add("continue");
        return super.visit(node);
    }

    @Override
    public boolean visit(DoStatement node) {
        names.add("do");
        names.add("while");
        return super.visit(node);
    }

    @Override
    public boolean visit(BreakStatement node) {
        names.add("break");
        return super.visit(node);
    }

    @Override
    public boolean visit(ForStatement node) {
        names.add("for");
        return super.visit(node);
    }

    @Override
    public boolean visit(IfStatement node) {
        names.add("if");
        if (node.getElseStatement() != null) {
            names.add("else");
        }
        return super.visit(node);
    }

    @Override
    public boolean visit(SwitchCase node) {
        names.add("switch");
        names.add("case");
        return super.visit(node);
    }

    @Override
    public boolean visit(ThrowStatement node) {
        names.add("throw");
        return super.visit(node);
    }

    @Override
    public boolean visit(WhileStatement node) {
        names.add("while");
        return super.visit(node);
    }

    @Override
    public boolean visit(StringLiteral node) {
        String s = node.getLiteralValue();
            names.add(node.getLiteralValue());
        return super.visit(node);
    }

    @Override
    public boolean visit(BooleanLiteral node) {
        names.add(String.valueOf(node.booleanValue()));
        return super.visit(node);
    }

    @Override
    public boolean visit(CharacterLiteral node) {
        names.add(node.getEscapedValue());
        return super.visit(node);
    }

    @Override
    public boolean visit(NullLiteral node) {
        names.add(node.toString());
        return super.visit(node);
    }

    @Override
    public boolean visit(NumberLiteral node) {
        names.add(node.getToken());
        return super.visit(node);
    }

    @Override
    public boolean visit(TypeLiteral node) {
        names.add(node.toString());
        return super.visit(node);
    }
}
