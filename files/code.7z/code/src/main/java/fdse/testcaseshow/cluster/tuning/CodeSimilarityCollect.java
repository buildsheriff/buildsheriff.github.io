package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.evaluation.CodeSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;

import java.io.FileNotFoundException;
import java.util.concurrent.BlockingQueue;

public class CodeSimilarityCollect implements Runnable {
    private BlockingQueue<ResultSummary> outQueue;
    private String outFileName;

    public CodeSimilarityCollect(BlockingQueue<ResultSummary> outQueue, String outFileName) {
        this.outQueue = outQueue;
        this.outFileName = outFileName;
    }

    public ResultSummary getResult() {
        ResultSummary resultSummary = null;
        try {
            resultSummary = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return resultSummary;
    }
    @Override
    public void run() {
        try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.CODESIMILARITY, true, outFileName)) {
            while (true) {
                CodeSimilarityResultSummary resultSummary = (CodeSimilarityResultSummary) getResult();
                if (resultSummary.getCoefficient() == null)
                    break;
                storeResultSummary.write(resultSummary);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
