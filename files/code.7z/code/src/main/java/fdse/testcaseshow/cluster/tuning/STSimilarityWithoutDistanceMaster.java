package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.STSimilarityWithoutDistance;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class STSimilarityWithoutDistanceMaster {
    private BlockingQueue<STSimilarityWithoutDistance.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);

    private static final int THREAD_NUMBER = 20;
    private void initializeThreads(List<Thread> threads, Thread thread, List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new STSimilarityWithoutDistanceSlave(testCases, inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    private void putCoefficient(STSimilarityWithoutDistance.Coefficient coefficient) {
        try {
            inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void tuning() {
        List<TestCase> testCases = null;
        try(Session session = SessionUtil.getSession()) {
            testCases = MysqlUtil.getCrashTestCases(session);
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    testItem.getTestFrames().size();
                }
            }
        }
        STSimilarityWithoutDistanceCollect stSimilarityCollect = new STSimilarityWithoutDistanceCollect(outQueue);
        Thread collectThread = new Thread(stSimilarityCollect);
        List<Thread> threads = new ArrayList<>();
        initializeThreads(threads, collectThread, testCases);
        for (double sMax = 0.51; sMax < 1.00001; sMax += 0.01) {
            for (double c = 0.1; c < 2.001; c += 0.1) {
                STSimilarityWithoutDistance.Coefficient coefficient = new STSimilarityWithoutDistance.Coefficient(sMax, c, 0, 1, 1);
                System.out.println(coefficient);
                putCoefficient(coefficient);
            }
        }

        for (int i = 0; i < THREAD_NUMBER; i++) {
            STSimilarityWithoutDistance.Coefficient coefficient = new STSimilarityWithoutDistance.Coefficient();
            coefficient.setMethodMatchDistance(-1);
            putCoefficient(coefficient);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        try {
            ResultSummary resultSummary = new STSimilarityResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new STSimilarityWithoutDistanceMaster().tuning();
    }

}

