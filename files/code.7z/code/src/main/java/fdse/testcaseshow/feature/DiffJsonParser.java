package fdse.testcaseshow.feature;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fdse.testcaseshow.model.TestCase;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DiffJsonParser {
    public static String getContentOfDiffJsonFile(String repoName, String jobNumber) {
        Path diffJsonFilePath = Paths.get(System.getProperty("user.dir"), "resources", "diff_json",
                repoName.replaceFirst("/", "@")+ "%" + jobNumber.replaceFirst("\\.", "@") + ".json");
        String jsonString = null;
        try {
            jsonString = new String(Files.readAllBytes(diffJsonFilePath));
        } catch (IOException e) {
            e.printStackTrace();
            jsonString = "";
        }
        return jsonString;
    }

    public static JsonObject getJsonObject(String content) {
        return JsonParser.parseString(content).getAsJsonObject();
    }

    public static JsonObject getJsonObject(String repoName, String jobNumber) {
        String content = getContentOfDiffJsonFile(repoName, jobNumber);
        return getJsonObject(content);
    }

    public static JsonObject getJsonObject(TestCase testCase) {
        return getJsonObject(testCase.getRepoName(), testCase.getJobNumber());
    }

}
