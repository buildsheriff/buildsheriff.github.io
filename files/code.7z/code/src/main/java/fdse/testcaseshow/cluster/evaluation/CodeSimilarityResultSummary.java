package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import lombok.Getter;

public class CodeSimilarityResultSummary extends ResultSummary {
    @Getter
    private CodeSimilarity.Coefficient coefficient;

    public CodeSimilarityResultSummary(CodeSimilarity.Coefficient coefficient) {
        this.coefficient = coefficient;
    }
    @Override
    public String toString() {
        String s = String.format("CodeSimilarity parameters\ncs: %.2f ca: %.2f maxDistance: %d matchThreshold: %.2f threshold: %.2f\n",
                coefficient.getCStatement(), coefficient.getCComplete(), coefficient.getMaxDistance(), coefficient.getMatchThreshold(), coefficient.getThreshold());
        s += super.toString();
        return s;
    }
}
