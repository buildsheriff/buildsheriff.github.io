package fdse.testcaseshow.cluster;

import fdse.testcaseshow.model.TestItem;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class DataPoint {
    private long ID;
    private TestItem testItem;
    private Cluster cluster;

    public DataPoint(long ID, TestItem testItem) {
        this.ID = ID;
        this.testItem = testItem;
    }

    public long getID() {
        return ID;
    }

    public TestItem getTestItem() {
        return testItem;
    }

    public Cluster getCluster() {
        return cluster;
    }

    public void setCluster(Cluster cluster) {
        this.cluster = cluster;
    }

    @Override
    public String toString() {
        return this.ID
                + "\n>>>>>>>>>>>>>>>\n" ;
    }
}
