package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreJavaFileTask implements Runnable{
    private BlockingQueue<ExtractJavaFile.OutJavaFile> outQueue;

    public StoreJavaFileTask(BlockingQueue<ExtractJavaFile.OutJavaFile> outQueue) {
        this.outQueue = outQueue;
    }

    private ExtractJavaFile.OutJavaFile getOutJavaFile() {
        ExtractJavaFile.OutJavaFile outJavaFile = null;
        try {
            outJavaFile = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return outJavaFile;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        ExtractJavaFile.OutJavaFile outJavaFile = null;
        Object o = session.createQuery("select max(j.id) from JavaFile j").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            try {
                outJavaFile = outQueue.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (outJavaFile.getTestCaseId() < 0)
                break;
            long testCaseId = outJavaFile.getTestCaseId();

            TestCase testCase = session.load(TestCase.class, testCaseId);
            JavaFile javaFile = outJavaFile.getJavaFile();
            javaFile.setTestCase(testCase);
            id++;
            javaFile.setId(id);
            session.save(javaFile);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
