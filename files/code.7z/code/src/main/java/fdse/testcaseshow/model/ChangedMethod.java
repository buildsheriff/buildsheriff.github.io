package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;
import java.util.regex.Pattern;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "changed_methods")
public class ChangedMethod {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "class_name")
    private String className;
    @Column(name = "method_name")
    private String methodName;
    @Column(name = "start_line_number")
    private int startLineNumber;
    @Column(name = "end_line_number")
    private int endLineNumber;

    public static Pattern classNamePattern = Pattern.compile("/([^/]+)$");
}