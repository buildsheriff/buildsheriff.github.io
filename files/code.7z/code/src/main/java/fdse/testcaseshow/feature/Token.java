package fdse.testcaseshow.feature;

import com.google.common.base.Objects;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.Locale;

@AllArgsConstructor
public class Token {
    @Setter
    @Getter
    private String name;
    @Setter
    @Getter
    private TokenType type;
    @Setter
    @Getter
    private TokenStatus status;

    public static Token create(String name, TokenType type, TokenStatus status) {
        return new Token(name, type, status);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Token token = (Token) o;
        return Objects.equal(name.toLowerCase(Locale.ROOT), token.name.toLowerCase(Locale.ROOT)) && type == token.type && status == token.status;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, type);
    }

    @Override
    public String toString() {
        return "Token{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", status=" + status +
                '}';
    }
}
