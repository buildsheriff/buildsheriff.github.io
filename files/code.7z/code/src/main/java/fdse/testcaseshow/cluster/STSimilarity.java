package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.combine.CoefficientInterface;
import fdse.testcaseshow.cluster.combine.SimInterface;
import fdse.testcaseshow.log.STLength;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestFrame;
import fdse.testcaseshow.model.TestItem;
import lombok.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class STSimilarity extends AHCluster implements SimInterface {
    private double c;
    private int maxDistance;
    public STSimilarity(List<DataPoint> dataPoints, double sMax, double c) {
        super(dataPoints, sMax);
        this.c = c;
        this.maxDistance = 15;
    }

    public STSimilarity(List<DataPoint> dataPoints, double sMax, double c, int maxDistance) {
        super(dataPoints, sMax);
        this.c = c;
        this.maxDistance = maxDistance;
    }

    private void printSim(TestItem tiA, TestItem tiB, double sim) {
        System.out.println("c: " + String.format("%.2f", this.c) + " maxDistance: " + this.maxDistance + " TestCaseId: " + tiA.getTestCase().getId() + " A: " + tiA.getId() + " B: " + tiB.getId() + " sim: " + sim);
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {

        List<Frame> aList = getFrameList(tiA);
        List<Frame> bList = getFrameList(tiB);
        if (aList.size() == 0 || bList.size() == 0)
            return 0.0;
        for (Frame aFrame:aList) {
            for (Frame bFrame:bList) {
                if (aFrame.equals(bFrame)) {
                    aFrame.setMatch(true);
                    bFrame.setMatch(true);
                }
            }
        }
        double sim = getSimilarity(aList, bList);
        return sim;
    }

    public double getSimilarity(List<Frame> aList, List<Frame> bList) {
        double numerator = 0.0;
        double denominator = 0.0;
        aList.addAll(bList);
        for (Frame frame:aList) {
            denominator += Math.exp(-1 * c * frame.getDistance());
            if (frame.isMatch()) {
                numerator += Math.exp(-1 * c * frame.getDistance());
            }
        }
        return numerator / denominator;
    }

    public List<Frame> getFrameList(TestItem testItem) {
        List<Frame> list = new ArrayList<>();
        testItem.getTestFrames().forEach(f -> {
            String s = f.getFrame().trim();
            if (s.startsWith("at") ) {
                Frame frame = new Frame();
                frame.setFrame(s);
                if (f.getDistance() > 5) {
                    frame.setDistance(maxDistance);
                } else {
                    frame.setDistance(f.getDistance());
                }
                list.add(frame);
            }
        });
        return list;
    }

    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(double sMax, double c, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new STSimilarity(dataPoints, sMax, c).startCluster();
    }

    public static List<Cluster> clusterBuild(double sMax, double c, int maxDistance, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new STSimilarity(dataPoints, sMax, c, maxDistance).startCluster();
    }

    public static List<Cluster> clusterBuild(Coefficient coefficient, List<TestItem> testItems) {
        return clusterBuild(coefficient.getSMax(), coefficient.getC(), coefficient.getMaxDistance(), testItems);
    }

    public static List<Cluster> clusterBuild(double sMax, double c, int maxDistance, TestCase testCase) {
        List<TestItem> selectedTestItems = getSelectedTestItems(testCase);
        return clusterBuild(sMax, c, maxDistance, selectedTestItems);
    }

    public static List<TestItem> getSelectedTestItems(TestCase testCase) {
        Collection<TestItem> testItems = testCase.getTestItems();
        List<TestItem> selectedTestItems = new ArrayList<>();
        testItems.forEach(e -> {
            if (e.isCrash())
                selectedTestItems.add(e);
        });
        return selectedTestItems;
    }

    @Getter
    @Setter
    private static class Frame {
        private String frame;
        private int distance;
        private boolean match = false;

        public boolean equals(Frame o) {
            if (this == o) return true;
            if (o == null) return false;
            if (this.getFrame().equals(o.getFrame())) return true;
            return false;
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient implements CoefficientInterface {
        private double sMax;
        private double c;
        private int maxDistance;
    }
}
