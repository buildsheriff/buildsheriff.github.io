package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.evaluation.ClusterEvaluation;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

public class TopNFrame {

    private static String getTopNFrame(TestItem testItem, int n) {
        if (testItem.getStackTrace() == null)
            return null;
        int count = 0;
        List<String> list = new ArrayList<>();
        String[] lines = testItem.getStackTrace().split("\\n");
        for (String line : lines) {
            String s = line.trim();
            if (s.startsWith("at")) {
                list.add(s);
                count++;
                if (count >= n)
                    break;
            }
        }
        if (list.size() > 0) {
            return String.join("\\n", list);
        } else {
            return null;
        }
    }

    public static List<List<TestItem>> TopNCluster(List<TestItem> testItems, int n) {
        List<List<TestItem>> testItemListList = new ArrayList<>();
        Map<String, List<TestItem>> map = new HashMap<>();
        for (TestItem testItem : testItems) {
            String key = getTopNFrame(testItem, n);
            if (key == null) {
                testItemListList.add(new ArrayList<TestItem>(Arrays.asList(testItem)));
            } else {
                if (map.containsKey(key)) {
                    map.get(key).add(testItem);
                } else {
                    map.put(key, new ArrayList<TestItem>(Arrays.asList(testItem)));
                }
            }
        }
        for (List<TestItem> list : map.values()) {
            testItemListList.add(list);
        }
        return testItemListList;
    }

    public static void runException() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            ResultSummary resultSummary = new ResultSummary();
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<List<TestItem>> testItemListList = TopNCluster(selectedTestItems, 1);
                List<Cluster> clusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.FRAME1, true, null)) {
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void runAssertion() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            ResultSummary resultSummary = new ResultSummary();
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
                List<List<TestItem>> testItemListList = TopNCluster(selectedTestItems, 1);
                List<Cluster> clusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
                resultSummary.addSingleResult(testCase, clusters, false);
            }
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.FRAME1, true, "Assertion")) {
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        runException();
        Instant end = Instant.now();
    }
}
