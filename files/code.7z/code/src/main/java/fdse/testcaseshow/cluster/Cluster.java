package fdse.testcaseshow.cluster;

import java.util.ArrayList;
import java.util.List;

public class Cluster {
    private List<DataPoint> dataPoints = new ArrayList<>();
    private String clusterName;
    private int clusterID;
    private List<Long> ids;

    public int getClusterID() {
        return clusterID;
    }

    public void setClusterID(int clusterID) {
        this.clusterID = clusterID;
    }

    public List<DataPoint> getDataPoints() {
        return dataPoints;
    }

    public void setDataPoints(List<DataPoint> dataPoints) {
        this.dataPoints = dataPoints;
    }

    public String getClusterName() {
        return clusterName;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    public int getSize() { return dataPoints.size(); }

    public List<Long> getIds() {
        if (ids == null) {
            ids = new ArrayList<>();
            for (DataPoint dataPoint : dataPoints) {
                ids.add(dataPoint.getID());
            }
        }
        return ids;
    }

    public String toString() {
        String s = clusterName + "->" + clusterID + ": ";
        for (DataPoint dataPoint : dataPoints) {
            s += dataPoint.getID() + ", ";
        }
        return s;
    }
}
