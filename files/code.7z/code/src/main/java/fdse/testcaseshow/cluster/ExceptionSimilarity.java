package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.combine.SimInterface;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ExceptionSimilarity extends AHCluster implements SimInterface {

    public ExceptionSimilarity(List<DataPoint> dataPoints, double sMax) {
        super(dataPoints, sMax);
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {

        String msg1 = getExceptionMessage(testItem1);
        String msg2 = getExceptionMessage(testItem2);
        if (msg1 == null || msg2 == null)
            return 0.0;
        double sim = EditDistance.getsimilarity(msg1, msg2);

        return sim;
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static String getExceptionMessage(TestItem testItem) {
        if (testItem.getStackTrace() == null && testItem.getErrorMessage() == null)
            return null;
        String msg = null;
        if (testItem.getStackTrace() != null) {
            String[] list = testItem.getStackTrace().split("\n");
            List<String> result = new ArrayList<>();
            boolean flag = false;
            for (String s : list) {
                if (s.trim().startsWith("at")) {
                    flag = false;
                }
                if (flag) {
                    result.add(s.trim());
                }
                if (s.contains("Time elapsed:")) {
                    flag = true;
                }
            }
            msg = String.join(" ", result);
        } else {
            msg = testItem.getErrorMessage();
        }
        msg = msg.replaceAll("\\s+", " ");
        return msg;
    }

    public static List<Cluster> clusterBuild(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new ExceptionSimilarity(dataPoints, sMax).startCluster();
    }

    public static void run() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id >= 228 ", TestCase.class);

            List<TestCase> testCases = query.list();
            int count = 0;
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                List<TestItem> selectedTestItems = new ArrayList<>();
                testItems.forEach(e -> {
                    if (e.isCrash() && e.getStackTrace() != null && e.getStackTrace().length() > 5)
                        selectedTestItems.add(e);
                });
                List<Cluster> clusters = clusterBuild(0.5, selectedTestItems);
                if (clusters.size() == testCase.getCrashClusterNum())
                    count++;

            }
            tx.commit();
        }
    }


    public static boolean testCaseLegal(List<TestItem> selectedTestItems) {
        for (TestItem testItem : selectedTestItems) {
            if (testItem.getStackTrace() == null && testItem.getErrorMessage() == null) {
                return false;
            }
        }
        return true;
    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private double sMax;
    }
}
