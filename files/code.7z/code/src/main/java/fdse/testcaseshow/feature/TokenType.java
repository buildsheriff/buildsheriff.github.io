package fdse.testcaseshow.feature;

public enum TokenType {
    CLASS_NAME(0), METHOD_NAME(1), FIELD_NAME(2), RESOURCE_NAME(3);
    private int value;
    private TokenType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
