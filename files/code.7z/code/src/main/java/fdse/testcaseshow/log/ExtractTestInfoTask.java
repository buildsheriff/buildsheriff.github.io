package fdse.testcaseshow.log;

import fdse.testcaseshow.log.CutLog;
import fdse.testcaseshow.log.SplitLog;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestLog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Pattern;

public class ExtractTestInfoTask implements Runnable{
    private BlockingQueue<TestCase> inQueue;
    private BlockingQueue<CutLog.CaseLogMap> outQueue;

    public ExtractTestInfoTask(BlockingQueue<TestCase> inQueue, BlockingQueue<CutLog.CaseLogMap> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }

    @Override
    public void run() {
        TestCase testCase = null;
        while (true) {
            try {
                testCase = inQueue.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            }
            if (testCase == null)
                break;
            if (testCase.getId() == -1)
                break;
            String repoName = testCase.getRepoName().trim();
            String jobNumber = testCase.getJobNumber().trim();
            Path logPath = Paths.get(System.getProperty("user.dir"), "resources", "log",
                    repoName.replaceFirst("/", "@"), jobNumber.replaceFirst("\\.", "@") + ".log");
            if (Files.exists(logPath)) {
                Instant start = Instant.now();
                List<String> list = extractTestInfoFromLog(logPath);
                Instant end = Instant.now();
                System.out.println("提取日志中信息时间" + Duration.between(start, end));
                String log = null;
                if (list != null) {
                    log = String.join("\n", list);
                }
                TestLog testLog = new TestLog();
                testLog.setLog(log);
                try {
                    outQueue.put(new CutLog.CaseLogMap(testCase, testLog));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public List<String> extractTestInfoFromLog(Path path) {
        if(Files.notExists(path)) {
            return null;
        }
        String stringTESTS = "T E S T S";

        Pattern patternHyphen = Pattern.compile("-----------------------------------------------------------------------");
        List<String> out = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(path);
            boolean testStartFlag = false;
            int count = 0;
            for (String line : lines) {
                //System.out.println(line);
                if(line.contains(stringTESTS) || line.contains(ExtractTestItemTask.mark1)) {
                    //System.out.println(line);
                    testStartFlag = true;
                } else if(count == 2) {
                    testStartFlag = false;
                    count = 0;
                } else if(patternHyphen.matcher(line).find() && testStartFlag) {
                    count += 1;
                }

                if(testStartFlag) {
                    //System.out.println(line);
                    out.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("File read has errors" + path.toString());
            return null;
        }

        if(out.size() > 0) {
            return out;
        } else {
            return null;
        }
    }
}
