package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "java_file_distances")
public class JavaFileDistance {
    @Id
    private long id;

    @Column(name = "distance")
    private Integer distance;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="java_file_id")
    private JavaFile javaFile;
}
