package fdse.testcaseshow.cluster.combine;

public interface CoefficientInterface {
}
