package fdse.testcaseshow.code;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatchFrameType {
    public static Pattern pattern = Pattern.compile("\\w+\\.java", Pattern.DOTALL);

    public void run() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id <= 305", TestCase.class);
            List<TestCase> testCases = query.list();
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                Collection<TestFrame> frames = testCase.getTestFrames();
                Map<String, List<ChangedMethod>> methodMap = getMethodMap(testCase);
                setType(frames, methodMap, testCase.getJavaFiles());
            }

            tx.commit();
        }

    }
    public Map<String, List<ChangedMethod>> getMethodMap(TestCase testCase) {
        Map<String, List<ChangedMethod>> methodMap = new HashMap<>();
        for (ChangedFile changedFile:testCase.getChangedFiles()) {
            Matcher matcher = pattern.matcher(changedFile.getCurrentFilePath());
            if (matcher.find()) {
                String fileName = matcher.group();
                methodMap.put(fileName, new ArrayList<ChangedMethod>());
                for (ChangedMethod changedMethod:changedFile.getChangedMethods()) {
                    methodMap.get(fileName).add(changedMethod);
                }
            }
        }
        return methodMap;
    }

    public int onlyOneMethodChanged(TestFrame testFrame, Map<String, List<ChangedMethod>> methodMap) {
        System.out.println(testFrame.getFrame());
        List<ChangedMethod> changedMethods = null;
        for (String fileName : methodMap.keySet()) {
            if (fileName.equals(testFrame.getFileName())) {
                for (ChangedMethod cm : methodMap.get(fileName)) {
                    if (testFrame.getLineNum() >= cm.getStartLineNumber() && testFrame.getLineNum() <= cm.getEndLineNumber()) {
                        changedMethods = methodMap.get(fileName);
                        break;
                    }
                }
            }
            if (changedMethods != null) {
                break;
            }
        }
        if (changedMethods == null) {
            return 2;
        }else if (changedMethods.size() == 1) {
            return 3;
        } else {
            return 2;
        }
    }
    public void setType(Collection<TestFrame> frames, Map<String, List<ChangedMethod>> methodMap, Collection<JavaFile> javaFiles) {
        for (TestFrame testFrame : frames) {
            if (testFrame.getDistance() == 0) {
                testFrame.setType(onlyOneMethodChanged(testFrame, methodMap));
            } else if (testFrame.getDistance() == 1) {
                testFrame.setType(1);
            }
        }
    }
    public void setTestFrameDistance() {
        Session session = SessionUtil.getSession();
        Query<TestFrame> query = session.createQuery("from TestFrame where id > 0", TestFrame.class);
        List<TestFrame> testFrames = query.getResultList();
        for (TestFrame testFrame : testFrames) {
        }
        session.close();
    }


    public static void main(String[] args) {
        new MatchFrameType().run();

    }
}
