package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.STSimilarity;
import lombok.Getter;

public class STSimilarityResultSummary extends ResultSummary {
    @Getter
    private STSimilarity.Coefficient coefficient;

    public STSimilarityResultSummary(STSimilarity.Coefficient coefficient) {
        this.coefficient = coefficient;
    }
    @Override
    public String toString() {
        String s = String.format("STSimilarity parameters\nsMax: %.2f c: %.2f maxDistance: %d\n",
                coefficient.getSMax(), coefficient.getC(), coefficient.getMaxDistance());
        s += super.toString();
        return s;
    }
}
