package fdse.testcaseshow.cluster;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import fdse.testcaseshow.model.TestItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class AHCluster {
    protected List<DataPoint> dataPoints;
    protected double sMax;
    protected Table<Long, Long, Double> simTable = HashBasedTable.create();
    protected List<TestItem> testItems;
    public AHCluster(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        this.dataPoints = dataPoints;
        this.sMax = sMax;
        this.testItems = testItems;
    }

    public AHCluster(List<DataPoint> dataPoints, double sMax) {
        this.dataPoints = dataPoints;
        this.sMax = sMax;
    }
    public String toStringOfSimMap() {
        String s = "simTable\n";
        for (Long rowNum : simTable.rowKeySet()) {
           s += rowNum + ": " ;
           Map<Long, Double> row = simTable.row(rowNum);
           for (Map.Entry<Long, Double> cell : row.entrySet()) {
               s += "(" + cell.getKey() + " : " + cell.getValue() + ")";
           }
           s += "\n";
        }
        return s;
    }

    public double getAndSaveSim(TestItem tiA, TestItem tiB) {
        Long numA = tiA.getId();
        Long numB = tiB.getId();
        Double sim = simTable.get(numA, numB);
        if (sim != null) {
            return sim;
        }
        sim = getSim(tiA, tiB);
        simTable.put(numA, numB, sim);
        simTable.put(numB, numA, sim);
        return sim;
    }

    public abstract double getSim(TestItem tiA, TestItem tiB);

    public double getMaxSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        double sim = 0.0;
        for (DataPoint a : dataPointsA) {
            for (DataPoint b : dataPointsB) {
                double tempSim = getAndSaveSim(a.getTestItem(), b.getTestItem());
                if (tempSim > sim) sim = tempSim;
            }
        }
        return sim;
    }

    public double getMinSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        double sim = 1.0;
        for (DataPoint a : dataPointsA) {
            for (DataPoint b : dataPointsB) {
                double tempSim = getAndSaveSim(a.getTestItem(), b.getTestItem());
                if (tempSim < sim) sim = tempSim;
            }
        }
        return sim;
    }

    public abstract double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB);

    private List<Cluster> initialCluster() {
        List<Cluster> originalClusters = new ArrayList<>();
        for (int i = 0; i < dataPoints.size(); i++) {
            DataPoint tempDataPoint = dataPoints.get(i);
            List<DataPoint> tempDataPoints = new ArrayList<DataPoint>();
            tempDataPoints.add(tempDataPoint);
            Cluster tempCluster = new Cluster();
            tempCluster.setClusterName("Cluster " + String.valueOf(i));
            tempCluster.setClusterID(i);
            tempCluster.setDataPoints(tempDataPoints);
            tempDataPoint.setCluster(tempCluster);
            originalClusters.add(tempCluster);
        }
        return originalClusters;
    }

    private List<Cluster> mergeCluster(List<Cluster> finalClusters, int mergeIndexA, int mergeIndexB) {
        if (mergeIndexA != mergeIndexB) {
            Cluster clusterA = finalClusters.get(mergeIndexA);
            Cluster clusterB = finalClusters.get(mergeIndexB);

            List<DataPoint> dpA = clusterA.getDataPoints();
            List<DataPoint> dpB = clusterB.getDataPoints();

            for (DataPoint dp : dpB) {
                DataPoint tempDp = new DataPoint(dp.getID(), dp.getTestItem());
                tempDp.setCluster(clusterA);
                dpA.add(tempDp);
            }
            finalClusters.remove(mergeIndexB);
        }
        return finalClusters;
    }

    public List<Cluster> startCluster() {
        List<Cluster> finalClusters = initialCluster();
        boolean flag = true;
        int it = 1;
        while (flag) {
            double maxSim = -1;
            int mergeIndexA = 0;
            int mergeIndexB = 0;
            for (int i = 0; i < finalClusters.size() - 1; i++) {
                for (int j = i + 1; j < finalClusters.size(); j++) {
                    Cluster clusterA = finalClusters.get(i);
                    Cluster clusterB = finalClusters.get(j);
                    List<DataPoint> dataPointsA = clusterA.getDataPoints();
                    List<DataPoint> dataPointsB = clusterB.getDataPoints();
                    double tempSim = 0.0;

                    tempSim = getSim(dataPointsA, dataPointsB);
                    if (tempSim > maxSim) {
                        maxSim = tempSim;
                        mergeIndexA = i;
                        mergeIndexB = j;
                    }
                }
            }

            if (maxSim > this.sMax || Math.abs(maxSim - this.sMax) < 0.00001) {
                finalClusters = mergeCluster(finalClusters, mergeIndexA, mergeIndexB);
            } else {
                flag = false;
            }

            it++;
        }
        return finalClusters;
    }
}
