package fdse.testcaseshow.cluster.codesim;

import java.util.Collection;

public interface ITokensDuplication {
    Collection<String> processTokens(Collection<String> collection);
}
