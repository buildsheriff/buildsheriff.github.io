package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.model.JavaFileToken;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.Statement;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CodeSimUtil {

    //convert string to corresponding statement
    public static Statement parseStatement(String s) {
        ASTParser parser = ASTParser.newParser(AST.JLS13);
        parser.setSource(s.toCharArray());
        parser.setKind(ASTParser.K_STATEMENTS);

        Block block = (Block) parser.createAST(null);

        //here can access the first element of the returned statement list
        if (block.statements().size() <= 0) {
            return null;
        } else {
            return (Statement) block.statements().get(0);
        }
    }

    public static double getTokensWeight(Collection<String> tokens, Map<String, Integer> distanceMap, double c) {
        double sum = 0.0;
        for (String token : tokens) {
            if (Math.abs(c - 0.0) < 0.00001) {
                sum += 1;
            } else {
                sum += Math.exp(-1 * c * distanceMap.get(token));
            }
        }
        return sum;
    }

    public static int getDistance(String name, Collection<JavaFileToken> javaFileTokens, int maxDistance) {
        int distance = maxDistance;
        for (JavaFileToken javaFileToken : javaFileTokens) {
            if (javaFileToken.getName().equals(name) && (javaFileToken.getType() > 0) && javaFileToken.getDistance() < distance) {
                distance = javaFileToken.getDistance();
            }
        }
        return distance;
    }

    public static Map<String, Integer> getDistanceMap(Collection<String> tokens, Collection<JavaFileToken> javaFileTokens, int maxDistance) {
        Map<String, Integer> map = new HashMap<>();
        for (String name : tokens) {
            int distance = getDistance(name, javaFileTokens, maxDistance);
            map.put(name, distance);
        }
        return map;
    }


    public static double getTokensWeightWithoutDistance(Collection<String> tokens, Map<String, Integer> distanceMap, double c) {
        double sum = 0.0;
        for (String token : tokens) {
            if (Math.abs(c - 0.0) < 0.00001) {
                sum += 1;
            } else {
                if (distanceMap.get(token) == 0) {
                    sum += 1;
                } else {
                    sum += Math.exp(-1 * c * 1);
                }
            }
        }
        return sum;
    }
}
