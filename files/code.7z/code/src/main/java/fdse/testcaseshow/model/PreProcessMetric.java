package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "pre_process_metrics")
public class PreProcessMetric {
    @Id
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;

    @Column(name = "crash")
    private boolean isCrash;

    @Column(name = "cluster_number")
    private int clusterNumber;

    @Column(name = "commit_number")
    private int commitNumber;

    @Column(name = "files_changed")
    private int filesChanged;

    @Column(name = "files_added")
    private int filesAdded;

    @Column(name = "files_deleted")
    private int filesDeleted;

    @Column(name = "files_modified")
    private int filesModified;

    @Column(name = "selected_files_changed")
    private int selectedFilesChanged;

    @Column(name = "src_churn")
    private int srcChurn;

    @Column(name = "test_churn")
    private int testChurn;

    @Column(name = "line_changed")
    private int lineChanged;

    @Column(name = "line_added")
    private int lineAdded;

    @Column(name = "line_deleted")
    private int lineDeleted;

    @Column(name = "src_files")
    private int srcFiles;

    @Column(name = "test_files")
    private int testFiles;

    @Column(name = "class_changed")
    private int classChanged;

    @Column(name = "class_added")
    private int classAdded;

    @Column(name = "class_deleted")
    private int classDeleted;

    @Column(name = "class_modified")
    private int classModified;

    @Column(name = "met_changed")
    private int metChanged;

    @Column(name = "met_added")
    private int metAdded;

    @Column(name = "met_deleted")
    private int metDeleted;

    @Column(name = "met_modified")
    private int metModified;

    @Column(name = "field_changed")
    private int fieldChanged;

    @Column(name = "field_added")
    private int fieldAdded;

    @Column(name = "field_deleted")
    private int fieldDeleted;

    @Column(name = "field_modified")
    private int fieldModified;

    @Column(name = "class_added_modified")
    private int classAddedModified;

    @Column(name = "met_added_modified")
    private int metAddedModified;

    @Column(name = "field_added_modified")
    private int fieldAddedModified;

    @Column(name = "mf_changed")
    private int mfChanged;

    @Column(name = "mf_added_modified")
    private int mfAddedModified;
}