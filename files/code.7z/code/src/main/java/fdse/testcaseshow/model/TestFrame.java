package fdse.testcaseshow.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.rest.core.annotation.RestResource;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access= AccessLevel.PUBLIC, force=true)
@Entity
@Table(name = "test_frames")
public class TestFrame {
    @Id
    private long id;

    @Column(name = "order_num")
    private int order;

    @Column(name = "frame")
    private String frame;

    @Column(name = "package_name")
    private String packageName;

    @Column(name = "type_name")
    private String typeName;

    @Column(name = "method_name")
    private String methodName;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "line_num")
    private Integer lineNum;

    @Column(name = "distance")
    private Integer distance;

    @Column(name = "type")
    private Integer type;

    @OneToMany(targetEntity = TestFrameDistance.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "testFrame")
    private List<TestFrameDistance> distances = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_item_id")
    private TestItem testItem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;

    @ManyToOne(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name="java_file_id")
    private JavaFile javaFile;
}
