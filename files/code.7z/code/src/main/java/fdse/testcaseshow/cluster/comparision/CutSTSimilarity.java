package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.AHCluster;
import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.log.STLength;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestFrame;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CutSTSimilarity extends AHCluster {
    public CutSTSimilarity(List<DataPoint> dataPoints, double sMax) {
        super(dataPoints, sMax);
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {

        if (tiA.getClassName() != null && tiA.getMethodName() != null && tiB.getClassName() != null && tiB.getMethodName() != null
                && tiA.getClassName().equals(tiB.getClassName())
                && tiA.getMethodName().equals(tiB.getMethodName())) {
            return 1.0;
        }

        List<String> aList = getFrameList(tiA);
        List<String> bList = getFrameList(tiB);
        if (aList.size() == 0 || bList.size() == 0)
            return 0.0;
        double numerator = 0.0;
        double denominator = 0.0;
        for (String aFrame:aList) {
            for (String bFrame:bList) {
                if (aFrame.equals(bFrame)) {
                    numerator += 2;
                }
            }
        }
        double sim = numerator / (aList.size() + bList.size());
        return sim;
    }


    public List<String> getFrameList(TestItem testItem) {
        List<String> list = new ArrayList<>();
        testItem.getTestFrames().forEach(f -> {
            String s = f.getFrame().trim();
            if (s.startsWith("at")) {
                if (f.getDistance() <= 1)
                    list.add(s);
            }
        });
        return list;
    }

    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new fdse.testcaseshow.cluster.comparision.CutSTSimilarity(dataPoints, sMax).startCluster();
    }


    public static List<Cluster> clusterBuild(double sMax, TestCase testCase) {
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        return clusterBuild(sMax, selectedTestItems);
    }

    public static void run() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.CUTSTSIMILARITY, true, null)) {
                for (double sMax = 0.01; sMax < 1; sMax += 0.01) {
                    System.out.println(sMax);
                    ResultSummary resultSummary = new STSimilarityResultSummary(new STSimilarity.Coefficient(sMax, 0, 0));
                    for (TestCase testCase : testCases) {
                        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                        List<Cluster> clusters = CutSTSimilarity.clusterBuild(sMax, selectedTestItems);
                        resultSummary.addSingleResult(testCase, clusters, true);
                    }
                    storeResultSummary.write(resultSummary);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }

    }

    public static void main(String[] args) throws IOException {
        CutSTSimilarity.run();
    }
}
