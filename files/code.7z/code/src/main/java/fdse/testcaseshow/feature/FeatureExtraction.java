package fdse.testcaseshow.feature;

import com.github.gumtreediff.actions.EditScript;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.tree.Tree;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fdse.testcaseshow.model.PreProcessMetric;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.MysqlUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.javatuples.Quintet;

import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class FeatureExtraction {

    public static final Pattern testFilePattern = Pattern.compile("/tests?/|[tT]est\\.java");

    public static boolean isTestFile(String path) {
        if (path.endsWith(".java") && testFilePattern.matcher(path).find()) {
            return true;
        }
        return false;
    }

    public static JsonArray getChangedFiles(String repoName, String jobNumber) {
        JsonObject obj = DiffJsonParser.getJsonObject(repoName, jobNumber);
        return obj.getAsJsonArray("files");
    }

    public static JsonArray getChangedFiles(TestCase testCase) {
        return getChangedFiles(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static Collection<String> getChangedFileNames(String repoName, String jobNumber) {
        JsonArray jsonArray = getChangedFiles(repoName, jobNumber);
        Collection<String> changedFileNames = new ArrayList<>();
        for (JsonElement element : jsonArray) {
            changedFileNames.add(element.getAsJsonObject().getAsJsonPrimitive("filename").getAsString());
        }
        return changedFileNames;
    }

    public static Collection<String> getChangedFileNames(TestCase testCase) {
        return getChangedFileNames(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int changeConfigFile(TestCase testCase) {
        int flag = 0;
        Collection<String> changedFiles = getChangedFileNames(testCase);
        for (String changedFile : changedFiles) {
            if (changedFile.endsWith("pom.xml") || changedFile.endsWith("gradle") || changedFile.endsWith("travis")) {
                // System.out.println(changedFile);
                flag = 1;
                break;
            }
        }
        return flag;
    }

    /**
     *
     * @param testCase
     * @return
     */
    public static Collection<String> getSelectedChangedFiles(TestCase testCase) {
        List<String> list = new ArrayList<>();
        ChangedInfo changedInfo = new ChangedInfo(testCase);
        List<Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript>> diffFileActionsMap = null;
        try {
            diffFileActionsMap = changedInfo.getDiffFileASTInfos();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript> entry : diffFileActionsMap) {
            String filePath = entry.getValue0().getCurrentFilePath();
            String status = entry.getValue0().getStatus();
            if (filePath.endsWith(".java")) {
                if (status.equals("modified") || status.equals("renamed")) {
                    List<Action> selectedActions = changedInfo.getValidatedActions(entry.getValue1(), entry.getValue2(), entry.getValue3(), entry.getValue4());
                    if (selectedActions.size() > 0) {
                        list.add(filePath);
                    }
                } else {
                    list.add(filePath);
                }
            } else if (filePath.endsWith(".txt") || filePath.endsWith(".html")) {
                list.add(filePath);
            }
        }
        return list;
    }

    public static int src_churn(String repoName, String jobNumber) {
        int srcChurn = 0;
        JsonArray files = getChangedFiles(repoName, jobNumber);
        for (JsonElement element : files) {
            String filename = element.getAsJsonObject().getAsJsonPrimitive("filename").getAsString();
            int changes = element.getAsJsonObject().getAsJsonPrimitive("changes").getAsInt();
            if (isTestFile(filename) == false) {
                srcChurn += changes;
            }
        }
        return srcChurn;
    }

    public static int src_churn(TestCase testCase) {
        return  src_churn(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int test_churn(String repoName, String jobNumber) {
        int testChurn = 0;
        JsonArray files = getChangedFiles(repoName, jobNumber);
        for (JsonElement element : files) {
            String filename = element.getAsJsonObject().getAsJsonPrimitive("filename").getAsString();
            int changes = element.getAsJsonObject().getAsJsonPrimitive("changes").getAsInt();
            if (isTestFile(filename)) {
                testChurn += changes;
            }
        }
        return testChurn;
    }

    public static int test_churn(TestCase testCase) {
        return  test_churn(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int line(String repoName, String jobNumber, String mark) {
        int lineAdded = 0;
        JsonArray files = getChangedFiles(repoName, jobNumber);
        for (JsonElement element : files) {
            int additions = element.getAsJsonObject().getAsJsonPrimitive(mark).getAsInt();
            lineAdded += additions;
        }
        return lineAdded;
    }

    public static int line_added(TestCase testCase) {
        return line(testCase.getRepoName(), testCase.getJobNumber(), "additions");
    }

    public static int line_deleted(TestCase testCase) {
        return line(testCase.getRepoName(), testCase.getJobNumber(), "deletions");
    }

    public static int files_added_deleted_modified(String repoName, String jobNumber, String status) {
        int num = 0;
        JsonArray files = getChangedFiles(repoName, jobNumber);
        for (JsonElement element : files) {
            String s = element.getAsJsonObject().getAsJsonPrimitive("status").getAsString();
            if (status.equals(s)) {
                num += 1;
            }
        }
        return num;
    }

    public static int files_added(String repoName, String jobNumber) {
        return files_added_deleted_modified(repoName, jobNumber, "added");
    }

    public static int files_added(TestCase testCase) {
        return files_added(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int files_deleted(String repoName, String jobNumber) {
        return files_added_deleted_modified(repoName, jobNumber, "removed");
    }

    public static int files_deleted(TestCase testCase) {
        return files_deleted(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int files_modified(String repoName, String jobNumber) {
        return files_added_deleted_modified(repoName, jobNumber, "modified") + files_added_deleted_modified(repoName, jobNumber, "renamed");
    }

    public static int files_modified(TestCase testCase) {
        return files_modified(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int src_files(String repoName, String jobNumber) {
        Collection<String> changedFileNames = getChangedFileNames(repoName, jobNumber);
        int count = 0;
        for (String name : changedFileNames) {
            if (isTestFile(name) == false) {
                count += 1;
            }
        }
        return count;
    }

    public static int src_files(TestCase testCase) {
        return src_files(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int test_files(String repoName, String jobNumber) {
        Collection<String> changedFileNames = getChangedFileNames(repoName, jobNumber);
        int count = 0;
        for (String name : changedFileNames) {
            if (isTestFile(name)) {
                count += 1;
            }
        }
        return count;
    }

    public static int test_files(TestCase testCase) {
        return test_files(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int config_files(String repoName, String jobNumber) {
        return 0;
    }

    public static int config_files(TestCase testCase) {
        return config_files(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int doc_files(String repoName, String jobNumber) {
        return 0;
    }

    public static int doc_files(TestCase testCase) {
        return doc_files(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int class_changed(ChangedInfo changedInfo) {
        Set<Token> set = changedInfo.getChangedClassTokens();
        Set<String> classNames = new HashSet<>();
        for (Token token : set) {
            classNames.add(token.getName());
        }
        return classNames.size();
    }

    public static int class_changed(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return class_changed(changedInfo);
    }

    public static int class_added_deleted_modified(ChangedInfo changedInfo, TokenStatus mark) {
        Set<Token> set = changedInfo.getChangedClassTokens();
        Set<String> classNames = new HashSet<>();
        for (Token token : set) {
            if (token.getStatus() == mark) {
                classNames.add(token.getName());
            }
        }
        return classNames.size();
    }

    public static int class_modified(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return class_added_deleted_modified(changedInfo, TokenStatus.MODIFIED);
    }

    public static int class_added(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return class_added_deleted_modified(changedInfo, TokenStatus.ADDED);
    }

    public static int class_deleted(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return class_added_deleted_modified(changedInfo, TokenStatus.DELETED);
    }

    public static int met_changed(ChangedInfo changedInfo) {
        Set<Token> set = changedInfo.getChangedMethodTokens();
        Set<String> methodNames = new HashSet<>();
        for (Token token : set) {
            methodNames.add(token.getName());
        }
        return methodNames.size();
    }

    public static int met_changed(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return met_changed(changedInfo);
    }

    public static int met_added_deleted_modified(ChangedInfo changedInfo, TokenStatus mark) {
        Set<Token> set = changedInfo.getChangedMethodTokens();
        Set<String> methodNames = new HashSet<>();
        for (Token token : set) {
            if (token.getStatus() == mark) {
                methodNames.add(token.getName());
            }
        }
        return methodNames.size();
    }

    public static int met_modified(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return met_added_deleted_modified(changedInfo, TokenStatus.MODIFIED);
    }

    public static int met_added(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return met_added_deleted_modified(changedInfo, TokenStatus.ADDED);
    }

    public static int met_deleted(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return met_added_deleted_modified(changedInfo, TokenStatus.DELETED);
    }

    public static int field_changed(ChangedInfo changedInfo) {
        Set<Token> set = changedInfo.getChangedFieldTokens();
        Set<String> fieldNames = new HashSet<>();
        for (Token token : set) {
            fieldNames.add(token.getName());
        }
        return fieldNames.size();
    }

    public static int field_changed(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return field_changed(changedInfo);
    }

    public static int field_added_deleted_modified(ChangedInfo changedInfo, TokenStatus mark) {
        Set<Token> set = changedInfo.getChangedFieldTokens();
        Set<String> fieldNames = new HashSet<>();
        for (Token token : set) {
            if (token.getStatus() == mark) {
                fieldNames.add(token.getName());
            }
        }
        return fieldNames.size();
    }

    public static int field_modified(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return field_added_deleted_modified(changedInfo, TokenStatus.MODIFIED);
    }

    public static int field_added(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return field_added_deleted_modified(changedInfo, TokenStatus.ADDED);
    }

    public static int field_deleted(TestCase testCase) {
        ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
        return field_added_deleted_modified(changedInfo, TokenStatus.DELETED);
    }

    public static int commit_number(String content) {
        JsonObject obj = JsonParser.parseString(content).getAsJsonObject();
        JsonArray jsonArray = obj.getAsJsonArray("commits");
//        for (JsonElement element : jsonArray) {
//            System.out.println(element.getAsJsonObject().getAsJsonPrimitive("sha"));
//        }
        return jsonArray.size();
    }

    public static int commit_number(String repoName, String jobNumber) {
        String content = DiffJsonParser.getContentOfDiffJsonFile(repoName, jobNumber);
        return commit_number(content);
    }

    public static int commit_number(TestCase testCase) {
        return commit_number(testCase.getRepoName(), testCase.getJobNumber());
    }

    public static int file_changed(TestCase testCase) {
        return getChangedFileNames(testCase).size();
    }

    public static PreProcessMetric createPreProcessMetric(TestCase testCase, long id, boolean crash) {
        PreProcessMetric preProcessMetric = new PreProcessMetric();
        preProcessMetric.setId(id);
        preProcessMetric.setTestCase(testCase);
        preProcessMetric.setCrash(crash);
        if (crash) {
            preProcessMetric.setClusterNumber(testCase.getCrashClusterNum());
        } else {
            preProcessMetric.setClusterNumber(testCase.getAssertionClusterNum());
        }
        preProcessMetric.setCommitNumber(commit_number(testCase));

        preProcessMetric.setFilesChanged(file_changed(testCase));
        preProcessMetric.setFilesAdded(files_added(testCase));
        preProcessMetric.setFilesDeleted(files_deleted(testCase));
        preProcessMetric.setFilesModified(files_modified(testCase));
        preProcessMetric.setSelectedFilesChanged(getSelectedChangedFiles(testCase).size());

        preProcessMetric.setSrcChurn(src_churn(testCase));
        preProcessMetric.setTestChurn(test_churn(testCase));

        preProcessMetric.setLineChanged(line_added(testCase) + line_deleted(testCase));
        preProcessMetric.setLineAdded(line_added(testCase));
        preProcessMetric.setLineDeleted(line_deleted(testCase));

        preProcessMetric.setSrcFiles(src_files(testCase));
        preProcessMetric.setTestFiles(test_files(testCase));

        preProcessMetric.setClassChanged(class_changed(testCase));
        preProcessMetric.setClassAdded(class_added(testCase));
        preProcessMetric.setClassDeleted(class_deleted(testCase));
        preProcessMetric.setClassModified(class_modified(testCase));

        preProcessMetric.setMetChanged(met_changed(testCase));
        preProcessMetric.setMetAdded(met_added(testCase));
        preProcessMetric.setMetDeleted(met_deleted(testCase));
        preProcessMetric.setMetModified(met_modified(testCase));

        preProcessMetric.setFieldChanged(field_changed(testCase));
        preProcessMetric.setFieldAdded(field_added(testCase));
        preProcessMetric.setFieldDeleted(field_deleted(testCase));
        preProcessMetric.setFieldModified(field_modified(testCase));

        preProcessMetric.setClassAddedModified(class_added(testCase) + class_modified(testCase));
        preProcessMetric.setMetAddedModified(met_added(testCase) + met_modified(testCase));
        preProcessMetric.setFieldAddedModified(field_added(testCase) + field_modified(testCase));

        preProcessMetric.setMfChanged(preProcessMetric.getMetChanged() + preProcessMetric.getFieldChanged());
        preProcessMetric.setMfAddedModified(preProcessMetric.getMetAddedModified() + preProcessMetric.getFieldAddedModified());


        return preProcessMetric;
    }

    public static void exchange(PreProcessMetric mA, PreProcessMetric mB) {
        TestCase temp = mA.getTestCase();
        mA.setTestCase(mB.getTestCase());
        mB.setTestCase(temp);
    }
    /**
     * 交换数据
     * 145和45交换
      */
    public static void exchange() {
        Session session = SessionUtil.getSession();
        Transaction tx = session.beginTransaction();
        Query<PreProcessMetric> crashQuery = session.createQuery("from PreProcessMetric where isCrash = true and (testCase.id = 145 or testCase.id = 45)", PreProcessMetric.class);
        List<PreProcessMetric> preProcessMetrics = crashQuery.list();
        exchange(preProcessMetrics.get(0), preProcessMetrics.get(1));
        tx.commit();
        session.close();
    }

    public static void run() {
        Session session = SessionUtil.getSession();
        Transaction tx = session.beginTransaction();
        session.createSQLQuery("delete from pre_process_metrics").executeUpdate();
        long id = 1L;
        List<TestCase> crashTestCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : crashTestCases) {
            PreProcessMetric preProcessMetric = createPreProcessMetric(testCase, id,true);
            id++;
            session.save(preProcessMetric);
        }

        List<TestCase> assertionTestCases = MysqlUtil.getAssertionTestCases(session);
        for (TestCase testCase : assertionTestCases) {
            PreProcessMetric preProcessMetric = createPreProcessMetric(testCase, id,false);
            id++;
            session.save(preProcessMetric);
        }
        tx.commit();
        session.close();

        // exchange();
    }

    public static void main(String[] args) {
        FeatureExtraction.run();
    }


}
