package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.comparision.AHClusterOld;
import fdse.testcaseshow.cluster.comparision.Rebucket;
import fdse.testcaseshow.cluster.evaluation.RebucketResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class RebucketSlave implements Runnable{
    private BlockingQueue<Rebucket.Coefficient> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<ResultSummary> outQueue;

    public RebucketSlave(List<TestCase> testCases, BlockingQueue<Rebucket.Coefficient> inQueue, BlockingQueue<ResultSummary> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
        this.testCases = testCases;
    }

    public Rebucket.Coefficient getCoefficient() {
        Rebucket.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true) {
            Rebucket.Coefficient coefficient = getCoefficient();
            if (coefficient.getSMax() < 0) {
                break;
            }
            ResultSummary resultSummary = new RebucketResultSummary(coefficient);
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);

                List<Cluster> clusters = AHClusterOld.clusterBuild(coefficient.getCoC(), coefficient.getCoO(), coefficient.getSMax(), selectedTestItems);
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            putResult(resultSummary);
        }

    }
}
