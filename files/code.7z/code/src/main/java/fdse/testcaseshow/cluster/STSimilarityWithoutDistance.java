package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.comparision.CutSTSimilarity;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.log.STLength;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestFrame;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import lombok.*;
import org.hibernate.Session;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class STSimilarityWithoutDistance extends AHCluster {
    private double c;
    private int methodMatchDistance;
    private int fileMatchDistance;
    private int noMatchDistance;
    private static Map<Long, List<Frame>> frameListMap = new HashMap<>();
    public STSimilarityWithoutDistance(List<DataPoint> dataPoints, double sMax, double c, int methodMatchDistance, int fileMatchDistance, int noMatchDistance) {
        super(dataPoints, sMax);
        this.c = c;
        this.methodMatchDistance = methodMatchDistance;
        this.fileMatchDistance = fileMatchDistance;
        this.noMatchDistance = noMatchDistance;
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {
        List<Frame> aList = getFrameList(tiA);
        List<Frame> bList = getFrameList(tiB);
        if (aList.size() == 0 || bList.size() == 0)
            return 0.0;
        List<Frame> aListClone = new ArrayList<>();
        List<Frame> bListClone = new ArrayList<>();
        for (Frame aFrame : aList) {
            aListClone.add(aFrame.copy());
        }
        for (Frame bFrame : bList) {
            bListClone.add(bFrame.copy());
        }
        for (Frame aFrame : aListClone) {
            for (Frame bFrame : bListClone) {
                if (aFrame.equals(bFrame)) {
                    aFrame.setMatch(true);
                    bFrame.setMatch(true);
                }
            }
        }

        double sim = getSimilarity(aListClone, bListClone);
        return sim;
    }

    public double getSimilarity(List<Frame> aList, List<Frame> bList) {
        double numerator = 0.0;
        double denominator = 0.0;
        aList.addAll(bList);
        for (Frame frame:aList) {
            denominator += Math.exp(-1 * c * frame.getDistance());
            if (frame.isMatch()) {
                numerator += Math.exp(-1 * c * frame.getDistance());
            }
        }
        return numerator / denominator;
    }

    public List<Frame> getFrameList(TestItem testItem) {
        if (frameListMap.get(testItem.getId()) != null)
            return frameListMap.get(testItem.getId());
        List<Frame> list = new ArrayList<>();
        testItem.getTestFrames().forEach(f -> {
            String s = f.getFrame().trim();
            if (s.startsWith("at")) {
                Frame frame = new Frame();
                frame.setFrame(s);
                if (f.getDistance() == 0) {
                    frame.setDistance(this.methodMatchDistance);
                } else if (f.getDistance() == 1) {
                    frame.setDistance(this.fileMatchDistance);
                } else {
                    frame.setDistance(this.noMatchDistance);
                }
                list.add(frame);
            }
        });
        if (list.size() <= 0) {
            testItem.getTestFrames().forEach(f -> {
                String s = f.getFrame().trim();
                if (s.startsWith("at")) {
                    Frame frame = new Frame();
                    frame.setFrame(s);
                    if (f.getDistance() == 0) {
                        frame.setDistance(this.methodMatchDistance);
                    } else if (f.getDistance() == 1) {
                        frame.setDistance(this.fileMatchDistance);
                    } else {
                        frame.setDistance(this.noMatchDistance);
                    }
                    list.add(frame);
                }
            });
        }
        frameListMap.put(testItem.getId(), list);
        return list;
    }

    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild( List<TestItem> testItems, double sMax, double c, int methodMatchDistance, int fileMatchDistance, int noMatchDistance) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new STSimilarityWithoutDistance(dataPoints, sMax, c, methodMatchDistance, fileMatchDistance, noMatchDistance).startCluster();
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    private static class Frame {
        private String frame;
        private int distance;
        private boolean match = false;

        public boolean equals(Frame o) {
            if (this == o) return true;
            if (o == null) return false;
            if (this.getFrame().equals(o.getFrame())) return true;
            return false;
        }

        protected Frame copy() {
            return new Frame(this.frame, this.distance, false);
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private double sMax;
        private double c;
        private int methodMatchDistance;
        private int fileMatchDistance;
        private int noMatchDistance;
    }
}
