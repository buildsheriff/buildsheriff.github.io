package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.FileUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ExtractJavaFile {
    private BlockingQueue<InJavaFile> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<OutJavaFile> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 20;
    @Data
    @AllArgsConstructor
    public static class InJavaFile {
        private Long testCaseId;
        private String filePath;
        private String repoPath;
    }
    @Data
    @AllArgsConstructor
    public static class OutJavaFile {
        private Long testCaseId;
        private JavaFile javaFile;
    }
    private void clearJavaFile() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete JavaFile";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            int autoIncrement = session.createSQLQuery("ALTER TABLE java_files AUTO_INCREMENT = 1").executeUpdate();
            updatedEntities = session.createSQLQuery("delete from java_file_type_names").executeUpdate();
            autoIncrement = session.createSQLQuery("ALTER TABLE java_file_type_names AUTO_INCREMENT = 1").executeUpdate();

            tx.commit();
        }
    }

    private void setChanged() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            int updatedEntities = session.createNativeQuery("update triage.java_files j, triage.changed_files c set j.changed=true where j.test_case_id = c.test_case_id and j.complete_file_name = c.current_file_path;").executeUpdate();
            tx.commit();
        }
    }
    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new ExtractJavaFileTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }
    public void extractJavaFileInfo() throws IOException {
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreJavaFileTask(outQueue));
        initializeThreads(threads, storeThread);
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id <= 93 and ((multipleCrash = true and crashIgnore = false) or (multipleAssertion = true and assertionIgnore = false))", TestCase.class);
            List<TestCase> testCases = query.list();
            for (TestCase testCase : testCases) {
                extractJavaFileInfo(testCase);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
        for (int i = 0; i < THREAD_NUMBER; i++) {
            InJavaFile sentry = new InJavaFile(-1L, null, null);
            putInJavaFile(sentry);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            OutJavaFile outJavaFile = new OutJavaFile(-1L, null);
            outQueue.put(outJavaFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        setChanged();
    }
    private void putInJavaFile(InJavaFile inJavaFile) {
        try {
            inQueue.put(inJavaFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void extractJavaFileInfo(TestCase testCase) throws IOException {
        if (testCase.getCurrentCommit() == null || testCase.getCurrentCommit().equals("null")) {
            return;
        }
        String repoPath = FileUtil.getRepoPath(testCase.getCurrentCommit().trim());
        if (repoPath == null) {
            throw new IOException(" " + testCase.getId() + "-" + testCase.getRepoName() + "-" + testCase.getJobNumber() + "-" + testCase.getCurrentCommit() );
        }
        List<String> javaFiles = FileUtil.getJavaFiles(repoPath);
        for (int i = 0; i < javaFiles.size(); i++) {
            String filePath = javaFiles.get(i);
            putInJavaFile(new InJavaFile(testCase.getId(), filePath, repoPath));
        }
    }

    public static void main(String[] args) throws IOException {
        Instant start = Instant.now();
        ExtractJavaFile extractJavaFile = new ExtractJavaFile();
        extractJavaFile.extractJavaFileInfo();
        Instant end = Instant.now();
        System.out.println("" + Duration.between(start, end));
    }
}
