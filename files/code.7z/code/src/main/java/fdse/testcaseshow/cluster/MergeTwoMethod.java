package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.evaluation.CombineRatioResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.cluster.combine.MergeRatioSimilarity;
import fdse.testcaseshow.model.Sim;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.io.FileNotFoundException;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class MergeTwoMethod extends AHCluster {
//    private int maxDistance;
    private double ratio;
    Collection<Sim> sims;
    public MergeTwoMethod(List<DataPoint> dataPoints, double sMax, double ratio, Collection<Sim> sims) {
        super(dataPoints, sMax);
        this.ratio = ratio;
        this.sims = sims;
    }

    private double getSim(long aId, long bId, int type) {
        for (Sim sim : sims) {
            if (sim.getType() == type && sim.getTestItemAID() == aId && sim.getTestItemBID() == bId)
                return sim.getSim();
        }
        return 0.0;
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {
        double stSim = getSim(testItem1.getId(), testItem2.getId(), StoreSim.Type.STSimilarity.getValue());
        double exSim = getSim(testItem1.getId(), testItem2.getId(), StoreSim.Type.ExceptionSimilarity.getValue());
        return ratio * stSim + (1 - ratio) * exSim;
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(List<TestItem> testItems, double sMax, double ratio, Collection<Sim> sims) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new MergeTwoMethod(dataPoints, sMax, ratio, sims).startCluster();
    }

    public static void main(String[] args) {
        new MergeMaster().tuning();
    }
}

class MergeMaster {
    private BlockingQueue<InQueuedata> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);

    private static final int THREAD_NUMBER = 20;
    private void initializeThreads(List<Thread> threads, Thread thread, List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new MergeSlave(testCases, inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    private void putInQueuedata(InQueuedata inQueuedata) {
        try {
            inQueue.put(inQueuedata);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public Map<Long, Collection<Sim>> createSimsMap(Session session, List<TestCase> testCases, double c, int maxDistance) {
        Map<Long, Collection<Sim>> simsMap = new HashMap<>();
        String cs = String.format("%.2f", c);
        List<Sim> list = new ArrayList<>();
        for (TestCase testCase : testCases) {
            Query<Sim> simQuery = session.createQuery("from Sim s where  s.testCase = :testCase and s.type = 0 and s.c = :cs and s.maxDistance = :maxDistance", Sim.class).
                    setParameter("testCase", testCase).
                    setParameter("cs", cs).
                    setParameter("maxDistance", maxDistance);
            list.addAll(simQuery.getResultList());
            simQuery = session.createQuery("from Sim s where  s.testCase = :testCase and s.type = 1", Sim.class).
                    setParameter("testCase", testCase);
            list.addAll(simQuery.getResultList());
            simsMap.put(testCase.getId(), list);
        }
        return simsMap;
    }

    public void tuning() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : testCases) {
            testCase.getTestItems().size();
        }

        MergeCollect mergeCollectTask = new MergeCollect(this.outQueue);
        Thread collectThread = new Thread(mergeCollectTask);
        List<Thread> threads = new ArrayList<>();
        initializeThreads(threads, collectThread, testCases);
        for (double sMax = 0.01; sMax < 1; sMax += 0.01) {
            for (double c = 0.1; c < 2; c += 0.1) {
                    for (double ratio = 0.1; ratio < 1; ratio += 0.1) {
                        MergeRatioSimilarity.Coefficient coefficient = new MergeRatioSimilarity.Coefficient(c, 7, ratio, sMax);
                        System.out.println(coefficient);
                        Map<Long, Collection<Sim>> simsMap = createSimsMap(session, testCases, c, 7);
                        putInQueuedata(new InQueuedata(coefficient, simsMap));
                    }
            }
        }
        session.close();
        for (int i = 0; i < THREAD_NUMBER; i++) {
            putInQueuedata(new InQueuedata(null, null));
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        try {
            ResultSummary resultSummary = new CombineRatioResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @AllArgsConstructor
    @Getter
    public static class InQueuedata {
        private MergeRatioSimilarity.Coefficient coefficient;
        private Map<Long, Collection<Sim>> simsMap;
    }

    public static void main(String[] args) {
        new MergeMaster().tuning();
    }
}

class MergeSlave implements Runnable {
    private BlockingQueue<MergeMaster.InQueuedata> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<ResultSummary> outQueue;
    public MergeSlave(List<TestCase> testCases, BlockingQueue<MergeMaster.InQueuedata> inQueue, BlockingQueue<ResultSummary> outQueue) {
        this.inQueue = inQueue;
        this.testCases = testCases;
        this.outQueue = outQueue;
    }

    public MergeMaster.InQueuedata getInQueuedata() {
        MergeMaster.InQueuedata inQueuedata = null;
        try {
            inQueuedata = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return inQueuedata;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true) {
            MergeMaster.InQueuedata inQueuedata = getInQueuedata();
            if (inQueuedata.getSimsMap() == null) {
                break;
            }
            MergeRatioSimilarity.Coefficient coefficient = inQueuedata.getCoefficient();
            ResultSummary resultSummary = new CombineRatioResultSummary(null);
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<Cluster> clusters = MergeTwoMethod.clusterBuild(selectedTestItems, coefficient.getSMax(), coefficient.getRatio(), inQueuedata.getSimsMap().get(testCase.getId()));
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            putResult(resultSummary);

        }

    }
}

class MergeCollect implements Runnable {
    private BlockingQueue<ResultSummary> outQueue;
    @Getter
    private List<ResultSummary> resultSummaryList = new ArrayList<>();

    public MergeCollect(BlockingQueue<ResultSummary> outQueue) {
        this.outQueue = outQueue;
    }

    public ResultSummary getResult() {
        ResultSummary resultSummary = null;
        try {
            resultSummary = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return resultSummary;
    }
    @Override
    public void run() {
        try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.MERGERATIO, true, null)) {
            while (true) {
                CombineRatioResultSummary resultSummary = (CombineRatioResultSummary) getResult();
                if (resultSummary.getCoefficient() == null)
                    break;

                storeResultSummary.write(resultSummary);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
