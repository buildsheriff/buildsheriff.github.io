package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.util.FileUtil;

import java.util.Collection;
import java.util.Map;

public class StatementMatchOne implements IStatementMatch {
    private volatile static StatementMatchOne statementMatchOne;
    private StatementMatchOne() { }

    public static StatementMatchOne getInstance() {
        if (statementMatchOne == null) {
            synchronized (StatementMatchOne.class) {
                if (statementMatchOne == null) {
                    statementMatchOne = new StatementMatchOne();
                }
            }
        }
        return statementMatchOne;
    }

    @Override
    public double getStatementSim(Collection<String> statementTokens, Collection<Collection<String>> statementTokensList, Map<String, Integer> distanceMap, double matchThreshold, double c) {
        double maxSim = 0.0;
        double divisorA = CodeSimUtil.getTokensWeight(statementTokens, distanceMap, c);
        for (Collection<String> list : statementTokensList) {
            double divisorB = CodeSimUtil.getTokensWeight(list, distanceMap, c);
            Collection<String> interSection = FileUtil.intersection(statementTokens, list);
            double dividend = CodeSimUtil.getTokensWeight(interSection, distanceMap, c);
            double sim = 2.0 * dividend / (divisorA + divisorB);
            if (sim > maxSim) {
                maxSim = sim;
            }
            if (maxSim > matchThreshold) {
                break;
            }
        }
        return maxSim;
    }

}
