package fdse.testcaseshow.cluster;

import java.util.Arrays;
import java.util.List;

public class EditDistance {

    public static int minDistance(List<String> sourceStr, List<String> targetStr){
        int sourceLen = sourceStr.size();
        int targetLen = targetStr.size();

        if(sourceLen == 0){
            return targetLen;
        }
        if(targetLen == 0){
            return sourceLen;
        }

        int[][]  arr = new int[sourceLen+1][targetLen+1];

        for(int i=0; i < sourceLen+1; i++){
            arr[i][0] = i;
        }
        for(int j=0; j < targetLen+1; j++){
            arr[0][j] = j;
        }

        String sourceChar = null;
        String targetChar = null;

        for(int i=1; i < sourceLen+1 ; i++){
            sourceChar = sourceStr.get(i-1);

            for(int j=1; j < targetLen+1 ; j++){
                targetChar = targetStr.get(j-1);

                if(sourceChar.equals(targetChar)){

                    arr[i][j] = arr[i-1][j-1];
                }else{

                    arr[i][j] = (Math.min(Math.min(arr[i-1][j], arr[i][j-1]), arr[i-1][j-1])) + 1;
                }
            }
        }

        return arr[sourceLen][targetLen];
    }

    public static int minDistance(String str1, String str2){
        List<String> list1 = Arrays.asList(str1.split(" "));
        List<String> list2 = Arrays.asList(str2.split(" "));
        return minDistance(list1, list2);
    }
    public static double getsimilarity(List<String> str1, List<String> str2){
        double distance = minDistance(str1,str2);
        double maxlen = Math.max(str1.size(),str2.size());
        double res = (maxlen - distance)/maxlen;


        return res;
    }

    public static double getsimilarity(String str1, String str2){
        List<String> list1 = Arrays.asList(str1.split(" "));
        List<String> list2 = Arrays.asList(str2.split(" "));

        return getsimilarity(list1, list2);
    }

    public static String evaluate(List<String> str1, List<String> str2) {
        double result = getsimilarity(str1,str2);
        return String.valueOf(result);
    }

    public static void main(String[] args) {
    }

}