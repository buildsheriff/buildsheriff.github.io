package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.comparision.Rebucket;
import fdse.testcaseshow.cluster.evaluation.RebucketResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class RebucketMaster {
    private BlockingQueue<Rebucket.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);

    private static final int THREAD_NUMBER = 1;
    private void initializeThreads(List<Thread> threads, Thread thread, List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new RebucketSlave(testCases, inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    private void putCoefficient(Rebucket.Coefficient coefficient) {
        try {
            inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void tuning() {
        List<TestCase> testCases = null;
        try(Session session = SessionUtil.getSession()) {
            testCases = MysqlUtil.getCrashTestCases(session);
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    testItem.getTestFrames().size();
                }
            }
        }
        RebucketCollect rebucketCollect = new RebucketCollect(outQueue);
        Thread collectThread = new Thread(rebucketCollect);
        List<Thread> threads = new ArrayList<>();
        initializeThreads(threads, collectThread, testCases);
        for (double coC = 0.1; coC < 0.2; coC += 0.1) {
            for (double coO = 0.1; coO < 0.2; coO += 0.1) {
                for (double sMax = 0.51; sMax < 0.6; sMax += 0.01) {
                    Rebucket.Coefficient coefficient = new Rebucket.Coefficient(sMax, coC, coO);
                    System.out.println(coefficient);
                    putCoefficient(coefficient);
                }
            }
        }

        for (int i = 0; i < THREAD_NUMBER; i++) {
            Rebucket.Coefficient coefficient = new Rebucket.Coefficient();
            coefficient.setSMax(-1.0);
            putCoefficient(coefficient);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        try {
            ResultSummary resultSummary = new RebucketResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        new RebucketMaster().tuning();
        Instant end = Instant.now();
    }
}
