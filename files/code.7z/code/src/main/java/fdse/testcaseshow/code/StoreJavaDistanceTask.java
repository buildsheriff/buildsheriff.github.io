package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFileDistance;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreJavaDistanceTask implements Runnable {
    private BlockingQueue<JavaFileDistance> outQueue;

    public StoreJavaDistanceTask(BlockingQueue<JavaFileDistance> outQueue) {
        this.outQueue = outQueue;
    }

    private JavaFileDistance getJavaFileDistance() {
        JavaFileDistance javaFileDistance = null;
        try {
            javaFileDistance = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return javaFileDistance;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        JavaFileDistance javaFileDistance = null;
        Object o = session.createQuery("select max(j.id) from JavaFileDistance j").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            javaFileDistance = getJavaFileDistance();
            if (javaFileDistance.getId() < 0)
                break;
            id++;
            javaFileDistance.setId(id);
            session.save(javaFileDistance);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
