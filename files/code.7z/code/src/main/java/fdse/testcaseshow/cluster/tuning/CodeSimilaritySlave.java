package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.codesim.*;
import fdse.testcaseshow.cluster.evaluation.CodeSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.feature.TokenType;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

public class CodeSimilaritySlave implements Runnable {
    private List<TestCase> testCases;
    private BlockingQueue<CodeSimilarity.Coefficient> inQueue;
    private BlockingQueue<ResultSummary> outQueue;
    private ITokensDuplication iTokensDuplication;

    public CodeSimilaritySlave(List<TestCase> testCases, BlockingQueue<CodeSimilarity.Coefficient> inQueue, BlockingQueue<ResultSummary> outQueue, ITokensDuplication iTokensDuplication) {
        this.testCases = testCases;
        this.inQueue = inQueue;
        this.outQueue = outQueue;
        this.iTokensDuplication = iTokensDuplication;
    }

    public CodeSimilarity.Coefficient takeCoefficient() {
        CodeSimilarity.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            CodeSimilarity.Coefficient coefficient = takeCoefficient();
            if (coefficient.getMaxDistance() <= -1) {
                break;
            }
            ResultSummary resultSummary = new CodeSimilarityResultSummary(coefficient);
            Instant start = Instant.now();
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
                CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, iTokensDuplication);
                List<Cluster> clusters = codeSimilarity.startCluster();
                resultSummary.addSingleResult(testCase, clusters, false);
            }
            Instant end = Instant.now();
            putResult(resultSummary);
        }
    }
}
