package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import lombok.Getter;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class STSimilarityWithoutDistanceCollect implements Runnable {
    private BlockingQueue<ResultSummary> outQueue;
    @Getter
    private List<ResultSummary> resultSummaryList = new ArrayList<>();

    public STSimilarityWithoutDistanceCollect(BlockingQueue<ResultSummary> outQueue) {
        this.outQueue = outQueue;
    }

    public ResultSummary getResult() {
        ResultSummary resultSummary = null;
        try {
            resultSummary = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return resultSummary;
    }
    @Override
    public void run() {
        try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.STSIMILARITYWITHOUTDISTANCE, true, null)) {
            while (true) {
                STSimilarityResultSummary resultSummary = (STSimilarityResultSummary) getResult();
                if (resultSummary.getCoefficient() == null)
                    break;
                storeResultSummary.write(resultSummary);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
