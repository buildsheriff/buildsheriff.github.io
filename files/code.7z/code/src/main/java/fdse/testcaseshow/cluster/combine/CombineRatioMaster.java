package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.evaluation.CombineRatioResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class CombineRatioMaster {
    private BlockingQueue<CombineMethod.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);
    private List<Thread> slaveThreads = new ArrayList<>();
    private Thread collectThread = null;

    private static final int THREAD_NUMBER = 20;

    private List<CombineMethod.Coefficient> coefficientList;
    private String outFileName;
    private CombineMark combineMark;
    public CombineRatioMaster(List<CombineMethod.Coefficient> coefficientList, String outFileName, CombineMark combineMark) {
        this.coefficientList = coefficientList;
        this.outFileName = outFileName;
        this.combineMark = combineMark;
    }

    private void initializeThreads(List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new CombineRatioSlave(testCases, this.inQueue, this.outQueue, this.combineMark));
            slaveThreads.add(tmpThread);
            tmpThread.start();
        }
        CombineRatioCollect combineRatioCollect = new CombineRatioCollect(this.outQueue, this.outFileName);
        this.collectThread = new Thread(combineRatioCollect);
        this.collectThread.start();
    }

    private void finishThreads() {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            CombineMethod.Coefficient coefficient = new CombineMethod.Coefficient(null, null, -1.0, -1.0);
            putCoefficient(coefficient);
        }
        this.slaveThreads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        try {
            ResultSummary resultSummary = new CombineRatioResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            this.collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void putCoefficient(CombineMethod.Coefficient coefficient) {
        try {
            inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public List<TestCase> loadExceptionResourcesFromMysql() {
        List<TestCase> testCases;
        try(Session session = SessionUtil.getSession()) {
            testCases = MysqlUtil.getCrashTestCases(session);
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    testItem.getTestFrames().size();
                }
            }
        }
        return testCases;
    }

    public List<TestCase> loadAssertionResourcesFromMysql() {
        List<TestCase> testCases;
        try(Session session = SessionUtil.getSession()) {
            testCases = MysqlUtil.getAssertionTestCases(session);
            for (TestCase testCase : testCases) {
                testCase.getJavaFileTokens().size();
                testCase.getChangedFiles().size();
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    testItem.getTestCodeStatements().size();;
                }
            }
        }
        return testCases;
    }

    public void tuning() {
        List<TestCase> testCases = null;
        if (combineMark == CombineMark.STSimilarity_Exception) {
            testCases = loadExceptionResourcesFromMysql();
        } else if (combineMark == CombineMark.CodeSimilarity_Assertion) {
            testCases = loadAssertionResourcesFromMysql();
        }
        initializeThreads(testCases);
        this.coefficientList.forEach(coefficient -> {
            System.out.println(coefficient);
            putCoefficient(coefficient);
        });
        finishThreads();
    }

    public static void combineSTAndEx() {
        List<CombineMethod.Coefficient> coefficients = new ArrayList<>();
        String outFileName = "STExRatio";
        for (double sMax = 0.51; sMax < 1.0001; sMax += 0.01) {
            for (double c = 0.1; c < 2.00001; c += 0.1) {
                for (double ratio = 0; ratio < 1.0001; ratio += 0.1) {
                    STSimilarity.Coefficient stCoefficient = new STSimilarity.Coefficient(sMax, c, 6);
                    CombineMethod.Coefficient coefficient = new CombineMethod.Coefficient(stCoefficient, null, ratio, sMax);
                    coefficients.add(coefficient);
                }
            }
        }
        new CombineRatioMaster(coefficients, outFileName, CombineMark.STSimilarity_Exception).tuning();
    }

    public static void combineCodeSimAndAssertion() {
        List<CombineMethod.Coefficient> coefficients = new ArrayList<>();
        String outFileName = "CodeAssertionRatio";
        for (double threshold = 0.51; threshold < 1.0001; threshold += 0.01) {
            for (double cComplete = 0.1; cComplete < 2.0001; cComplete += 0.1) {
                for (double ratio = 0; ratio < 1.00001; ratio += 0.1) {
                    CodeSimilarity.Coefficient csCoefficient = new CodeSimilarity.Coefficient(0.0, cComplete, 6, 0.0, threshold);
                    CombineMethod.Coefficient coefficient = new CombineMethod.Coefficient(csCoefficient, null, ratio, threshold);
                    coefficients.add(coefficient);
                }
            }
        }
        new CombineRatioMaster(coefficients, outFileName, CombineMark.CodeSimilarity_Assertion).tuning();
    }

    public static enum CombineMark {
        STSimilarity_Exception, CodeSimilarity_Assertion
    }

    public static void main(String[] args) {
        combineCodeSimAndAssertion();
    }
}
