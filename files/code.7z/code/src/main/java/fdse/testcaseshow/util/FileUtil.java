package fdse.testcaseshow.util;

import fdse.testcaseshow.code.JavaVisitor;
import fdse.testcaseshow.code.JdtTreeGenerator;
import fdse.testcaseshow.code.gumtree.Action;
import fdse.testcaseshow.code.gumtree.ActionGenerator;
import fdse.testcaseshow.code.gumtree.GreedyBottomUpMatcher;
import fdse.testcaseshow.code.gumtree.GreedySubtreeMatcher;
import fdse.testcaseshow.code.gumtree.ITree;
import fdse.testcaseshow.code.gumtree.MappingStore;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.javatuples.Pair;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class FileUtil {
    public static final Path codeDirectoryPath = Paths.get(System.getProperty("user.dir"), "resources", "code");
    public static Pattern staticPattern = Pattern.compile("(([a-zA-Z_$][a-zA-Z\\d_$]*\\.)*)[a-zA-Z_$][a-zA-Z\\d_$]*", Pattern.DOTALL);

    public static char[] getFileCharArray(Path path) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.ISO_8859_1);
        StringBuilder sb = new StringBuilder();
        for(String s:lines){
            sb.append(s + "\n");
        }
        char[] ca = sb.toString().toCharArray();
        return ca;
    }

    public static char[] getFileCharArray(String path) throws IOException {
        return getFileCharArray(Paths.get(path));
    }

    private static CompilationUnit getCompilationUnit(char[] charArray) {
        ASTParser parser = ASTParser.newParser(AST.JLS10);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        Map<String, String> options = JavaCore.getOptions();
        options.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_10);
        options.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_10);
        options.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_6);
        options.put(JavaCore.COMPILER_DOC_COMMENT_SUPPORT, JavaCore.ENABLED);
        parser.setCompilerOptions(options);
        parser.setSource(charArray);
        CompilationUnit astRoot = (CompilationUnit)parser.createAST(null);
        return astRoot;
    }

    public static CompilationUnit getCompilationUnit(String path) {

        return getCompilationUnit(Paths.get(path));
    }
    public static CompilationUnit getCompilationUnit(Path path) {
        try {
            return getCompilationUnit(getFileCharArray(path));
        } catch (IOException e) {
            System.out.println("解析文件出现问题" + path);
            e.printStackTrace();
        }
        return null;
    }

    public static String getRepoPath(String sha) {
        List<String> paths = null;
        try {
            paths = Files.list(codeDirectoryPath).filter(f -> Files.isDirectory(f)).map(f -> f.toString()).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        String repoPath = null;
        for (String path:paths) {
            if (path.contains("-" + sha))
                repoPath = path;
        }
        return repoPath;
    }
    public static List<String> getJavaFiles(String repoPath) {
        List<String> list = null;
        try {
            list = Files.walk(Paths.get(repoPath)).map(f -> f.toString()).filter(f -> f.endsWith(".java")).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        // list.forEach(System.out::println);
        return list;
    }

    public static String getFileRelativePath(String filePath) {
        Path pathAbsolute = Paths.get(filePath);
        Path pathRelative = codeDirectoryPath.relativize(pathAbsolute);
        return pathRelative.toString();
    }

    public static String getFileAbsolutePath(String fileRelativePath) {
        return codeDirectoryPath.resolve(fileRelativePath).toString();
    }

    public static String getCompleteFileName(String filePath, String repoPath) {
        Path pathAbsolute = Paths.get(filePath);
        Path pathRelative = Paths.get(repoPath).relativize(pathAbsolute);
        return pathRelative.toString();
    }

    public static String getFileName(String filePath) {
        return Paths.get(filePath).getFileName().toString();
    }

    public static String extractClassNameFromStaticImport(String name) {
        String result = null;
        Matcher matcher = staticPattern.matcher(name);
        if (matcher.matches())
            result = matcher.group(1);
        result = result.substring(0, result.length() - 1);
        return result;
    }

    public static void main(String[] args) {
        String s = "lombok.dagea.dada.AccessLevel";
        FileUtil.extractClassNameFromStaticImport(s);
    }

    public static JavaVisitor getJavaFileInfo(String path) {
        CompilationUnit cu = getCompilationUnit(path);
        JavaVisitor visitor = new JavaVisitor(cu);
        if(cu == null)
            return null;
        cu.accept(visitor);
        return visitor;
    }

    public static int getStartLineNumber(JavaVisitor javaVisitor, ASTNode node) {
        CompilationUnit cu = javaVisitor.getCompilationUnit();
        return cu.getLineNumber(node.getStartPosition());
    }

    public static int getEndLineNumber(JavaVisitor javaVisitor, ASTNode node) {
        CompilationUnit cu = javaVisitor.getCompilationUnit();
        return cu.getLineNumber(node.getStartPosition() + node.getLength() - 1);
    }

    public static int max(List<Integer> list) {
        if (list.size() == 0)
            return Integer.MIN_VALUE;
        int max = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i) > max)
                max = list.get(i);
        }
        return max;
    }

    public static int min(List<Integer> list) {
        if (list.size() == 0)
            return Integer.MAX_VALUE;
        int min = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i) < min)
                min = list.get(i);
        }
        return min;
    }

    public static double averge(List<Integer> list) {
        if (list.size() == 0)
            return 0;
        double sum = 0.0;
        for (int i : list) {
            sum += i;
        }
        return sum / list.size();
    }

    public static double median(List<Integer> list) {
        if (list.size() == 0)
            return 0;
        double j = 0;
        Collections.sort(list);
        int size = list.size();
        if(size % 2 == 1){
            j = list.get((size-1)/2);
        }else {
            j = (list.get(size/2-1) + list.get(size/2) + 0.0)/2;
        }
        return j;
    }
    public static Pair<Integer, Integer> mode(List<Integer> list) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int i : list) {
            map.put(i, map.getOrDefault(i, 0) + 1);
        }
        int maxValue = 0;
        int maxCount = 0;
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            int v = entry.getKey();
            int c = entry.getValue();
            if (c > maxCount) {
                maxValue = v;
                maxCount = c;
            }
        }

        return Pair.with(maxValue, maxCount);
    }

    public static boolean includeFrame(String s) {
        boolean flag = true;

        return flag;
    }

    public static String getTreeContextFromFile(String path) {
        List<String> lines = null;
        try {
            lines = Files.readAllLines(Paths.get(path));
        } catch (IOException e) {
            e.printStackTrace();
        }
        StringBuilder sb = new StringBuilder();
        for(String s:lines){
            sb.append(s + "\n");
        }
        return sb.toString();
    }

    public static ITree getRoot(String s) {
        return new JdtTreeGenerator().getTreeContext(s).getRoot();
    }

    public static List<Action> getActions(ITree src, ITree dst) {
        MappingStore mappingStore = new MappingStore();
        new GreedySubtreeMatcher(src, dst, mappingStore).match();
        new GreedyBottomUpMatcher(src, dst, mappingStore).match();
        ActionGenerator g = new ActionGenerator(src, dst, mappingStore);
        g.generate();
        return g.getActions();
    }

    public static <T> Collection<T> union(Collection<T> list1, Collection<T> list2) {
        Collection<T> list = new ArrayList<>();

        list.addAll(list1);
        list.addAll(list2);

        return list;
    }

    public static <T> Collection<T> intersection(Collection<T> collection1, Collection<T> collectionn2) {
        Collection<T> collection = new ArrayList<T>();

        for (T t : collection1) {
            if(collectionn2.contains(t)) {
                collection.add(t);
            }
        }

        return collection;
    }
}
