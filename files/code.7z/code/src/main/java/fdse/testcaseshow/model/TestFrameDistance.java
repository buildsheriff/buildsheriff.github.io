package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "test_frame_distances")
public class TestFrameDistance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "distance")
    private Integer distance;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_frame_id")
    private TestFrame testFrame;
}

