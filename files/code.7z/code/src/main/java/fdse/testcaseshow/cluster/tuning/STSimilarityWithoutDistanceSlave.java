package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.STSimilarityWithoutDistance;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class STSimilarityWithoutDistanceSlave implements Runnable {
    private BlockingQueue<STSimilarityWithoutDistance.Coefficient> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<ResultSummary> outQueue;
    public STSimilarityWithoutDistanceSlave(List<TestCase> testCases, BlockingQueue<STSimilarityWithoutDistance.Coefficient> inQueue, BlockingQueue<ResultSummary> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
        this.testCases = testCases;
    }

    public STSimilarityWithoutDistance.Coefficient getCoefficient() {
        STSimilarityWithoutDistance.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            STSimilarityWithoutDistance.Coefficient coefficient = getCoefficient();
            if (coefficient.getMethodMatchDistance() <= -1) {
                break;
            }
            ResultSummary resultSummary = new STSimilarityResultSummary(new STSimilarity.Coefficient(coefficient.getSMax(), coefficient.getC(), 0));
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<Cluster> clusters = STSimilarityWithoutDistance.clusterBuild(selectedTestItems, coefficient.getSMax(),
                        coefficient.getC(), coefficient.getMethodMatchDistance(), coefficient.getFileMatchDistance(), coefficient.getNoMatchDistance());
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            putResult(resultSummary);
        }

    }
}
