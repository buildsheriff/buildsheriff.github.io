package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "java_file_tokens")
public class JavaFileToken {
    @Id
    private long id;

    @Column(name = "name")
    private String name;

    @Column(name = "type")
    private int type;

    @Column(name = "distance")
    private int distance;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="java_file_id")
    private JavaFile javaFile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;
}

