package fdse.testcaseshow.code;

import fdse.testcaseshow.model.TestCase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PathProcess {

    public static String pathProcessing(String filepath){


        String regrex = "figs/[A-Za-z0-9_\\-.]+png";
        Pattern pattern = Pattern.compile(regrex);
        Matcher matcher = pattern.matcher(filepath);
        if (matcher.find()) {
            filepath = matcher.group();
            filepath = filepath.replace("figs/", "");
            System.out.println("filepath为"+filepath);
            return filepath;

        }
        return null;
    }

}
