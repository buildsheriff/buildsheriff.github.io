package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.ExceptionSimilarity;
import lombok.Getter;

public class ExceptionSimilarityResultSummary extends ResultSummary {
    @Getter
    private ExceptionSimilarity.Coefficient coefficient;

    public ExceptionSimilarityResultSummary(ExceptionSimilarity.Coefficient coefficient) {
        this.coefficient = coefficient;
    }
    @Override
    public String toString() {
        String s = String.format("ExceptionSimilarity parameters\nsMax: %.2f\n",
                coefficient.getSMax());
        s += super.toString();
        return s;
    }
}
