package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.cluster.evaluation.CombineRatioResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import lombok.Getter;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class CombineRatioCollect implements Runnable {
    private BlockingQueue<ResultSummary> outQueue;
    private String outFileName;

    public CombineRatioCollect(BlockingQueue<ResultSummary> outQueue, String outFileName) {

        this.outQueue = outQueue;
        this.outFileName = outFileName;
    }

    public ResultSummary getResult() {
        ResultSummary resultSummary = null;
        try {
            resultSummary = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return resultSummary;
    }
    @Override
    public void run() {
        try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.MERGERATIO, true, this.outFileName)) {
            while (true) {
                CombineRatioResultSummary resultSummary = (CombineRatioResultSummary) getResult();
                if (resultSummary.getCoefficient() == null)
                    break;

                storeResultSummary.write(resultSummary);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
