package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.FileUtil;

import java.util.*;

public class CodeSimilarityWithoutDistance extends CodeSimilarity {
    private ITokensDuplication tokensDuplication;
    public CodeSimilarityWithoutDistance(List<TestItem> testItems, Collection<JavaFileToken> javaFileTokens, Coefficient coefficient, ITokensDuplication tokensDuplication) {
        super(testItems, javaFileTokens, coefficient);
        this.tokensDuplication = tokensDuplication;
    }

    public double getSimByToken(Collection<String> tokensA, Collection<String> tokensB) {
        tokensA = tokensDuplication.processTokens(tokensA);
        tokensB = tokensDuplication.processTokens(tokensB);
        Set<String> set = new HashSet<>(FileUtil.intersection(tokensA, tokensB));
        List<String> interSection = new ArrayList<>();
        for (String token : tokensA) {
            if (set.contains(token))
                interSection.add(token);
        }
        for (String token : tokensB) {
            if (set.contains(token))
                interSection.add(token);
        }

        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(this.testCaseId);
        double divisor = 0.0;
        divisor += CodeSimUtil.getTokensWeightWithoutDistance(tokensA, distanceMap, coefficient.getCComplete());
        divisor += CodeSimUtil.getTokensWeightWithoutDistance(tokensB, distanceMap, coefficient.getCComplete());
        double dividend = CodeSimUtil.getTokensWeightWithoutDistance(interSection, distanceMap, coefficient.getCComplete());;

        double sim = dividend / divisor;
        return sim;
    }

    public double getSimByToken(TestItem tiA, TestItem tiB) {
        Collection<String> tokensA = CodeSimilarity.getTokens(tiA, CodeSimilarity.getDistanceMap(this.testCaseId));
        Collection<String> tokensB = CodeSimilarity.getTokens(tiB, CodeSimilarity.getDistanceMap(this.testCaseId));
        double sim = getSimByToken(tokensA, tokensB);
        return sim;
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {
        return getSimByToken(tiA, tiB);
    }
}

