package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.FileUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.*;

public class EvaluationOld {
    private TestCase testCase;
    private List<Cluster> groundTruthClusters;
    private List<Cluster> evaluatedClusters;
    @Getter
    private double purity = 0.0;
    @Getter
    private double inversePurity = 0.0;
    @Getter
    private double fMeasure = 0.0;
    private int N;
    public EvaluationOld(TestCase testCase, List<Cluster> groundTruthClusters, List<Cluster> evaluatedClusters, int N) {
        this.testCase = testCase;
        this.groundTruthClusters = groundTruthClusters;
        this.evaluatedClusters = evaluatedClusters;
        this.N = N;
    }
    //
    public static List<Cluster> getGroundTruthClusterList(List<TestItem> testItems) {
        List<List<TestItem>> testItemListList = new ArrayList<>();
        Map<Integer, List<TestItem>> map = new HashMap<>();
        for (TestItem testItem : testItems) {
            int clusterType = testItem.getClusterType();
            if (map.get(clusterType) == null) {
                map.put(clusterType, new ArrayList<>());
            }
            map.get(clusterType).add(testItem);
        }
        testItemListList.addAll(map.values());
        return convertTestItemListListToClusterList(testItemListList);
    }

    public static List<Cluster> convertTestItemListListToClusterList(List<List<TestItem>> testItemListList) {
        //System.out.println(testItemListList.size());
        List<List<DataPoint>> dataPointsList = new ArrayList<>();
        for (List<TestItem> testItems : testItemListList) {
            List<DataPoint> dataPoints = new ArrayList<>();
            for (TestItem testItem : testItems) {
                dataPoints.add(new DataPoint(testItem.getId(), testItem));
            }
            dataPointsList.add(dataPoints);
        }
        //System.out.println(dataPointsList.size());

        List<Cluster> originalClusters = new ArrayList<>();
        for (int i = 0; i < dataPointsList.size(); i++) {
            List<DataPoint> tempDataPoints = dataPointsList.get(i);
            Cluster tempCluster = new Cluster();
            tempCluster.setClusterName("Cluster " + String.valueOf(i));
            tempCluster.setClusterID(i);
            tempCluster.setDataPoints(tempDataPoints);
            for (DataPoint tempDataPoint : tempDataPoints) {
                tempDataPoint.setCluster(tempCluster);
            }
            originalClusters.add(tempCluster);
        }
        // System.out.println(originalClusters.size());
        return originalClusters;
    }

    public void run() {
        if (testCase.getCrashClusterNum() == 1 && evaluatedClusters.size() == 1) {
            this.purity = 1.0;
            this.inversePurity = 1.0;
            this.fMeasure = 1.0;
            return;
        }
        /*
        for (Cluster cluster : clusters) {
            System.out.println(cluster);
        }
        */
        List<ClusterIntersection> clusterIntersectionList = new ArrayList<>();
        for (Cluster groundTruthCluster : groundTruthClusters) {
            for (Cluster evaluatedCluster : evaluatedClusters) {
                List<Long> intersection = (List<Long>) FileUtil.intersection(groundTruthCluster.getIds(), evaluatedCluster.getIds());
                double fmeasure = 2.0 * intersection.size() / (groundTruthCluster.getSize() + evaluatedCluster.getSize());
                ClusterIntersection clusterIntersection = new ClusterIntersection(groundTruthCluster.getClusterID(), evaluatedCluster.getClusterID(), intersection.size(), fmeasure);
                clusterIntersectionList.add(clusterIntersection);
            }
        }

        int totalMax = 0;
        for (Cluster evaluatedCluster : evaluatedClusters) {
            int evaluatedClusterID = evaluatedCluster.getClusterID();
            int maxSize = ClusterIntersection.getMaxIntersectionSizeByEvaluatedClusterID(clusterIntersectionList, evaluatedClusterID);
            totalMax += maxSize;
        }
        this.purity = 1.0 * totalMax / N;

        totalMax = 0;
        for (Cluster groundTruthCluster : groundTruthClusters) {
            int groundTruthClusterID = groundTruthCluster.getClusterID();
            int maxSize = ClusterIntersection.getMaxIntersectionSizeByGroundTruthClusterID(clusterIntersectionList, groundTruthClusterID);
            totalMax += maxSize;
        }
        this.inversePurity = 1.0 * totalMax / N;

        /*
         */
        double fm = 0.0;
        for (Cluster groundTruthCluster : groundTruthClusters) {
            int groundTruthClusterID = groundTruthCluster.getClusterID();
            double maxFMeasure = ClusterIntersection.getMaxFMeasureByGroundTruthClusterID(clusterIntersectionList, groundTruthClusterID);
            fm += groundTruthCluster.getSize() * maxFMeasure;
        }
        this.fMeasure = fm / N;
    }

    public boolean correctness(DataPoint dataPointA, DataPoint dataPointB) {

        return false;
    }
    public void bcubed() {

    }
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ClusterIntersection {
        @Getter
        private int groundTruthClusterID;
        @Getter
        private int evaluatedClusterID;
        @Getter
        private int size = 0;
        // private double precision = 0.0;
        // private double recall = 0.0;
        @Getter
        private double fmeasure = 0.0;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ClusterIntersection that = (ClusterIntersection) o;
            return groundTruthClusterID == that.groundTruthClusterID &&
                    evaluatedClusterID == that.evaluatedClusterID;
        }

        @Override
        public int hashCode() {
            return Objects.hash(groundTruthClusterID, evaluatedClusterID);
        }

        public static int getMaxIntersectionSizeByGroundTruthClusterID(List<ClusterIntersection> clusterIntersectionList, int groundTruthClusterID) {
            int maxSize = 0;
            for (ClusterIntersection clusterIntersection : clusterIntersectionList) {
                if (clusterIntersection.getGroundTruthClusterID() == groundTruthClusterID) {
                    if (clusterIntersection.getSize() > maxSize) {
                        maxSize = clusterIntersection.getSize();
                    }
                }
            }
            return maxSize;
        }

        public static int getMaxIntersectionSizeByEvaluatedClusterID(List<ClusterIntersection> clusterIntersectionList, int evaluatedClusterID) {
            int maxSize = 0;
            for (ClusterIntersection clusterIntersection : clusterIntersectionList) {
                if (clusterIntersection.getEvaluatedClusterID() == evaluatedClusterID) {
                    if (clusterIntersection.getSize() > maxSize) {
                        maxSize = clusterIntersection.getSize();
                    }
                }
            }
            return maxSize;
        }

        public static double getMaxFMeasureByGroundTruthClusterID(List<ClusterIntersection> clusterIntersectionList, int groundTruthClusterID) {
            double fmeasure = 0.0;
            for (ClusterIntersection clusterIntersection : clusterIntersectionList) {
                if (clusterIntersection.getGroundTruthClusterID() == groundTruthClusterID) {
                    if (clusterIntersection.getFmeasure() > fmeasure) {
                        fmeasure = clusterIntersection.getFmeasure();
                    }
                }
            }
            return fmeasure;
        }
    }
}