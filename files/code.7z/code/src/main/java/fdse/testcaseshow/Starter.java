package fdse.testcaseshow;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Starter {
    public static void main(String[] args) throws IOException {
        new Starter();
        Map<Integer, Long> map = new HashMap<>();
        map = null;
        map.put(10, 5L);
        map = null;
        Class c = Integer.class;
        int a = 147573;
        char f = 'd';
        boolean flag = true;
        if (true) {

        } else if (false){

        }

        try {

        } catch (NullPointerException e) {

        }

        try {

        } finally {

        }

    }
}
