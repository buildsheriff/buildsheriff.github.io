package fdse.testcaseshow.code;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCode;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreCodeTask implements Runnable {
    private BlockingQueue<TestCode> outQueue;

    public StoreCodeTask(BlockingQueue<TestCode> outQueue) {
        this.outQueue = outQueue;
    }

    private TestCode getTestCode() {
        TestCode testCode = null;
        try {
            testCode = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testCode;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        TestCode testCode = null;
        Object o = session.createQuery("select max(t.id) from TestCode t").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            testCode = getTestCode();
            if (testCode.getId() < 0)
                break;
            id++;
            testCode.setId(id);
            session.save(testCode);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
