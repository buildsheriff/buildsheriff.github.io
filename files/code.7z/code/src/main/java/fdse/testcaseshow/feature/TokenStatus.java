package fdse.testcaseshow.feature;

public enum TokenStatus {
    ADDED(0), DELETED(1), MODIFIED(2), EMPTY(3);
    private int value;
    private TokenStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
