package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.feature.TokenType;
import fdse.testcaseshow.model.JavaFileToken;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public interface IStatementWeight {
    default Map<String, TokenType> getTokenTypeMap(Collection<String> tokens, Map<String, TokenType> changedNames) {
        Map<String, TokenType> map = new HashMap<>();
        for (String token : tokens) {
            TokenType type = changedNames.get(token);
            if (type == null) {
                map.put(token, null);
            } else if (type == TokenType.CLASS_NAME) {
                map.put(token, TokenType.CLASS_NAME);
            } else if (type == TokenType.METHOD_NAME) {
                map.put(token, TokenType.METHOD_NAME);
            } else if (type == TokenType.RESOURCE_NAME) {
                map.put(token, TokenType.RESOURCE_NAME);
            }
        }
        return map;
    }

    void setStatementInfoWeight(CodeSimilarityByStatement.StatementInfo statementInfo, Map<String, Integer> distanceMap, CodeSimilarity.Coefficient coefficient);
}
