package fdse.testcaseshow.code;

import fdse.testcaseshow.feature.TokenType;
import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.model.JavaFileDistance;
import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.util.FileUtil;
import org.eclipse.jdt.core.dom.CompilationUnit;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ExtractJavaTokenTask implements Runnable {

    private BlockingQueue<JavaFile> inQueue;
    private BlockingQueue<JavaFileToken> outQueue;
    public ExtractJavaTokenTask(BlockingQueue<JavaFile> inQueue, BlockingQueue<JavaFileToken> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }
    private JavaFile takeJavaFile() {
        JavaFile javaFile = null;
        try {
            javaFile = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return javaFile;
    }

    private void putJavaFileToken(JavaFileToken javaFileToken) {
        try {
            outQueue.put(javaFileToken);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public JavaFileToken getToken(JavaFile javaFile, String name, TokenType type, int distance) {
        JavaFileToken javaFileToken = new JavaFileToken();
        javaFileToken.setTestCase(javaFile.getTestCase());
        javaFileToken.setJavaFile(javaFile);
        javaFileToken.setName(name);
        javaFileToken.setType(type.getValue());
        javaFileToken.setDistance(distance);
        return javaFileToken;
    }

    public int getMinDistance(JavaFile javaFile) {
        if (javaFile.getChanged() != null && javaFile.getChanged() == true)
            return 1;
        int distance = Integer.MAX_VALUE;
        for (JavaFileDistance javaFileDistance : javaFile.getDistances()) {
            if (javaFileDistance.getDistance() < distance)
                distance = javaFileDistance.getDistance();
        }
        return distance;
    }

    public List<JavaFileToken> getTokens(JavaFile javaFile) {
        List<JavaFileToken> javaFileTokens = new ArrayList<>();
        Path path = ExtractJavaToken.getAbsoluteFilePath(javaFile.getFilePath());
        CompilationUnit cu = FileUtil.getCompilationUnit(path);
        TokenVisitor visitor = new TokenVisitor();
        cu.accept(visitor);

        final int fdistance = getMinDistance(javaFile);
        Set<String> classNames = visitor.getClassNames();
        Set<String> methodNames = visitor.getMethodNames();
        Set<String> fieldNames = visitor.getFieldNames();
        classNames.forEach(name -> javaFileTokens.add(getToken(javaFile, name, TokenType.CLASS_NAME, fdistance)));
        methodNames.forEach(name -> javaFileTokens.add(getToken(javaFile, name, TokenType.METHOD_NAME, fdistance)));
        fieldNames.forEach(name -> javaFileTokens.add(getToken(javaFile, name, TokenType.FIELD_NAME, fdistance)));
        return javaFileTokens;
    }

    @Override
    public void run() {
        while (true) {
            JavaFile javaFile = takeJavaFile();
            if (javaFile.getId() == -1L)
                break;
            List<JavaFileToken> javaFileTokens = getTokens(javaFile);
            javaFileTokens.forEach(javaFileToken -> putJavaFileToken(javaFileToken));
        }
    }
}
