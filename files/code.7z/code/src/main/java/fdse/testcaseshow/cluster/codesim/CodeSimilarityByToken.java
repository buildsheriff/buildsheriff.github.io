package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.FileUtil;

import java.util.*;

public class CodeSimilarityByToken extends CodeSimilarity {
    public static int maxdis = 0;
    private ITokensDuplication tokensDuplication;
    public CodeSimilarityByToken(List<TestItem> testItems, Collection<JavaFileToken> javaFileTokens, Coefficient coefficient, ITokensDuplication tokensDuplication) {
        super(testItems, javaFileTokens, coefficient);
        this.tokensDuplication = tokensDuplication;
    }

    public int minv(Map<String, Integer> distanceMap) {
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            if (entry.getValue() == 16)
                continue;
            if (entry.getValue() > maxdis)
                maxdis = entry.getValue();
            System.out.println("key = " + entry.getKey() + ", value = " + entry.getValue());
        }
        return maxdis;
    }

    public double getSimByToken(Collection<String> tokensA, Collection<String> tokensB) {
        tokensA = tokensDuplication.processTokens(tokensA);
        tokensB = tokensDuplication.processTokens(tokensB);
        Set<String> set = new HashSet<>(FileUtil.intersection(tokensA, tokensB));
        List<String> interSection = new ArrayList<>();
        for (String token : tokensA) {
            if (set.contains(token))
                interSection.add(token);
        }
        for (String token : tokensB) {
            if (set.contains(token))
                interSection.add(token);
        }

        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(this.testCaseId);
        System.out.println(minv(distanceMap));
        double divisor = 0.0;
        divisor += CodeSimUtil.getTokensWeight(tokensA, distanceMap, coefficient.getCComplete());
        divisor += CodeSimUtil.getTokensWeight(tokensB, distanceMap, coefficient.getCComplete());
        double dividend = CodeSimUtil.getTokensWeight(interSection, distanceMap, coefficient.getCComplete());;

        double sim = dividend / divisor;
        return sim;
    }

    public double getSimByToken(TestItem tiA, TestItem tiB) {
        Collection<String> tokensA = CodeSimilarity.getTokens(tiA, CodeSimilarity.getDistanceMap(this.testCaseId));
        Collection<String> tokensB = CodeSimilarity.getTokens(tiB, CodeSimilarity.getDistanceMap(this.testCaseId));
        double sim = getSimByToken(tokensA, tokensB);
        return sim;
    }

    @Override
    public double getSim(TestItem tiA, TestItem tiB) {
        return getSimByToken(tiA, tiB);
    }
}
