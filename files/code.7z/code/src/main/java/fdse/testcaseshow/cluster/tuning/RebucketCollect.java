package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.evaluation.RebucketResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;

import java.io.FileNotFoundException;
import java.util.concurrent.BlockingQueue;

public class RebucketCollect implements Runnable {
    private BlockingQueue<ResultSummary> outQueue;

    public RebucketCollect(BlockingQueue<ResultSummary> outQueue) {
        this.outQueue = outQueue;
    }

    public ResultSummary getResult() {
        ResultSummary resultSummary = null;
        try {
            resultSummary = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return resultSummary;
    }
    @Override
    public void run() {
        try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.REBUCKET, true, "Assertion")) {
            while (true) {
                RebucketResultSummary resultSummary = (RebucketResultSummary) getResult();
                if (resultSummary.getCoefficient() == null)
                    break;
                storeResultSummary.write(resultSummary);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
