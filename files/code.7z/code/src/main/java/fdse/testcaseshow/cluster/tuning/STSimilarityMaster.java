package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import lombok.Getter;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class STSimilarityMaster {
    private BlockingQueue<STSimilarity.Coefficient> inQueue = new ArrayBlockingQueue<>(50);;
    private BlockingQueue<ResultSummary> outQueue = new ArrayBlockingQueue<>(20);
    @Getter
    private List<ResultSummary> resultSummaryList = new ArrayList<>();
    private static final int THREAD_NUMBER = 1;
    private void initializeThreads(List<Thread> threads, Thread thread, List<TestCase> testCases) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new STSimilaritySlave(testCases, inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    private void putCoefficient(STSimilarity.Coefficient coefficient) {
        try {
            inQueue.put(coefficient);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void tuning() {
        List<Long> ids = new ArrayList<>();
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false ", TestCase.class);
            for (TestCase testCase : query.list()) {
                ids.add(testCase.getId());
            }
        }
        tuning(ids);
    }
    public void tuning(List<Long> ids) {
        List<TestCase> testCases = null;
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id in :ids", TestCase.class);
            query.setParameterList("ids", ids);
            testCases = query.list();
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    testItem.getTestFrames().size();
                }
            }
        }
        STSimilarityCollect stSimilarityCollect = new STSimilarityCollect(outQueue);
        Thread collectThread = new Thread(stSimilarityCollect);
        List<Thread> threads = new ArrayList<>();
        initializeThreads(threads, collectThread, testCases);
        Date date1 = new Date();

        for (double sMax = 0.51; sMax < 0.52; sMax += 0.01) {
            for (double c = 0.1; c < 0.3; c += 0.1) {
                STSimilarity.Coefficient coefficient = new STSimilarity.Coefficient(sMax, c, 6);
                System.out.println(coefficient);
                putCoefficient(coefficient);
            }
        }

        for (int i = 0; i < THREAD_NUMBER; i++) {
            STSimilarity.Coefficient coefficient = new STSimilarity.Coefficient();
            coefficient.setMaxDistance(-1);
            putCoefficient(coefficient);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            ResultSummary resultSummary = new STSimilarityResultSummary(null);
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            collectThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        resultSummaryList = stSimilarityCollect.getResultSummaryList();
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        new STSimilarityMaster().tuning();
        Instant end = Instant.now();
    }
}
