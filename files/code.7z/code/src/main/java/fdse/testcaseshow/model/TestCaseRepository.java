package fdse.testcaseshow.model;


import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@CrossOrigin
public interface TestCaseRepository extends CrudRepository<TestCase, Long> {

    TestCase findByFigsLike(String filename);

}
