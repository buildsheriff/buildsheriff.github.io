package fdse.testcaseshow.code.gumtree;

public abstract class Action {
  public abstract ITree getNode();
}
