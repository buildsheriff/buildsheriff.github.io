package fdse.testcaseshow.log;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestLog;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreTestLogTask implements Runnable {
    private BlockingQueue<CutLog.CaseLogMap> outQueue;

    public StoreTestLogTask(BlockingQueue<CutLog.CaseLogMap> outQueue) {
        this.outQueue = outQueue;
    }

    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        CutLog.CaseLogMap cl = null;
        Transaction tx = session.beginTransaction();
        while (true) {
            try {
                cl = outQueue.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (cl == null)
                break;
            if (cl.getTestCase() == null)
                break;
            TestCase detachedTestCase = cl.getTestCase();
            TestCase testCase = session.get(TestCase.class, detachedTestCase.getId());
            TestLog testLog = cl.getTestLog();
            System.out.println(testCase.getId());
            testCase.setTestLog(testLog);
            testLog.setTestCase(testCase);
        }
        tx.commit();
        session.close();
    }
}
