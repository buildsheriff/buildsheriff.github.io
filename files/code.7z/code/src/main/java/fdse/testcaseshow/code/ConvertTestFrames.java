package fdse.testcaseshow.code;

import fdse.testcaseshow.log.LogUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestFrame;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ConvertTestFrames {
    private BlockingQueue<TestItem> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<TM> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 20;

    private void clear() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete TestFrame";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            int autoIncrement = session.createSQLQuery("ALTER TABLE test_frames AUTO_INCREMENT = 1").executeUpdate();

            tx.commit();
        }
    }

    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new SplitTestItemTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    private void putTestItem(TestItem testItem) {
        try {
            inQueue.put(testItem);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void storeTestFrame() {
        clear();
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreTestFrameTask(outQueue));
        initializeThreads(threads, storeThread);
        Session session = SessionUtil.getSession();
        Query<TestItem> query = session.createQuery("from TestItem where id >= 0", TestItem.class);
        List<TestItem> testItems = query.getResultList();
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getId());
            if (testItem.getStackTrace() == null)
                continue;
            testItem.getTestCase();
            putTestItem(testItem);

        }
        session.close();
        for (int i = 0; i < THREAD_NUMBER; i++) {
            TestItem sentry = new TestItem();
            sentry.setId(-1L);
            try {
                inQueue.put(sentry);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            TestFrame testFrame = new TestFrame();
            testFrame.setId(-1L);
            outQueue.put(new TM(testFrame, -1L));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            System.out.println(storeThread);
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new ConvertTestFrames().storeTestFrame();
    }
}

class SplitTestItemTask implements Runnable {
    private BlockingQueue<TestItem> inQueue;
    private BlockingQueue<TM> outQueue;

    public SplitTestItemTask(BlockingQueue<TestItem> inQueue, BlockingQueue<TM> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }
    private TestItem getTestItem() {
        TestItem testItem = null;
        try {
            testItem = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testItem;
    }

    private void putTestFrame(TM testFrame) {
        try {
            outQueue.put(testFrame);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true) {
            TestItem testItem = getTestItem();
            if (testItem.getId() < 0)
                break;

            String st = testItem.getStackTrace();
            String[] list = st.split("\n");
            for (int i = 0; i < list.length; i++) {
                TestFrame frame = new TestFrame();
                frame.setTestItem(testItem);
                frame.setOrder(i);
                frame.setFrame(list[i]);
                LogUtil.polulateTestFrame(frame);
               putTestFrame(new TM(frame, testItem.getTestCase().getId()));
            }
        }
    }
}

class StoreTestFrameTask implements Runnable {
    private BlockingQueue<TM> outQueue;

    public StoreTestFrameTask(BlockingQueue<TM> outQueue) {
        this.outQueue = outQueue;
    }

    private TM getTestFrame() {
        TM tm = null;
        try {
            tm = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return tm;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        TestFrame testFrame = null;
        Object o = session.createQuery("select max(t.id) from TestFrame t").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            TM tm = getTestFrame();
            testFrame = tm.getTestFrame();
            if (testFrame.getId() < 0)
                break;
            id++;
            testFrame.setId(id);
            TestCase testCase = session.load(TestCase.class, tm.getTestCaseId());
            testFrame.setTestCase(testCase);
            session.save(testFrame);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}

@Data
@AllArgsConstructor
class TM {
    private TestFrame testFrame;
    private long testCaseId;
}