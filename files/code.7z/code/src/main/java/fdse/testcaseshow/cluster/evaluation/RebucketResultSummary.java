package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.comparision.Rebucket;
import lombok.Getter;

public class RebucketResultSummary extends ResultSummary {
    @Getter
    private Rebucket.Coefficient coefficient;

    public RebucketResultSummary(Rebucket.Coefficient coefficient) {
        this.coefficient = coefficient;
    }
    @Override
    public String toString() {
        String s = String.format("Rebucket parameters\nsMax: %.2f coC: %.2f coO: %.2f\n",
                coefficient.getSMax(), coefficient.getCoC(), coefficient.getCoO());
        s += super.toString();
        return s;
    }
}
