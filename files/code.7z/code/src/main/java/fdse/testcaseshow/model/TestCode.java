package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access= AccessLevel.PUBLIC, force=true)
@Entity
@Table(name = "test_codes")
public class TestCode {
    @Id
    private long id;

    @Column(name = "code")
    private String code;

    @Column(name = "start_number")
    private Integer startNumber;

    @Column(name = "end_number")
    private Integer endNumber;

    @Column(name = "complete_file_name")
    private String completeFileName;

    @Column(name = "parameters")
    private String parameters;

    @OneToOne
    @JoinColumn(name="test_item_id")
    private TestItem testItem;
}
