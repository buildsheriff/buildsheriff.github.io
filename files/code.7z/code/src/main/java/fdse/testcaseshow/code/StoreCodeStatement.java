package fdse.testcaseshow.code;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCodeStatement;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreCodeStatement implements Runnable {
    private BlockingQueue<TestCodeStatement> outQueue;

    public StoreCodeStatement(BlockingQueue<TestCodeStatement> outQueue) {
        this.outQueue = outQueue;
    }

    private TestCodeStatement getTestCodeStatement() {
        TestCodeStatement testCodeStatement = null;
        try {
            testCodeStatement = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testCodeStatement;
    }
    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        TestCodeStatement testCodeStatement = null;
        Object o = session.createQuery("select max(t.id) from TestCodeStatement t").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            testCodeStatement = getTestCodeStatement();
            if (testCodeStatement.getId() < 0)
                break;
            id++;
            testCodeStatement.setId(id);
            session.save(testCodeStatement);
            i++;
            if (i % 100 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
