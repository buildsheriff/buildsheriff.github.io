package fdse.testcaseshow.cluster;


import fdse.testcaseshow.cluster.comparision.AHClusterOld;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.*;

public class MyCluster {

    public static void main(String[] args) {

        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and noStackTrace = false", TestCase.class);
            List<TestCase> testCases = query.list();
            for (double c = 2; c <= 2; c += 1) {
                for (double cMax = 0.49; cMax <= 0.6; cMax += 0.2) {
                    for (TestCase testCase : testCases) {
                        Collection<TestItem> testItems = testCase.getTestItems();
                        List<TestItem> selectedTestItems = new ArrayList<>();
                        testItems.forEach(e -> {
                            if (e.isCrash()  && e.getStackTrace() != null && e.getStackTrace().length() > 5)
                                selectedTestItems.add(e);
                        });
                        List<Cluster> clusters = AHClusterOld.clusterBuild(2.0, cMax, selectedTestItems);
                        if (testCase.getMyCluster() != null && clusters.size() != testCase.getMyCluster()) {
                            System.out.println(testCase.getId() + "->" + testCase.getCrashClusterNum());
                            System.out.println(clusters.size());
                        }
                    }
                }
            }
        }
    }

}
