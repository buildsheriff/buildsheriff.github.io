package fdse.testcaseshow.code;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.*;
import java.util.concurrent.BlockingQueue;

public class JavaFileDistancesTask implements Runnable {
    private BlockingQueue<Long> inQueue;
    private BlockingQueue<fdse.testcaseshow.model.JavaFileDistance> outQueue;

    public JavaFileDistancesTask(BlockingQueue<Long> inQueue, BlockingQueue<fdse.testcaseshow.model.JavaFileDistance> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }
    private long getTestCaseId() {
        Long testCaseId = null;
        try {
            testCaseId = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return testCaseId;
    }

    private void putJavaFileDistance(JavaFileDistance javaFileDistance) {
        try {
            outQueue.put(javaFileDistance);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        while (true) {
            long testCaseId = getTestCaseId();
            if (testCaseId < 0)
                break;
            Query<TestCase> query = session.createQuery("from TestCase where id = :id", TestCase.class).setParameter("id", testCaseId);
            TestCase testCase = query.getSingleResult();
            List<JavaFileDistances.Node> nodes = initGraph(testCase.getJavaFiles(), session);
            System.out.println(testCaseId + " -> " + testCase.getJavaFiles().size() + " -> " + nodes.size());
            List<JavaFileDistances.Node> sources = new ArrayList<>();
            nodes.forEach(node -> {
                if (node.getJavaFile().getChanged() != null && node.getJavaFile().getChanged().booleanValue() == true )
                    sources.add(node);
            });
            for (JavaFileDistances.Node root : sources) {
                breadthFirst(root);
                for (JavaFileDistances.Node node:nodes) {
                    JavaFileDistance javaFileDistance = new JavaFileDistance();
                    javaFileDistance.setDistance(node.getDistance());
                    javaFileDistance.setJavaFile(node.getJavaFile());
                    putJavaFileDistance(javaFileDistance);
                }

                nodes.forEach(node -> {
                    node.clear();
                });
            }
        }
        session.close();

    }

    public List<JavaFileDistances.Node> initGraph(Collection<JavaFile> javaFiles, Session session) {
        List<JavaFileDistances.Node> nodes = new ArrayList<>();
        javaFiles.forEach(f ->
        {
            JavaFileDistances.Node node = new JavaFileDistances.Node();
            node.setJavaFile(f);
            nodes.add(node);
        });
        for (int i=0; i<nodes.size(); i++) {
            JavaFileDistances.Node tmpNode = nodes.get(i);
            Set<Long> set = new HashSet<>();
            Query<FileToFile> query = session.createQuery("select f from FileToFile f where usingId = :id", FileToFile.class);
            query.setParameter("id", tmpNode.javaFile.getId());
            query.list().forEach(f -> {
                set.add(f.getUsedId());
            });
            query = session.createQuery("select f from FileToFile f where usedId = :id", FileToFile.class);
            query.setParameter("id", tmpNode.javaFile.getId());
            query.list().forEach(f -> {
                set.add(f.getUsingId());
            });
            nodes.forEach(n -> {
                if (set.contains(n.javaFile.getId()))
                    tmpNode.getAdjNodes().add(n);
            });
        }
        return nodes;
    }

    public void breadthFirst(JavaFileDistances.Node node) {
        node.setColor("gray");
        node.setDistance(1);
        Queue<JavaFileDistances.Node> queue = new ArrayDeque<>();
        queue.add(node);
        while (queue.isEmpty() == false) {
            JavaFileDistances.Node u = queue.remove();
            for (JavaFileDistances.Node v : u.getAdjNodes()) {
                if (v.getColor().equals("white")) {
                    v.setColor("gray");
                    v.setDistance(u.getDistance() + 1);
                    v.setPre(u);
                    queue.add(v);
                }
            }
            u.setColor("black");
        }
    }
}
