package fdse.testcaseshow.code;

import fdse.testcaseshow.feature.ChangedInfo;
import fdse.testcaseshow.feature.ChangedInfoFactory;
import fdse.testcaseshow.feature.Token;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ExtractJavaChangedToken {
    public static void run() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getTestCases(session);
        Map<String, Integer> map = new HashMap<>();
        for (TestCase testCase : testCases) {
            ChangedInfo changedInfo = ChangedInfoFactory.getInstance().getChangedInfo(testCase);
            Set<Token> tokens = changedInfo.getChangedTokens();
            for (Token token : tokens) {
                map.put(token.getName(), token.getType().getValue());
            }
        }
        session.close();
    }
}
