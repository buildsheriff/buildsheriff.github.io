package fdse.testcaseshow.cluster.evaluation;


import lombok.Getter;

import java.util.Objects;

public class MyDataPoint {
    private long testItemId;
    @Getter
    private MyCluster category;
    @Getter
    private MyCluster cluster;

    public MyDataPoint(long testItemId, MyCluster category, MyCluster cluster) {
        this.testItemId = testItemId;
        this.category = category;
        this.cluster = cluster;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MyDataPoint that = (MyDataPoint) o;
        return testItemId == that.testItemId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(testItemId);
    }

    @Override
    public String toString() {
        return "MyDataPoint{" +
                "testItemId=" + testItemId +
                ", category=" + category.getMyClusterId() +
                ", cluster=" + cluster.getMyClusterId() +
                '}';
    }
}
