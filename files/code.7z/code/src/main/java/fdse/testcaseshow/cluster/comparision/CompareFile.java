package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.evaluation.ClusterEvaluation;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CompareFile {
    public static final Pattern framePattern = Pattern.compile("at (([\\w$]+\\.)*)([\\w$]+)\\.([\\w$<>]+)\\(([\\.\\s\\w]+)(:\\d+)?\\)", Pattern.DOTALL);

    private static String getFileName(TestItem testItem) {
        if (testItem.getStackTrace() == null)
            return null;
        String[] lines = testItem.getStackTrace().split("\\n");
        for (String line : lines) {
            String s = line.trim();
            Matcher matcher = framePattern.matcher(s);
            if (s.startsWith("at") && matcher.find()) {
                return matcher.group(5);
            }
        }
        return null;
    }

    public static List<List<TestItem>> compareFileCluster(List<TestItem> testItems) {
        List<List<TestItem>> testItemListList = new ArrayList<>();
        Map<String, List<TestItem>> map = new HashMap<>();
        for (TestItem testItem : testItems) {
            String key = getFileName(testItem);
            if (key == null) {
                testItemListList.add(new ArrayList<TestItem>(Arrays.asList(testItem)));
            } else {
                if (map.containsKey(key)) {
                    map.get(key).add(testItem);
                } else {
                    map.put(key, new ArrayList<TestItem>(Arrays.asList(testItem)));
                }
            }
        }
        for (List<TestItem> testItemList : map.values()) {
            testItemListList.add(testItemList);
        }
        return testItemListList;
    }

    public static void runException() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            ResultSummary resultSummary = new ResultSummary();
            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<List<TestItem>> testItemListList = compareFileCluster(selectedTestItems);
                List<Cluster> clusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.COMPARE_FILE, true, null)) {
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void runAssertion() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            ResultSummary resultSummary = new ResultSummary();
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
                List<List<TestItem>> testItemListList = compareFileCluster(selectedTestItems);
                List<Cluster> clusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
                resultSummary.addSingleResult(testCase, clusters, false);
            }
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.COMPARE_FILE, true, "Assertion")) {
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        runException();
        Instant end = Instant.now();
    }
}
