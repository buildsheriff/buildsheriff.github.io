package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.FileUtil;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;

public class ExtractJavaFileTask implements Runnable {
    private BlockingQueue<ExtractJavaFile.InJavaFile> inQueue;
    private BlockingQueue<ExtractJavaFile.OutJavaFile> outQueue;

    public ExtractJavaFileTask(BlockingQueue<ExtractJavaFile.InJavaFile> inQueue, BlockingQueue<ExtractJavaFile.OutJavaFile> outQueue) {
        this.inQueue = inQueue;
        this.outQueue = outQueue;
    }

    private ExtractJavaFile.InJavaFile getInJavaFile() {
        ExtractJavaFile.InJavaFile inJavaFile = null;
        try {
            inJavaFile = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return inJavaFile;
    }

    private void putOutJavaFile(ExtractJavaFile.OutJavaFile outJavaFile) {
        try {
            outQueue.put(outJavaFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (true) {
            ExtractJavaFile.InJavaFile inJavaFile = getInJavaFile();
            if (inJavaFile.getTestCaseId() < 0)
                break;
            String filePath = inJavaFile.getFilePath();
            String repoPath = inJavaFile.getRepoPath();
            JavaVisitor visitor = FileUtil.getJavaFileInfo(filePath);
            if (visitor == null) {
                continue;
            }
            String packageName = visitor.getPackageName();
            JavaFile javaFile = new JavaFile();
            javaFile.setFilePath(FileUtil.getFileRelativePath(filePath));
            javaFile.setCompleteFileName(FileUtil.getCompleteFileName(filePath, repoPath));
            javaFile.setFileName(FileUtil.getFileName(filePath));
            javaFile.setPackageName(packageName);
            Set<String> typeNameList = visitor.getTypeNameList();
            Set<String> fullTypeNameList = new HashSet<>();
            typeNameList.forEach(typeName -> {
                fullTypeNameList.add(packageName + "." + typeName);

            });
            fullTypeNameList.forEach(fullTypeName -> {
                javaFile.getTypeNames().add(fullTypeName);

            });
            putOutJavaFile(new ExtractJavaFile.OutJavaFile(inJavaFile.getTestCaseId(), javaFile));
        }

    }
}
