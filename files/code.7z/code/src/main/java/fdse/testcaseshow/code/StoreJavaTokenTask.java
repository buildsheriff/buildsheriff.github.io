package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.concurrent.BlockingQueue;

public class StoreJavaTokenTask implements Runnable {
    private BlockingQueue<JavaFileToken> outQueue;

    public StoreJavaTokenTask(BlockingQueue<JavaFileToken> outQueue) {
        this.outQueue = outQueue;
    }

    private JavaFileToken takeJavaFileToken() {
        JavaFileToken javaFileToken = null;
        try {
            javaFileToken = outQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return javaFileToken;
    }

    @Override
    public void run() {
        Session session = SessionUtil.getSession();
        JavaFileToken javaFileToken = null;
        Object o = session.createQuery("select max(f.id) from JavaFileToken f").getSingleResult();
        Long id = null;
        if (o == null){
            id = 0L;
        } else {
            id = (Long) o;
        }
        Transaction tx = session.beginTransaction();
        int i = 0;
        while (true) {
            javaFileToken = takeJavaFileToken();
            if (javaFileToken.getDistance() == -1)
                break;
            id++;
            javaFileToken.setId(id);
            session.save(javaFileToken);
            i++;
            if (i % 1000 == 0) {
                session.flush();
                session.clear();
            }
        }
        tx.commit();
        session.close();
    }
}
