package fdse.testcaseshow.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.hibernate.annotations.Where;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.data.rest.core.config.Projection;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Data
@RequiredArgsConstructor
@Entity
@Table(name = "test_cases")
public class TestCase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "repo_name")
    private String repoName;

    @Column(name = "job_number")
    private String jobNumber;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(columnDefinition = "Text")
    private String description;

    @Column(name = "include_exception")
    private Boolean includeException;

    @Column(name = "include_assertion")
    private Boolean includeAssertion;

    private Integer number;

    @Column(name = "cause_url")
    private String causeUrl;

    @Column(name = "pre_commit")
    private String preCommit;

    @Column(name = "current_commit")
    private String currentCommit;

    @Column(name = "multiple_crash")
    private Boolean multipleCrash;

    @Column(name = "crash_cluster_num")
    private Integer crashClusterNum;

    @Column(name = "my_cluster")
    private Integer myCluster;

    @Column(name = "frame1")
    private Integer frame1;

    @Column(name = "frame2")
    private Integer frame2;

    @Column(name = "frame3")
    private Integer frame3;

    @Column(name = "file1")
    private Integer file1;

    @Column(name = "rule3")
    private Integer rule3;

    @Column(name = "rebucket")
    private Integer rebucket;

    @Column(name = "exception_message_sim")
    private Integer exceptionMessageSim;

    @Column(name = "length")
    private Integer length;

    @Column(name = "aLength")
    private Integer assertionLength;

    @Column(name = "config_changed")
    private Boolean configChanged;

    @Column(name = "multiple_assertion")
    private Boolean multipleAssertion;

    @Column(name = "assertion_cluster_num")
    private Integer assertionClusterNum;

    @Column(name = "multiple_error")
    private Boolean multipleError;

    @Column(name = "cluster_num")
    private Integer clusterNum;

    @Column(name = "assertion_code_sim")
    private Integer assertionCodeSim;

    @Column(name = "no_stack_trace")
    private Boolean noStackTrace;

    @Column(name = "my_cluster_no_delete")
    private Integer myClusterNoDelete;

    @Column(name = "my_cluster_no_merge")
    private Integer myClusterNoMerge;

    @Column(name = "crash_ignore")
    private Boolean crashIgnore;

    @Column(name = "assertion_ignore")
    private Boolean assertionIgnore;

    @Column(name = "exception_message_sim_1")
    private Integer exceptionMessageSim74;
    //    @ElementCollection
//    @Column(name = "fix_url")
//    private List<String> fixUrls;
    @OneToMany(targetEntity = TestItem.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<TestItem> testItems = new ArrayList<>();
@OneToOne(cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name="test_log_id")
    private TestLog testLog;

    @OneToMany(targetEntity = ChangedFile.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<ChangedFile> changedFiles = new ArrayList<>();

    @OneToMany(targetEntity = JavaFile.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<JavaFile> javaFiles = new ArrayList<>();

    @OneToMany(targetEntity = TestFrame.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<TestFrame> testFrames = new ArrayList<>();

    @Convert(converter = StringListConverter.class)
    @Column(name = "figs")
    private List<String> figs = new ArrayList<>();

    @OneToMany(targetEntity = ChangedToken.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<ChangedToken> changedTokens = new ArrayList<>();

    @OneToMany(targetEntity = JavaFileToken.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="testCase")
    private Collection<JavaFileToken> javaFileTokens = new ArrayList<>();

}
