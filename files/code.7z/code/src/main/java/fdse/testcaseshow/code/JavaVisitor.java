package fdse.testcaseshow.code;

import org.eclipse.jdt.core.dom.*;

import java.util.*;


public class JavaVisitor extends ASTVisitor {
    private CompilationUnit compilationUnit = null;
    private String packageName;
    private Set<String> typeNameList = new LinkedHashSet<>();
    private Set<ImportDeclaration> imports = new LinkedHashSet<>();
    private List<ExtractCode.MethodInfo> methodInfos = new ArrayList<>();
    private List<String> superClassNames = new ArrayList<>();


    public String getPackageName() {
        return packageName;
    }

    public Set<String> getTypeNameList() {
        return typeNameList;
    }

    public Set<ImportDeclaration> getImports() {
        return imports;
    }

    public List<ExtractCode.MethodInfo> getMethodInfos() {
        return methodInfos;
    }

    public List<String> getSuperClassNames() {
        return superClassNames;
    }

    public CompilationUnit getCompilationUnit() {
        return compilationUnit;
    }

    public JavaVisitor(CompilationUnit compilationUnit){
      super();
      this.compilationUnit = compilationUnit;
    }

    @Override
    public void preVisit(ASTNode node) {
        int nodeTypeNumber = node.getNodeType();
        String nodeTypeName = node.getClass().getSimpleName();
        int startPosition = node.getStartPosition();
        int length = node.getLength();
        int startLineNumber = compilationUnit.getLineNumber(startPosition);
        int endLineNumber = compilationUnit.getLineNumber(startPosition + length - 1);
    }

    @Override
    public boolean visit(MethodDeclaration md) {
        ExtractCode.MethodInfo methodInfo = new ExtractCode.MethodInfo(
                md,
                compilationUnit.getLineNumber(md.getStartPosition()),
                compilationUnit.getLineNumber(md.getStartPosition() + md.getLength() - 1)
        );
        methodInfos.add(methodInfo);
        return true;
    }

    @Override
    public boolean visit(ImportDeclaration id) {
        imports.add(id);
        return true;
    }

    @Override
    public boolean visit(PackageDeclaration pd) {
        packageName = pd.getName().getFullyQualifiedName();
        return true;
    }

    @Override
    public boolean visit(TypeDeclaration td) {
        String typeName = td.getName().getFullyQualifiedName();
        typeNameList.add(typeName);
        if (td.getSuperclassType() != null) {
            superClassNames.add(td.getSuperclassType().toString());
        }
        return true;
    }


}
