package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.cluster.*;
import fdse.testcaseshow.cluster.codesim.CodeSimilarity;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.STSimilarityResultSummary;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestFrame;
import fdse.testcaseshow.model.TestItem;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class STSimilaritySlave implements Runnable {
    private BlockingQueue<STSimilarity.Coefficient> inQueue;
    private List<TestCase> testCases;
    private BlockingQueue<ResultSummary> outQueue;
    public STSimilaritySlave(List<TestCase> testCases, BlockingQueue<STSimilarity.Coefficient> inQueue, BlockingQueue<ResultSummary> outQueue) {
        this.inQueue = inQueue;
        this.testCases = testCases;
        this.outQueue = outQueue;
    }

    public STSimilarity.Coefficient getCoefficient() {
        STSimilarity.Coefficient coefficient = null;
        try {
            coefficient = inQueue.take();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return coefficient;
    }

    public void putResult(ResultSummary resultSummary) {
        try {
            outQueue.put(resultSummary);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            STSimilarity.Coefficient coefficient = getCoefficient();
            if (coefficient.getMaxDistance() <= -1) {
                break;
            }
            ResultSummary resultSummary = new STSimilarityResultSummary(coefficient);
            for (TestCase testCase : testCases) {
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<Cluster> clusters = STSimilarity.clusterBuild(coefficient.getSMax(),
                        coefficient.getC(), coefficient.getMaxDistance(), selectedTestItems);
                resultSummary.addSingleResult(testCase, clusters, true);
            }
            putResult(resultSummary);
        }

    }
}
