package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.combine.CombineMethod;
import lombok.Getter;

public class CombineRatioResultSummary extends ResultSummary {
    @Getter
    private CombineMethod.Coefficient coefficient;

    public CombineRatioResultSummary(CombineMethod.Coefficient coefficient) {
        this.coefficient = coefficient;
    }
    @Override
    public String toString() {
        String s = "STSimilarity parameters\n";
        if (coefficient.getCoefficientA() != null)
            s = s + coefficient.getCoefficientA().toString() + " ";
        if (coefficient.getCoefficientB() != null)
            s = s + coefficient.getCoefficientB().toString() + " ";
        s = s + String.format("sMax: %.2f ratio: %.2f\n", coefficient.getSMax(), coefficient.getRatio());
        s += super.toString();
        return s;
    }
}
