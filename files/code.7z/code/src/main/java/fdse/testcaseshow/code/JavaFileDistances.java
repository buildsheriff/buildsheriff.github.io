package fdse.testcaseshow.code;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import lombok.Data;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class JavaFileDistances {
    private BlockingQueue<Long> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<fdse.testcaseshow.model.JavaFileDistance> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 1;

    private void setMysql() {
        try (Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete JavaFileDistance";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            tx.commit();
        }
    }

    private void putTestCaseId(long testCaseId) {
        try {
            inQueue.put(testCaseId);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new JavaFileDistancesTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }

    public void distance() {
        setMysql();
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreJavaDistanceTask(outQueue));
        initializeThreads(threads, storeThread);
        try(Session session = SessionUtil.getSession()) {
            //Query<TestCase> query = session.createQuery("from TestCase where id >= 306", TestCase.class);
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            //List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            for (TestCase testCase : testCases) {

                System.out.println(testCase.getId());
                putTestCaseId(testCase.getId());



            }
        }
        for (int i = 0; i < THREAD_NUMBER; i++) {
            putTestCaseId(-1L);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            JavaFileDistance javaFileDistance = new JavaFileDistance();
            javaFileDistance.setId(-1L);
            outQueue.put(javaFileDistance);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    public void depthFirst() {

    }

    public void setFrameDistance() {
        Session session = SessionUtil.getSession();
        Query<TestFrame> query = session.createQuery("from TestFrame where id > 0", TestFrame.class);
        List<TestFrame> testFrames = query.getResultList();
        for (TestFrame testFrame : testFrames) {
        }
        session.close();
    }
    @Data
    public static class Node {
        public JavaFile javaFile;
        public int distance = Integer.MAX_VALUE;
        public Node pre;
        public String color = "white";
        public List<Node> adjNodes = new ArrayList<>();

        public void clear() {
            distance = Integer.MAX_VALUE;
            pre = null;
            color = "white";
        }
    }

    public static void main(String[] args) throws IOException {
        Instant start = Instant.now();
        JavaFileDistances ge = new JavaFileDistances();
        ge.distance();
        Instant end = Instant.now();
    }
}

