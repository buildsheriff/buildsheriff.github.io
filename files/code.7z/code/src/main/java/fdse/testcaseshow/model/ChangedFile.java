package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "changed_files")
public class ChangedFile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "status")
    private String status;

    @Column(name = "pre_file_path")
    private String preFilePath;

    @Column(name = "current_file_path")
    private String currentFilePath;

    @OneToMany(targetEntity = ChangedMethod.class, cascade=CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name="changed_file_id")
    private List<ChangedMethod> changedMethods;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;
}

