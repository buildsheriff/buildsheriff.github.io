package fdse.testcaseshow.model;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Converter
public class StringListConverter implements AttributeConverter<List<String>, String> {
    private static final String SPLIT_CHAR = "\n";

    @Override
    public String convertToDatabaseColumn(List<String> stringList) {
        return (stringList == null)? null : String.join(SPLIT_CHAR, stringList);
    }

    @Override
    public List<String> convertToEntityAttribute(String string) {

        return (string == null)? new ArrayList<>() : new ArrayList<>(Arrays.asList(string.split(SPLIT_CHAR)));
    }
}