package fdse.testcaseshow.model;

import lombok.*;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "test_items")
public class TestItem {
    @Id
    private Long id;

    @Column(name = "class_name")
    private String className;

    @Column(name = "line_number")
    private Integer lineNumber;

    @Column(name = "summary")
    private String summary;

    @Column(name = "method_name")
    private String methodName;

    @Column(name = "error_message")
    private String errorMessage;

    @Column(name = "stack_trace")
    private String stackTrace;

    @Column(name = "length")
    private Integer length;

    @Column(name = "del_length")
    private Integer delLength;

    @OneToMany(targetEntity = TestFrame.class, fetch = FetchType.LAZY, mappedBy="testItem")
    private Collection<TestFrame> testFrames = new ArrayList<>();

    @Column(name = "crash_flag")
    private boolean isCrash;

    @Column(name = "cluster_type")
    private Integer clusterType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="test_case_id")
    private TestCase testCase;

    @OneToOne(targetEntity = TestCode.class, fetch = FetchType.LAZY, mappedBy = "testItem")
    private TestCode testCode;

    @OneToMany(targetEntity = TestCodeStatement.class, fetch = FetchType.LAZY, mappedBy="testItem")
    private Collection<TestCodeStatement> testCodeStatements = new ArrayList<>();
}

