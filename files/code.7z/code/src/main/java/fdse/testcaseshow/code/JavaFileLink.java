package fdse.testcaseshow.code;

import fdse.testcaseshow.model.FileToFile;
import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class JavaFileLink {
    private BlockingQueue<JavaFile> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<FileToFile> outQueue = new ArrayBlockingQueue<>(20);
    private static final int THREAD_NUMBER = 20;

    private void putJavaFile(JavaFile javaFile) {
        try {
            inQueue.put(javaFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private void clear() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            String hqlUpdate = "delete FileToFile ";
            int updatedEntities = session.createQuery(hqlUpdate).executeUpdate();
            tx.commit();
        }
    }

    private void initializeThreads(List<Thread> threads, Thread thread) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new JavaFileLinkTask(inQueue, outQueue));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
    }
    public void extractImportInfo() {
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreFileLinkTask(outQueue));
        initializeThreads(threads, storeThread);
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            System.out.println(testCases.size());
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                for (JavaFile javaFile : testCase.getJavaFiles()) {
                    extractImportInfo(javaFile);
                }
            }
        }
        for (int i = 0; i < THREAD_NUMBER; i++) {
            JavaFile sentry = new JavaFile();
            sentry.setId(-1L);
            putJavaFile(sentry);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            FileToFile fileToFile = new FileToFile();
            fileToFile.setUsingId(-1L);
            outQueue.put(fileToFile);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public void extractImportInfo(JavaFile javaFile) {
        putJavaFile(javaFile);

    }
    public static void main(String[] args) {
        Instant start = Instant.now();
        JavaFileLink javaFileLink = new JavaFileLink();
        javaFileLink.extractImportInfo();
        Instant end = Instant.now();
        System.out.println("" + Duration.between(start, end));
    }
}
