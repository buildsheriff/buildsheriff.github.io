package fdse.testcaseshow.cluster.combine;

import fdse.testcaseshow.cluster.*;
import fdse.testcaseshow.model.TestItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

public class MergeRatioSimilarity extends AHCluster {
    private double c;
    private int maxDistance;
    private double ratio;
    private STSimilarity stSimilarity;
    private ExceptionSimilarity exceptionSimilarity;
    public MergeRatioSimilarity(List<DataPoint> dataPoints, double c, int maxDistance, double ratio, double sMax) {
        super(dataPoints, sMax);
        this.c = c;
        this.maxDistance = maxDistance;
        this.ratio = ratio;
        this.stSimilarity = new STSimilarity(null, 0.0, c, maxDistance);
        this.exceptionSimilarity = new ExceptionSimilarity(null, 0.0);
    }

    @Override
    public double getSim(TestItem testItem1, TestItem testItem2) {
        double stSim = stSimilarity.getSim(testItem1, testItem2);
        double exSim = exceptionSimilarity.getSim(testItem1, testItem2);
        return ratio * stSim + (1 - ratio) * exSim;
    }
    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<Cluster> clusterBuild(List<TestItem> testItems, double c, int maxDistance, double ratio, double sMax) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new MergeRatioSimilarity(dataPoints, c, maxDistance, ratio, sMax).startCluster();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient {
        private double c;
        private int maxDistance;
        private double ratio;
        private double sMax;
    }
}