package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.feature.TokenType;
import fdse.testcaseshow.model.JavaFileToken;

import java.util.Collection;
import java.util.Map;

public interface IStatementMatch {
    double getStatementSim(Collection<String> statementTokens, Collection<Collection<String>> statementTokensList, Map<String, Integer> distanceMap, double matchThreshold, double c);

    default boolean isMatch(Collection<String> statementTokens, Collection<Collection<String>> statementTokensList, Map<String, Integer> distanceMap, double matchThreshold,  double c) {
        double sim = getStatementSim(statementTokens, statementTokensList, distanceMap, matchThreshold, c);
        if (sim > matchThreshold) {
            return true;
        } else {
            return false;
        }
    }
}
