package fdse.testcaseshow.model;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor(access = AccessLevel.PUBLIC)
@NoArgsConstructor(access = AccessLevel.PUBLIC, force = true)
@Entity
@Table(name = "file_to_files")
public class FileToFile {
    @Id
    private long id;

    @Column(name = "using_id")
    private long usingId;

    @Column(name = "used_id")
    private long usedId;
}
