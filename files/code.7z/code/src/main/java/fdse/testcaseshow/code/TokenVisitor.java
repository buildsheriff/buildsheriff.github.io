package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFileToken;
import lombok.Getter;
import org.eclipse.jdt.core.dom.*;

import java.util.HashSet;
import java.util.Set;

public class TokenVisitor extends ASTVisitor {
    @Getter
    Set<String> classNames = new HashSet<>();
    @Getter
    Set<String> methodNames = new HashSet<>();
    @Getter
    Set<String> fieldNames = new HashSet<>();

    @Override
    public boolean visit(FieldDeclaration node) {
        for (Object fragment : node.fragments()) {
            fieldNames.add(((VariableDeclarationFragment)fragment).getName().toString());
        }
        return super.visit(node);
    }

    @Override
    public boolean visit(MethodDeclaration node) {
        methodNames.add(node.getName().toString());
        return super.visit(node);
    }

    @Override
    public boolean visit(TypeDeclaration node) {
        classNames.add(node.getName().toString());
        return super.visit(node);
    }
}
