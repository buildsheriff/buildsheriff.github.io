package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.model.TestItem;
import org.javatuples.Pair;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class StoreResultSummary implements AutoCloseable {
    public enum Method {
        COMPARE_FILE,
        FRAME1,
        REBUCKET,
        STSIMILARITY,
        EXCEPTIONSIMILARITY,
        CODESIMILARITY,
        NAIVESTSIMILARITY,

        EQUALEXCEPTIONSIMILARITY,
        CUTSTSIMILARITY,
        STSIMILARITYWITHOUTDISTANCE,
        ASSERTIONMESSAGE,

        MERGERATIO
    }
    private boolean isTuning;
    private PrintWriter clusterOut;
    private PrintWriter metricOut;
    public StoreResultSummary(Method method, boolean isTuning, String fileName) throws FileNotFoundException {
        String clusterFileName = null;
        String metricFileName = null;
        if (method == Method.COMPARE_FILE) {
            if (fileName == null) {
                clusterFileName = "CompareFileClusters.txt";
                metricFileName = "CompareFileMetrics.txt";
            } else {
                clusterFileName = "CompareFile" + fileName + "Clusters.txt";
                metricFileName = "CompareFile" + fileName + "Metrics.txt";
            }
        } else if (method == Method.FRAME1) {
            if (fileName == null) {
                clusterFileName = "Frame1Clusters.txt";
                metricFileName = "Frame1Metrics.txt";
            } else {
                clusterFileName = "Frame1" + fileName + "Clusters.txt";
                metricFileName = "Frame1" + fileName + "Metrics.txt";
            }
        } else if (method == Method.REBUCKET) {
            if (fileName == null) {
                clusterFileName = "RebucketClusters.txt";
                metricFileName = "RebucketMetrics.txt";
            } else {
                clusterFileName = "Rebucket" + fileName + "Clusters.txt";
                metricFileName = "Rebucket" + fileName + "Metrics.txt";
            }
        } else if (method == Method.STSIMILARITY) {
            if (fileName == null) {
                clusterFileName = "STSimilarityClusters.txt";
                metricFileName = "STSimilarityMetrics.txt";
            } else {
                clusterFileName = "STSimilarity" + fileName + "Clusters.txt";
                metricFileName = "STSimilarity" + fileName + "Metrics.txt";
            }
        } else if (method == Method.EXCEPTIONSIMILARITY) {
            clusterFileName = "ExceptionSimilarityClusters.txt";
            metricFileName = "ExceptionSimilarityMetrics.txt";
        } else if (method == Method.NAIVESTSIMILARITY) {
            clusterFileName = "NaiveSTSimilarityClusters.txt";
            metricFileName = "NaiveSTSimilarityMetrics.txt";
        } else if (method == Method.CODESIMILARITY) {
            if (fileName == null) {
                clusterFileName = "CodeSimilarityClusters.txt";
                metricFileName = "CodeSimilarityMetrics.txt";
            } else {
                clusterFileName = "CodeSimilarity" + fileName + "Clusters.txt";
                metricFileName = "CodeSimilarity" + fileName + "Metrics.txt";
            }
        } else if (method == Method.EQUALEXCEPTIONSIMILARITY) {
            clusterFileName = "EqualExceptionSimilarityClusters.txt";
            metricFileName = "EqualExceptionSimilarityMetrics.txt";
        } else if (method == Method.CUTSTSIMILARITY) {
            clusterFileName = "CutSTSimilarityClusters.txt";
            metricFileName = "CutSTSimilarityMetrics.txt";
        } else if (method == Method.STSIMILARITYWITHOUTDISTANCE) {
            clusterFileName = "STSimilarityWithoutDistanceClusters.txt";
            metricFileName = "STSimilarityWithoutDistanceMetrics.txt";
        } else if (method == Method.ASSERTIONMESSAGE) {
            clusterFileName = "AssertionMessageClusters.txt";
            metricFileName = "AssertionMessageMetrics.txt";
        } else if (method == Method.MERGERATIO) {
            if (fileName == null) {
                clusterFileName = "MergeRatioClusters.txt";
                metricFileName = "MergeRatioMetrics.txt";
            } else {
                clusterFileName = "Combine" + fileName + "Clusters.txt";
                metricFileName = "Combine" + fileName + "Metrics.txt";
            }
        }
        String dirName = null;
        if (isTuning) {
            dirName = "tuningResult";
        } else {
            dirName = "result";
        }
        Path clusterFilePath = Paths.get(System.getProperty("user.dir"), "doc", dirName, clusterFileName);
        Path metricFilePath = Paths.get(System.getProperty("user.dir"), "doc", dirName, metricFileName);
        if (isTuning == false) {
            this.clusterOut = new PrintWriter(clusterFilePath.toString());
        }
        this.metricOut = new PrintWriter(metricFilePath.toString());
        this.isTuning = isTuning;
    }

    public void write(ResultSummary resultSummary) {
        if (isTuning == false) {
            for (SingleResult singleResult : resultSummary.getSingleResultList()) {
                clusterOut.print(singleResult.toStringOfClusterResult());
            }
        }
        metricOut.println(resultSummary);
    }

    public void close() {
        if (isTuning == false) {
            clusterOut.close();
        }
        metricOut.close();
    }
}
