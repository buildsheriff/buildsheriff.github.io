package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Quartet;
import org.javatuples.Triplet;

import java.util.List;

public class CountingPairMetrics {
    public static Quartet<Integer, Integer, Integer, Integer> getCountingPairs(List<MyDataPoint> myDataPoints) {
        int ss = 0;
        int sd = 0;
        int ds = 0;
        int dd = 0;
        for (int i = 0; i < myDataPoints.size() - 1; i++) {
            for (int j = i + 1; j < myDataPoints.size(); j++) {
                MyDataPoint myDataPointA = myDataPoints.get(i);
                MyDataPoint myDataPointB = myDataPoints.get(j);

                if (myDataPointA.getCluster() == myDataPointB.getCluster() && myDataPointA.getCategory() == myDataPointB.getCategory()) {
                    ss += 1;
                } else if (myDataPointA.getCluster() == myDataPointB.getCluster() && myDataPointA.getCategory() != myDataPointB.getCategory()) {
                    sd += 1;
                } else if (myDataPointA.getCluster() != myDataPointB.getCluster() && myDataPointA.getCategory() == myDataPointB.getCategory()) {
                    ds += 1;
                } else if (myDataPointA.getCluster() != myDataPointB.getCluster() && myDataPointA.getCategory() != myDataPointB.getCategory()) {
                    dd += 1;
                }
            }
        }

        return  Quartet.with(ss, sd, ds, dd);
    }

    public static double getRandStatisticR(int ss, int sd, int ds, int dd) {
        return 1.0 * (ss + dd) / (ss + sd + ds + dd);
    }

    public static double getJaccardCoefficientJ(int ss, int sd, int ds) {
        return 1.0 * ss / (ss + sd + ds);
    }

    public static double getFolkesAndMallowsFM(int ss, int sd, int ds) {

        return Math.sqrt(1.0 * ss * ss / (ss + sd) / (ss + ds));
    }

    public static Triplet<Double, Double, Double> getCountingPairsMetrics(List<Cluster> ahClusters) {
        Quartet<List<MyCluster>, List<MyCluster>, List<MyDataPoint>, Integer> quartet = ClusterEvaluation.clusterListToMyDataPointList(ahClusters);
        List<MyCluster> categories = quartet.getValue0();
        List<MyCluster> clusters = quartet.getValue1();
        List<MyDataPoint> myDataPoints = quartet.getValue2();
        Quartet<Integer, Integer, Integer, Integer> countingPairs = getCountingPairs(myDataPoints);
        int ss = countingPairs.getValue0();
        int sd = countingPairs.getValue1();
        int ds = countingPairs.getValue2();
        int dd = countingPairs.getValue3();
        double randStatisticR = getRandStatisticR(ss, sd, ds, dd);
        double jaccardCoefficientJ = getJaccardCoefficientJ(ss,sd, ds);
        double folkesAndMallowsFM = getFolkesAndMallowsFM(ss, sd, ds);
        return  Triplet.with(randStatisticR, jaccardCoefficientJ, folkesAndMallowsFM);
    }
}
