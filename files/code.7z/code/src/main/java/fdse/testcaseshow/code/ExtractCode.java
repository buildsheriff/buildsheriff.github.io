package fdse.testcaseshow.code;

import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.SessionUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.eclipse.jdt.core.dom.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ExtractCode {
    private BlockingQueue<TestItem> inQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<TestCode> outQueue = new ArrayBlockingQueue<>(20);
    private BlockingQueue<TestCodeStatement> outQueue1 = new ArrayBlockingQueue<>(20);

    private static final int THREAD_NUMBER = 1;

    private void putTestItem(TestItem testItem) {
        try {
            inQueue.put(testItem);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private void clear() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx = session.beginTransaction();
            session.createQuery("delete TestCode").executeUpdate();
            session.createNativeQuery("ALTER TABLE test_codes AUTO_INCREMENT = 1").executeUpdate();
            session.createQuery("delete TestCodeStatement").executeUpdate();
            session.createNativeQuery("ALTER TABLE test_code_statements AUTO_INCREMENT = 1").executeUpdate();

            tx.commit();
        }
    }
    private void initializeThreads(List<Thread> threads, Thread thread, Thread thread1) {
        for (int i = 0; i < THREAD_NUMBER; i++) {
            Thread tmpThread = new Thread(new ExtractCodeTask(inQueue, outQueue, outQueue1));
            threads.add(tmpThread);
            tmpThread.start();
        }
        thread.start();
        thread1.start();
    }
    public void run() {
        clear();
        List<Thread> threads = new ArrayList<>();
        Thread storeThread = new Thread(new StoreCodeTask(outQueue));
        Thread storeThread1 = new Thread(new StoreCodeStatement(outQueue1));
        initializeThreads(threads, storeThread, storeThread1);
        try (Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id >= 0", TestCase.class);
            List<TestCase> testCases = query.list();
            System.out.println(testCases.size());
            for (TestCase testCase : testCases) {
                System.out.println(testCase.getId());
                if (testCase.getCurrentCommit() == null || testCase.getCurrentCommit().equals("null")) {
                    continue;
                }
                Collection<TestItem> testItems = testCase.getTestItems();
                for (TestItem testItem : testItems) {
                    if ((testItem.getClassName() != null && testItem.getMethodName() != null) || testItem.getStackTrace() != null ) {
                        putTestItem(testItem);
                    } else {
                    }
                }
            }
        }
        for (int i = 0; i < THREAD_NUMBER; i++) {
            TestItem testItem = new TestItem();
            testItem.setId(-1L);
            putTestItem(testItem);
        }
        threads.forEach(thread -> {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        try {
            TestCode testCode = new TestCode();
            testCode.setId(-1L);
            outQueue.put(testCode);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            TestCodeStatement testCodeStatement = new TestCodeStatement();
            testCodeStatement.setId(-1L);
            outQueue1.put(testCodeStatement);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            storeThread1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        new ExtractCode().run();
        Instant end = Instant.now();

    }
    @Data
    @AllArgsConstructor
    public static class MethodInfo {
        private MethodDeclaration methodDeclaration;
        private int startLineNumber;
        private int endLineNumber;
    }
}