package fdse.testcaseshow.code;

import fdse.testcaseshow.code.gumtree.*;
import fdse.testcaseshow.model.ChangedFile;
import fdse.testcaseshow.model.ChangedMethod;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.FileUtil;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetChangedMethod {
    public static Pattern[] patterns = {Pattern.compile("src/(main|test)/java/(.*)\\.java"),
            Pattern.compile("(src/)(.*)\\.java"),
            Pattern.compile("(test/)(.*)\\.java"),

    };

    public static List<ChangedMethod> getChangedMethods(String preFilePath, String currentFilePath, String status) {
        if (currentFilePath.endsWith(".java") == false)
            return null;
        if (status.equals("modified") || status.equals("renamed")) {
            return getChangedMethodsModified(preFilePath, currentFilePath);
        } else if (status.equals("added")) {
            return getChangedMethodsAdded(currentFilePath);
        }
        return null;
    }

    public static List<ChangedMethod> getChangedMethodsModified(String preFilePath, String currentFilePath) {
        ITree src = FileUtil.getRoot(FileUtil.getTreeContextFromFile(preFilePath));
        ITree dst = FileUtil.getRoot(FileUtil.getTreeContextFromFile(currentFilePath));

        List<Action> actions = FileUtil.getActions(src, dst);
        List<ChangedMethod> methods = actionsToMethods(actions);
        return addFullClassName(currentFilePath, methods);
    }

    public static List<ChangedMethod> getChangedMethodsAdded(String currentFilePath) {
        ITree root = FileUtil.getRoot(FileUtil.getTreeContextFromFile(currentFilePath));
        List<ITree> iTrees = root.getBreadthFirstTreeNodeList();
        List<ChangedMethod> methods = iTreesToMethods(iTrees);
        return addFullClassName(currentFilePath, methods);
    }

    public static List<ChangedMethod> actionsToMethods(List<Action> actions) {
        List<ChangedMethod> methods = new ArrayList<>();
        for (Action action : actions) {
            List<ITree> parents = action.getNode().getParents();
            parents.add(action.getNode());
            List<ChangedMethod> tmpMethods = iTreesToMethods(parents);
            for (ChangedMethod method : tmpMethods) {
                if (methods.contains(method) == false) methods.add(method);
            }
        }

        for (Action action : actions) {
            if (action instanceof Delete) {
                JavaTree javaTree = (JavaTree) action.getNode();
                ASTNode astNode = action.getNode().getASTNode();
                if (astNode.getNodeType() == ASTNode.METHOD_DECLARATION) {
                    MethodDeclaration methodDeclaration = (MethodDeclaration)astNode;
                    String methodName = methodDeclaration.getName().getIdentifier();
                    int startLineNumber = javaTree.getStartLineNumber();
                    int endLineNumber = javaTree.getEndLineNumber();
                    ChangedMethod deletedMethod = null;
                    for (ChangedMethod method : methods) {
                        if (method.getMethodName().equals(methodName)
                                && method.getStartLineNumber() == startLineNumber
                                && method.getEndLineNumber() == endLineNumber){
                            deletedMethod = method;
                            break;
                        }
                    }
                    methods.remove(deletedMethod);
                }
            }
        }
        return methods;
    }

    public static List<ChangedMethod> iTreesToMethods(List<ITree> iTrees) {
        List<ChangedMethod> methods = new ArrayList<>();
        for (ITree iTree : iTrees) {
            if (iTree.getASTNode() != null && iTree.getASTNode().getNodeType() == ASTNode.METHOD_DECLARATION) {
                MethodDeclaration methodDeclaration = (MethodDeclaration) iTree.getASTNode();
                String methodName = methodDeclaration.getName().getIdentifier();
                JavaTree javaTree = (JavaTree)iTree;
                ChangedMethod tmpMethod = new ChangedMethod();
                tmpMethod.setMethodName(methodName);
                tmpMethod.setStartLineNumber(javaTree.getStartLineNumber());
                tmpMethod.setEndLineNumber(javaTree.getEndLineNumber());
                if (methods.contains(tmpMethod) == false) methods.add(tmpMethod);
            }
        }
        return methods;
    }

    public static List<ChangedMethod> addFullClassName(String fileName, List<ChangedMethod> methods) {
        String fullClassName = null;
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(fileName);
            if (matcher.find()) {
                fullClassName = matcher.group(2);
                break;
            }
        }

        for (ChangedMethod method : methods) {
            method.setClassName(fullClassName);
        }
        return methods;
    }

    public static void run() {
        try (Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getAssertionTestCases(session);
            testCases.forEach(testCase -> {
                extractFromTestCase(testCase, session);
            });
        }
    }
    public static void extractFromTestCase(TestCase testCase, Session session) {
        String repoName = testCase.getRepoName().trim();
        String jobNumber = testCase.getJobNumber().trim();
        if (testCase.getPreCommit() == null || testCase.getCurrentCommit() == null || testCase.getPreCommit().contains("null") || testCase.getCurrentCommit().contains("null")) {
            return;
        }
        String preCommit = testCase.getPreCommit().trim();
        String currentCommit = testCase.getCurrentCommit().trim();

        String preRepoPath = FileUtil.getRepoPath(preCommit);
        String currentRepoPath = FileUtil.getRepoPath(currentCommit);

        if (preRepoPath == null || currentRepoPath == null) {
            return;
        }
        Transaction tx = session.beginTransaction();
        for (ChangedFile changedFile : testCase.getChangedFiles()) {
            String status = changedFile.getStatus();
            String preFilePath = Paths.get(preRepoPath, changedFile.getPreFilePath()).toString();
            String currentFilePath = Paths.get(currentRepoPath, changedFile.getCurrentFilePath()).toString();
            List<ChangedMethod> list = getChangedMethods(preFilePath, currentFilePath, status);
            if (list != null)
                list.forEach(e -> changedFile.getChangedMethods().add(e));
        }
        tx.commit();
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        GetChangedMethod.run();
        Instant end = Instant.now();
    }

}
