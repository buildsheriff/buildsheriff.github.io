package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.cluster.AHCluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.cluster.combine.CoefficientInterface;
import fdse.testcaseshow.cluster.combine.SimInterface;
import fdse.testcaseshow.model.*;
import fdse.testcaseshow.util.FileUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.eclipse.jdt.core.dom.Statement;

import java.util.*;

public abstract class CodeSimilarity extends AHCluster implements SimInterface {
    protected Collection<JavaFileToken> javaFileTokens = null;
    protected static Map<Long, Map<String, Integer>> distanceMaps = new HashMap<>();
    protected CodeSimilarity.Coefficient coefficient;
    protected long testCaseId;

    public CodeSimilarity(List<TestItem> testItems, Collection<JavaFileToken> javaFileTokens, CodeSimilarity.Coefficient coefficient) {
        super(coefficient.getThreshold(), testItems);
        this.javaFileTokens = javaFileTokens;
        this.coefficient = coefficient;
        this.testCaseId = testItems.get(0).getTestCase().getId();
        registerDistanceMap(this.testItems.get(0).getTestCase(), this.testItems, javaFileTokens, coefficient.maxDistance);
    }

    public static synchronized void registerDistanceMap(TestCase testCase, List<TestItem> testItems, Collection<JavaFileToken> javaFileTokens, int maxDistance) {
        long id = testCase.getId();
        if (distanceMaps.containsKey(id))
            return;

        List<String> tokens = new ArrayList<>();
        for (TestItem testItem : testItems) {
            tokens.addAll(getCodeTokens(testItem));
            if (testItem.getMethodName() != null)
                tokens.add(testItem.getMethodName());
            if (testItem.getTestCode() != null && testItem.getTestCode().getParameters() != null)
                tokens.addAll(Arrays.asList(testItem.getTestCode().getParameters().split(" ")));
        }
        Map<String, Integer> distanceMap = CodeSimUtil.getDistanceMap(tokens, javaFileTokens, maxDistance);
        distanceMaps.put(id, distanceMap);
    }

    public static Map<String, Integer> getDistanceMap(long testCaseId) {
        if (distanceMaps.containsKey(testCaseId)) {
            return distanceMaps.get(testCaseId);
        } else {
            return null;
        }
    }

    public static List<String> getStatementTokens(TestCodeStatement testCodeStatement) {
        List<String> list = null;
        Statement st = CodeSimUtil.parseStatement(testCodeStatement.getStatement());
        if (st == null) {
            list = new ArrayList<>();
        } else {
            StatementVisitor visitor = new StatementVisitor();
            st.accept(visitor);
            // names.addAll(visitor.getSimpleNames());
            list = visitor.getNames();
        }
        return list;
    }

    public static boolean testCodeStatementValidation(TestItem testItem, TestCodeStatement testCodeStatement) {
        if (testItem.getTestCase() == null)
            return true;

        boolean flag = true;
        return flag;
    }

    public static List<TestCodeStatement> getTestCodeStatements(TestItem testItem) {
        List<TestCodeStatement> selectedTestCodeStatements = new ArrayList<>();
        Collection<TestCodeStatement> testCodeStatements = testItem.getTestCodeStatements();
        for (TestCodeStatement testCodeStatement : testCodeStatements) {
            if (testCodeStatementValidation(testItem, testCodeStatement))
                selectedTestCodeStatements.add(testCodeStatement);
        }
       return selectedTestCodeStatements;
    }



    public static List<String> getCodeTokens(TestItem testItem) {
        List<String> tokens = new ArrayList<>();
        List<TestCodeStatement> selectedTestCodeStatements = getTestCodeStatements(testItem);
        selectedTestCodeStatements.forEach(testCodeStatement -> {
            tokens.addAll(getStatementTokens(testCodeStatement));
        });
        return tokens;
    }

    public static List<String> getTokens(TestItem testItem, Map<String, Integer> distanceMap) {
        List<String> names = getCodeTokens(testItem);

        String methodName = testItem.getMethodName();
        if (distanceMap.get(methodName) != null) {
            names.add(methodName);
        }
        if (testItem.getTestCode() != null && testItem.getTestCode().getParameters() != null)
            names.addAll(Arrays.asList(testItem.getTestCode().getParameters().split(" ")));
        return names;
    }

    @Override
    public double getSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        return getMaxSim(dataPointsA, dataPointsB);
    }

    public static List<TestItem> getSelectedTestItems(TestCase testCase) {
        List<TestItem> selectedTestItems = new ArrayList<>();
        for (TestItem testItem : testCase.getTestItems()) {
            if (testItem.isCrash() == false) {
                selectedTestItems.add(testItem);
            }
        }
        return selectedTestItems;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Coefficient implements CoefficientInterface {
        private double cStatement;
        private double cComplete;
        private int maxDistance;
        private double matchThreshold;
        private double threshold;
    }

    public static void main(String[] args) {

    }

}
