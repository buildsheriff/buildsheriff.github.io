package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.model.TestItem;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AHClusterOld {
    private static Logger logger = LogManager.getLogger();
    private static final String MY_MRTHOD = "MyCluster";
    private static final String REBUCKET_METHOD = "Rebucket";
    private static final String TEST_CODE_METHOD = "Test code";

    private String method;
    private List<DataPoint> dataPoints;
    private double c;
    private double sMax;

    private double coC;
    private double coO;
    private Map<String, Double> simMap = new HashMap<>();
    public AHClusterOld(List<DataPoint> dataPoints, double sMax, String method) {
        this.dataPoints = dataPoints;
        this.sMax = sMax;
        this.method = method;
    }

    public AHClusterOld(List<DataPoint> dataPoints, double c, double sMax, String method) {
        this.dataPoints = dataPoints;
        this.c = c;
        this.sMax = sMax;
        this.method = method;
    }

    public AHClusterOld(List<DataPoint> dataPoints, double coC, double coO, double sMax, String method) {
        this.dataPoints = dataPoints;
        this.coC = coC;
        this.coO = coO;
        this.sMax = sMax;
        this.method = method;
    }

    private List<Cluster> initialCluster() {
        List<Cluster> originalClusters = new ArrayList<>();

        for (int i = 0; i < dataPoints.size(); i++) {
            DataPoint tempDataPoint = dataPoints.get(i);
            List<DataPoint> tempDataPoints = new ArrayList<DataPoint>();
            tempDataPoints.add(tempDataPoint);
            Cluster tempCluster = new Cluster();
            tempCluster.setClusterName("Cluster " + String.valueOf(i));
            tempCluster.setClusterID(i);
            tempCluster.setDataPoints(tempDataPoints);
            tempDataPoint.setCluster(tempCluster);
            originalClusters.add(tempCluster);
        }
        return originalClusters;
    }

    private double getSim(TestItem tiA, TestItem tiB) {
        String key = tiA.getId() + "diff" + tiB.getId();
        Double sim = simMap.get(key);
        if (sim == null) {
            double tempSim = 0.0;
            if (method.equals(MY_MRTHOD)) {
            } else if (method.equals(REBUCKET_METHOD)) {
                tempSim = Rebucket.getSimilarity(coC, coO, tiA, tiB);
            } else if (method.equals(TEST_CODE_METHOD)) {
            }
            simMap.put(key, tempSim);
            return tempSim;
        } else {
            return sim;
        }
    }

    private double getMinSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        double sim = 1.0;
        for (DataPoint a : dataPointsA) {
            for (DataPoint b : dataPointsB) {
                double tempSim = getSim(a.getTestItem(), b.getTestItem());
                if (tempSim < sim) sim = tempSim;
            }
        }
        return sim;
    }

    private double getMaxSim(List<DataPoint> dataPointsA, List<DataPoint> dataPointsB) {
        double sim = 0.0;
        for (DataPoint a : dataPointsA) {
            for (DataPoint b : dataPointsB) {
                double tempSim = getSim(a.getTestItem(), b.getTestItem());
                if (tempSim > sim) sim = tempSim;
            }
        }
        return sim;
    }

    private List<Cluster> mergeCluster(List<Cluster> finalClusters, int mergeIndexA, int mergeIndexB) {
        if (mergeIndexA != mergeIndexB) {
            Cluster clusterA = finalClusters.get(mergeIndexA);
            Cluster clusterB = finalClusters.get(mergeIndexB);

            List<DataPoint> dpA = clusterA.getDataPoints();
            List<DataPoint> dpB = clusterB.getDataPoints();

            for (DataPoint dp : dpB) {
                DataPoint tempDp = new DataPoint(dp.getID(), dp.getTestItem());
                tempDp.setCluster(clusterA);
                dpA.add(tempDp);
            }
            finalClusters.remove(mergeIndexB);
        }
        return finalClusters;
    }

    public List<Cluster> startCluster() {
        List<Cluster> finalClusters = initialCluster();
        boolean flag = true;
        int it = 1;
        while (flag) {
            double maxSim = -1;
            int mergeIndexA = 0;
            int mergeIndexB = 0;
            for (int i = 0; i < finalClusters.size() - 1; i++) {
                for (int j = i + 1; j < finalClusters.size(); j++) {
                    Cluster clusterA = finalClusters.get(i);
                    Cluster clusterB = finalClusters.get(j);
                    List<DataPoint> dataPointsA = clusterA.getDataPoints();
                    List<DataPoint> dataPointsB = clusterB.getDataPoints();
                    double tempSim = 0.0;
                    if (method.equals(MY_MRTHOD) || method.equals(TEST_CODE_METHOD)) {
                        tempSim = getMinSim(dataPointsA, dataPointsB);

                    } else if (method.equals(REBUCKET_METHOD)) {
                        tempSim = getMaxSim(dataPointsA, dataPointsB);
                    }
                    if (tempSim > maxSim) {
                        maxSim = tempSim;
                        mergeIndexA = i;
                        mergeIndexB = j;
                    }
                }
            }
            if (maxSim < sMax) {
                flag = false;
            } else {
                finalClusters = mergeCluster(finalClusters, mergeIndexA, mergeIndexB);
            }
            it++;
        }
        return finalClusters;
    }

    public static List<Cluster> clusterBuild(double c, double sMax, List<TestItem> testItems) {
        logger.debug("\nCluster Build with c{} cMax = {}", c, sMax);
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            logger.debug("The stacktrace of TestItem {} {} {} is as follows:", testItem.getId(),testItem.getClassName(), testItem.getMethodName());
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new AHClusterOld(dataPoints, c, sMax, MY_MRTHOD).startCluster();
    }

    public static List<Cluster> clusterBuild(double coC, double coO, double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            logger.debug("The stacktrace of TestItem {} {} {} is as follows:", testItem.getId(),testItem.getClassName(), testItem.getMethodName());
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new AHClusterOld(dataPoints, coC, coO, sMax, REBUCKET_METHOD).startCluster();
    }

    public static List<Cluster> clusterBuild(double sMax, List<TestItem> testItems) {
        List<DataPoint> dataPoints = new ArrayList<>();
        for (TestItem testItem : testItems) {
            dataPoints.add(new DataPoint(testItem.getId(), testItem));
        }
        return new AHClusterOld(dataPoints, sMax, TEST_CODE_METHOD).startCluster();
    }
}
