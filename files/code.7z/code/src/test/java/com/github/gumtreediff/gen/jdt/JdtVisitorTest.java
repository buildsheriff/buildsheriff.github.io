package com.github.gumtreediff.gen.jdt;

import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.tree.TreeContext;
import fdse.testcaseshow.code.ExtractCode;
import fdse.testcaseshow.code.JavaVisitor;
import fdse.testcaseshow.util.FileUtil;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.ToolFactory;
import org.eclipse.jdt.core.compiler.IScanner;
import org.eclipse.jdt.core.dom.*;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class JdtVisitorTest {
    @Test
    void test() throws IOException {
        String path = "/Users/projects/test-case-show/src/main/java/fdse/testcaseshow/feature/ChangedInfo.java";
        ASTParser parser = ASTParser.newParser(AST.JLS14);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        Map pOptions = JavaCore.getOptions();
        pOptions.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_DOC_COMMENT_SUPPORT, JavaCore.ENABLED);
        parser.setCompilerOptions(pOptions);
        char[] source = FileUtil.getFileCharArray(path);
        parser.setSource(source);
        IScanner scanner = ToolFactory.createScanner(false, false, false, false);
        scanner.setSource(source);
        AbstractJdtVisitor v = new JdtVisitor(scanner);
        ASTNode node = parser.createAST(null);
        node.accept(v);
        TreeContext src = v.getTreeContext();
        for (Tree tree : src.getRoot().preOrder()) {
            for (Iterator<Map.Entry<String, Object>> it = tree.getMetadata(); it.hasNext(); ) {
                Map.Entry entry = it.next();
            }
        }
    }

    @Test
    void test1() throws IOException {
        String path = "/Users/projects/test-case-show/src/main/java/fdse/testcaseshow/feature/ChangedInfo.java";
        ASTParser parser = ASTParser.newParser(AST.JLS14);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        Map pOptions = JavaCore.getOptions();
        pOptions.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_DOC_COMMENT_SUPPORT, JavaCore.ENABLED);
        parser.setCompilerOptions(pOptions);
        char[] source = FileUtil.getFileCharArray(path);
        parser.setSource(source);
        CompilationUnit node = (CompilationUnit) parser.createAST(null);
        JavaVisitor javaVisitor = new JavaVisitor(node);
        node.accept(javaVisitor);
        List<ExtractCode.MethodInfo> methodInfos = javaVisitor.getMethodInfos();
        for (ExtractCode.MethodInfo methodInfo:methodInfos) {
            MethodDeclaration md = methodInfo.getMethodDeclaration();
            if (md.parameters().size() > 0) {
                List<String> stringList = new ArrayList<>();
                for (Object o : md.parameters()) {
                    SingleVariableDeclaration singleVariableDeclaration = (SingleVariableDeclaration) o;
                    System.out.println(singleVariableDeclaration);
                    System.out.println(singleVariableDeclaration.getType().toString());
                    System.out.println(singleVariableDeclaration.getName());
                }
            }
        }
    }
}