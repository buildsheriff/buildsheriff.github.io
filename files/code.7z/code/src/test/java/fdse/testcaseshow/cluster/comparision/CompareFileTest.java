package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.ClusterEvaluation;
import fdse.testcaseshow.cluster.evaluation.SingleResult;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CompareFileTest {
    public TestCase getTestCase(long TestCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", TestCaseId);
        testCase = query.getSingleResult();
        testCase.getTestLog().getLog();
        return testCase;
    }

    @Test
    public void check136() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(136, session);
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        assertEquals(4, selectedTestItems.size());
        List<List<TestItem>> testItemListList = CompareFile.compareFileCluster(selectedTestItems);
        assertEquals(4, testItemListList.size());
        for (List<TestItem> testItemList : testItemListList) {
            assertEquals(1, testItemList.size());
        }
        List<Cluster> ahClusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
        assertEquals(4, ahClusters.size());
        SingleResult singleResult = SingleResult.getSingleResult(testCase, ahClusters, true);
        assertTrue(Double.isNaN(singleResult.getJaccardCoefficientJ()));
        assertFalse(Double.isNaN(singleResult.getPurity()));
        session.close();
    }
}