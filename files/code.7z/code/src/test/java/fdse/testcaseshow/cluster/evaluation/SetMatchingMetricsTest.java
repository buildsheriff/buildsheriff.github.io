package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Triplet;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SetMatchingMetricsTest {
    @Test
    public void test0() {
        int[][] array = ClusterEvaluationTest.array0;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        System.out.println(purity);
        assertEquals(0.71, purity, 0.0099);
        assertEquals(0.93, inversePurity, 0.0099);
        assertEquals(0.69, vrFMeasure, 0.0099);

    }

    @Test
    public void test1() {
        int[][] array = ClusterEvaluationTest.array1;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.78, purity, 0.0099);
        assertEquals(0.93, inversePurity, 0.0099);
        assertEquals(0.72, vrFMeasure, 0.0099);

    }

    @Test
    public void test2() {
        int[][] array = ClusterEvaluationTest.array2;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.78, purity, 0.0099);
        assertEquals(0.78, inversePurity, 0.0099);
        assertEquals(0.62, vrFMeasure, 0.0099);

    }

    @Test
    public void test3() {
        int[][] array = ClusterEvaluationTest.array3;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.78, purity, 0.0099);
        assertEquals(0.78, inversePurity, 0.0099);
        assertEquals(0.62, vrFMeasure, 0.0099);

    }

    @Test
    public void test4() {
        int[][] array = ClusterEvaluationTest.array4;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.55, purity, 0.0099);
        assertEquals(1, inversePurity, 0.0099);
        assertEquals(0.61, vrFMeasure, 0.0099);

    }

    @Test
    public void test5() {
        int[][] array = ClusterEvaluationTest.array5;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.55, purity, 0.0099);
        assertEquals(1, inversePurity, 0.0099);
        assertEquals(0.63, vrFMeasure, 0.0099);

    }

    @Test
    public void test6() {
        int[][] array = ClusterEvaluationTest.array6;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(1, purity, 0.0099);
        assertEquals(0.69, inversePurity, 0.0099);
        assertEquals(0.79, vrFMeasure, 0.0099);

    }

    @Test
    public void test7() {
        int[][] array = ClusterEvaluationTest.array7;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(1, purity, 0.0099);
        assertEquals(0.92, inversePurity, 0.0099);
        assertEquals(0.96, vrFMeasure, 0.0099);

    }

    @Test
    public void test8() {
        int[][] array = ClusterEvaluationTest.array8;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = SetMatchingMetrics.getSetMatchingMetrics(ahClusters);
        double purity = result.getValue0();
        double inversePurity = result.getValue1();
        double vrFMeasure = result.getValue2();
        assertEquals(0.71, purity, 0.0099);
        assertEquals(0.71, inversePurity, 0.0099);
        assertEquals(0.71, vrFMeasure, 0.0099);

    }
}