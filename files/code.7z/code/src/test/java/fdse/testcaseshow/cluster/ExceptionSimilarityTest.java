package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.evaluation.ExceptionSimilarityResultSummary;
import fdse.testcaseshow.cluster.evaluation.ResultSummary;
import fdse.testcaseshow.cluster.evaluation.StoreResultSummary;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;

class ExceptionSimilarityTest {

    public ResultSummary extractTestItems(double sMax, List<TestCase> testCases) {
        ResultSummary resultSummary = new ExceptionSimilarityResultSummary(new ExceptionSimilarity.Coefficient(sMax));
        for (TestCase testCase : testCases) {
            List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
            List<Cluster> clusters = ExceptionSimilarity.clusterBuild(sMax, selectedTestItems);
            resultSummary.addSingleResult(testCase, clusters, true);
        }
        return resultSummary;
    }

    @Test
    public void tuningCoefficient() {
        Instant start = Instant.now();
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id <= 307 and multipleCrash = true and crashIgnore = false", TestCase.class);
            List<TestCase> testCases = query.list();
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.EXCEPTIONSIMILARITY, true, null)) {
                for (double sMax = 0.51; sMax < 1.0001; sMax += 0.01) {
                    System.out.println("sMax: " + sMax);
                    ResultSummary resultSummary = extractTestItems(sMax, testCases);
                    storeResultSummary.write(resultSummary);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        Instant end = Instant.now();
        System.out.println("ExceptionSimilarity时间" + Duration.between(start, end));
    }

    @Test
    public void checkRefactor() {
        try(Session session = SessionUtil.getSession()) {
            // Transaction tx = session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where id <= 307 and multipleCrash = true and crashIgnore = false ", TestCase.class);
            List<TestCase> testCases = query.list();
            ResultSummary resultSummary = new ResultSummary();
            for (TestCase testCase : testCases) {
                // System.out.println(testCase.getId());
                List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
                List<Cluster> clusters = ExceptionSimilarity.clusterBuild(0.76, selectedTestItems);
                resultSummary.addSingleResult(testCase, clusters, true);
                int clusterNum = clusters.size();
                if (testCase.getExceptionMessageSim74() != null && clusterNum != testCase.getExceptionMessageSim74()) {
                    System.out.println(testCase.getId() + "->" + testCase.getCrashClusterNum() + "->" + testCase.getExceptionMessageSim74() + "->" + clusterNum);
                }
                // testCase.setExceptionMessageSim74(clusterNum);
            }
            try (StoreResultSummary storeResultSummary = new StoreResultSummary(StoreResultSummary.Method.EXCEPTIONSIMILARITY, false, null)) {
                storeResultSummary.write(resultSummary);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            // tx.commit();
        }
    }
}
