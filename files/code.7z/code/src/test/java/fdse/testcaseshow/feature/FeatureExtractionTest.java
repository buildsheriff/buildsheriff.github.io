package fdse.testcaseshow.feature;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.MysqlUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import static org.junit.jupiter.api.Assertions.*;

class FeatureExtractionTest {
    public TestCase getTestCase(long testCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", testCaseId);
        testCase = query.getSingleResult();
        return testCase;
    }

    @Test
    void getCommitNumber() {
        String repoName = "AlmasB/FXGL";
        String jobNumber = "739.1";
        assertEquals(2, FeatureExtraction.commit_number(repoName, jobNumber));
    }

    void print(List<Integer> one, List<Integer> multi, String boundName, int bound) {
        System.out.println("\n" + one.size() + " " + one);
        System.out.println("\n" + multi.size() + " " + multi);
        int max_ar = 0;
        int max_mr = 0;
        for (int i = 1; i <= bound; i++) {
            int or = 0;
            int mr = 0;
            for (int o : one) {
                if (o <= i) {
                    or += 1;
                }
            }
            for (int m : multi) {
                if (m > i) {
                    mr += 1;
                }
            }
            int ar = or + mr;
            if (ar > max_ar) max_ar = ar;
            if (mr > max_mr) max_mr = mr;
            System.out.println(boundName + ": " + i + " all: " + ar + " one: " + or + " multi: " + mr);
        }
        System.out.println("max_mr " + max_mr);
        System.out.println("max_ar " + max_ar);
    }

    void print(List<Integer> one, List<Integer> multi, int flag) {
        System.out.println("\n" + one.size() + " " + one);
        System.out.println("\n" + multi.size() + " " + multi);
        int or = 0;
        int mr = 0;
        for (int o : one) {
            if (o == flag) {
                or += 1;
            }
        }
        for (int m : multi) {
            if (m != flag) {
                mr += 1;
            }
        }
        int ar = or + mr;
        System.out.println(flag + " all: " + ar + " one: " + or + " multi: " + mr);
    }

    @Test
    void testRegex() {
        String path = "fragmentargs/processor/src/test/java/com/hannesdorfmann/fragmentargs/processor/DifferentPackageInheritanceTest.java";
        Matcher matcher = FeatureExtraction.testFilePattern.matcher(path);
        if (matcher.find()) {
            assertEquals("/test/", matcher.group());
        }

        path = "fragmentargs/processor/com/hannesdorfmann/fragmentargs/processor/DifferentPackageInheritanceTest.java";
        matcher = FeatureExtraction.testFilePattern.matcher(path);
        if (matcher.find()) {
            assertEquals("Test.java", matcher.group());
        }
        assertTrue(FeatureExtraction.isTestFile(path));
        path = "fragmentargs/processor/src/main/java/com/hannesdorfmann/fragmentargs/processor/DifferentPackageInheritance.java";
        assertFalse(FeatureExtraction.isTestFile(path));
    }
    @Test
    void test224() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(224, session);
        assertEquals(1221, FeatureExtraction.src_churn(testCase));
        assertEquals(524, FeatureExtraction.test_churn(testCase));
        assertEquals(1274, FeatureExtraction.line_added(testCase));
        assertEquals(471, FeatureExtraction.line_deleted(testCase));
        assertEquals(9, FeatureExtraction.files_added(testCase));
        assertEquals(1, FeatureExtraction.files_deleted(testCase));
        assertEquals(8, FeatureExtraction.files_modified(testCase));
        assertEquals(15, FeatureExtraction.src_files(testCase));
        assertEquals(3, FeatureExtraction.test_files(testCase));

        testCase = getTestCase(315, session);
        assertEquals(0, FeatureExtraction.src_churn(testCase));
        assertEquals(98, FeatureExtraction.test_churn(testCase));
        assertEquals(98, FeatureExtraction.line_added(testCase));
        assertEquals(0, FeatureExtraction.line_deleted(testCase));
        assertEquals(6, FeatureExtraction.files_added(testCase));
        assertEquals(0, FeatureExtraction.files_deleted(testCase));
        assertEquals(0, FeatureExtraction.files_modified(testCase));
        assertEquals(0, FeatureExtraction.src_files(testCase));
        assertEquals(6, FeatureExtraction.test_files(testCase));
        assertEquals(6, FeatureExtraction.class_changed(testCase));
        assertEquals(0, FeatureExtraction.class_modified(testCase));
        assertEquals(6, FeatureExtraction.class_added(testCase));
        assertEquals(0, FeatureExtraction.class_deleted(testCase));
        assertEquals(4, FeatureExtraction.met_changed(testCase));
        assertEquals(0, FeatureExtraction.met_modified(testCase));
        assertEquals(4, FeatureExtraction.met_added(testCase));
        assertEquals(0, FeatureExtraction.met_deleted(testCase));
        assertEquals(5, FeatureExtraction.field_changed(testCase));
        assertEquals(5, FeatureExtraction.field_added(testCase));
        assertEquals(0, FeatureExtraction.field_deleted(testCase));
        assertEquals(0, FeatureExtraction.field_modified(testCase));

        testCase = getTestCase(317, session);
        assertEquals(2, FeatureExtraction.class_changed(testCase));
        assertEquals(2, FeatureExtraction.class_modified(testCase));
        assertEquals(0, FeatureExtraction.class_added(testCase));
        assertEquals(0, FeatureExtraction.class_deleted(testCase));
        assertEquals(2, FeatureExtraction.met_changed(testCase));
        assertEquals(2, FeatureExtraction.met_modified(testCase));
        assertEquals(0, FeatureExtraction.met_added(testCase));
        assertEquals(0, FeatureExtraction.met_deleted(testCase));
        assertEquals(0, FeatureExtraction.field_changed(testCase));
        session.close();
    }
    @Test
    void anova1OfCommitNumberAboutCrash() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getCrashTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getCrashClusterNum() == 1) {
                one.add(FeatureExtraction.commit_number(testCase));
            } else {
                multi.add(FeatureExtraction.commit_number(testCase));
            }
        }
        print(one, multi, "commit number about crash", 16);
    }

    @Test
    void anova1OfCommitNumberAboutAssertion() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getAssertionTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getAssertionClusterNum() == 1) {
                one.add(FeatureExtraction.commit_number(testCase));
            } else {
                multi.add(FeatureExtraction.commit_number(testCase));
            }
        }
        print(one, multi, "commit number about assertion", 16);
    }

    @Test
    void anova1OfNumberOfChangedFilesAboutCrash() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getCrashTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getCrashClusterNum() == 1) {
                one.add(FeatureExtraction.file_changed(testCase));
            } else {
                multi.add(FeatureExtraction.file_changed(testCase));
            }
        }
        print(one, multi, "file number about crash", 31);

    }

    @Test
    void anova1OfNumberOfChangedFilesAboutAssertion() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getAssertionTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getAssertionClusterNum() == 1) {
                one.add(FeatureExtraction.file_changed(testCase));
            } else {
                multi.add(FeatureExtraction.file_changed(testCase));
            }
        }
        print(one, multi, "file number about assertion", 31);
    }

    @Test
    void anova1OfChangeConfigFileAboutCrash() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getCrashTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getCrashClusterNum() == 1) {
                one.add(FeatureExtraction.changeConfigFile(testCase));
            } else {
                multi.add(FeatureExtraction.changeConfigFile(testCase));
            }
        }
        print(one, multi, 0);
        print(one, multi, 1);
    }

    @Test
    void anova1OfChangeConfigFileAboutAssertion() {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> crashTestCases = MysqlUtil.getAssertionTestCases();
        for (TestCase testCase : crashTestCases) {
            if (testCase.getAssertionClusterNum() == 1) {
                one.add(FeatureExtraction.changeConfigFile(testCase));
            } else {
                multi.add(FeatureExtraction.changeConfigFile(testCase));
            }
        }
        print(one, multi, 0);
        print(one, multi, 1);
    }

    @Test
    void anova1OfSelectedChangedFilesAboutCrash() throws IOException {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        Session session = SessionUtil.getSession();
        List<TestCase> crashTestCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : crashTestCases) {
            System.out.println(testCase.getId());
            if (testCase.getCrashClusterNum() == 1) {
                one.add(FeatureExtraction.getSelectedChangedFiles(testCase).size());
            } else {
                multi.add(FeatureExtraction.getSelectedChangedFiles(testCase).size());
            }
        }
        session.close();
        print(one, multi, "SelectedChangedFiles about crash", 31);
    }

    @Test
    void anova1OfSelectedChangedFilesAboutAssertion() throws IOException {
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        Session session = SessionUtil.getSession();
        List<TestCase> crashTestCases = MysqlUtil.getAssertionTestCases(session);
        for (TestCase testCase : crashTestCases) {
            System.out.println(testCase.getId());
            if (testCase.getAssertionClusterNum() == 1) {
                one.add(FeatureExtraction.getSelectedChangedFiles(testCase).size());
            } else {
                multi.add(FeatureExtraction.getSelectedChangedFiles(testCase).size());
            }
        }
        session.close();
        print(one, multi, "SelectedChangedFiles about assertion", 31);
    }

    @Test
    void anova1Test() {
        Session session = SessionUtil.getSession();
        List<Integer> one = new ArrayList<>();
        List<Integer> multi = new ArrayList<>();
        List<TestCase> assertionTestCases = MysqlUtil.getAssertionTestCases(session);
        for (TestCase testCase : assertionTestCases) {
            if (testCase.getAssertionClusterNum() == 1) {
                one.add(FeatureExtraction.met_added(testCase));
            } else {
                multi.add(FeatureExtraction.met_added(testCase));
            }
        }

        print(one, multi, "bound", 20);

        session.close();
    }
}

