package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JavaFileLinkTaskTest {
    public TestCase getTestCase(long testCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", testCaseId);
        testCase = query.getSingleResult();
        return testCase;
    }

    private JavaFile getJavaFile(Collection<JavaFile> javaFiles, String completeFileName) {
        JavaFile javaFile = null;
        for (JavaFile j : javaFiles) {
            if (j.getCompleteFileName().equals(completeFileName)) {
                javaFile = j;
                break;
            }
        }
        return javaFile;
    }

    @Test
    public void test38() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(38, session);
        Collection<JavaFile> javaFiles = testCase.getJavaFiles();
        JavaFile javaFile = getJavaFile(javaFiles, "handlebars/src/test/java/com/github/jknack/handlebars/ParsingErrorTest.java");
        JavaFileLinkTask javaFileLinkTask = new JavaFileLinkTask(null, null);
        JavaVisitor javaVisitor = javaFileLinkTask.getJavaVisitor(javaFile.getFilePath());
        List<String> packageNames = javaFileLinkTask.getPackageNames(javaVisitor);
        assertEquals(1, packageNames.size());
        assertEquals("com.github.jknack.handlebars", packageNames.get(0));
        List<String> classNames = javaFileLinkTask.getClassNames(javaVisitor);
        classNames.forEach(System.out::println);
        assertEquals(8, classNames.size());
        assertTrue(classNames.contains("com.github.jknack.handlebars.Literals"));
        session.close();
    }

    @Test
    public void test217() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(217, session);
        Collection<JavaFile> javaFiles = testCase.getJavaFiles();
        JavaFile javaFile = getJavaFile(javaFiles, "fxgl/src/main/java/com/almasb/fxgl/scene/FXGLScene.java");
        JavaFileLinkTask javaFileLinkTask = new JavaFileLinkTask(null, null);
        JavaVisitor javaVisitor = javaFileLinkTask.getJavaVisitor(javaFile.getFilePath());
        List<String> packageNames = javaFileLinkTask.getPackageNames(javaVisitor);
        assertEquals(2, packageNames.size());
        assertEquals("com.almasb.fxgl.scene", packageNames.get(0));
        assertEquals("javafx.scene.layout", packageNames.get(1));
        List<String> classNames = javaFileLinkTask.getClassNames(javaVisitor);
        classNames.forEach(System.out::println);
        assertEquals(11, classNames.size());
        assertTrue(classNames.contains("com.almasb.fxgl.app.DSLKt"));

        List<JavaFile> usedJavaFiles = javaFileLinkTask.getUsedJavaFiles(session, javaFile.getId(), 217, packageNames, classNames);
        for (JavaFile jf : usedJavaFiles) {
            System.out.println(jf.getId() + " : " + jf.getCompleteFileName());
        }
        session.close();
    }

    @Test
    public void test243() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(243, session);
        Collection<JavaFile> javaFiles = testCase.getJavaFiles();
        JavaFile javaFile = getJavaFile(javaFiles, "web/web_support/src/main/java/com/intuit/tank/script/SleepTimeEditor.java");
        JavaFileLinkTask javaFileLinkTask = new JavaFileLinkTask(null, null);
        JavaVisitor javaVisitor = javaFileLinkTask.getJavaVisitor(javaFile.getFilePath());
        List<String> packageNames = javaFileLinkTask.getPackageNames(javaVisitor);
        assertEquals(1, packageNames.size());
        assertEquals("com.intuit.tank.script", packageNames.get(0));
        List<String> classNames = javaFileLinkTask.getClassNames(javaVisitor);
        classNames.forEach(System.out::println);
        assertEquals(15, classNames.size());
        List<JavaFile> usedJavaFiles = javaFileLinkTask.getUsedJavaFiles(session, javaFile.getId(), 243, packageNames, classNames);
        for (JavaFile jf : usedJavaFiles) {
            System.out.println(jf.getId() + " : " + jf.getCompleteFileName());
        }
        javaFile = getJavaFile(javaFiles, "api/api/src/test/java/com/intuit/tank/vm/common/ThreadLocalUsernameProviderCpTest.java");
        javaVisitor = javaFileLinkTask.getJavaVisitor(javaFile.getFilePath());
        packageNames = javaFileLinkTask.getPackageNames(javaVisitor);
        assertEquals(2, packageNames.size());
        assertEquals("com.intuit.tank.vm.common", packageNames.get(0));
        assertEquals("org.junit", packageNames.get(1));
        classNames = javaFileLinkTask.getClassNames(javaVisitor);
        classNames.forEach(System.out::println);
        assertEquals(3, classNames.size());
        assertTrue(classNames.contains("com.intuit.tank.vm.common.ThreadLocalUsernameProvider"));
        assertTrue(classNames.contains("com.intuit.tank.vm.common.UsernameProvider"));
        assertTrue(classNames.contains("org.junit.Assert"));

        session.close();
    }
}