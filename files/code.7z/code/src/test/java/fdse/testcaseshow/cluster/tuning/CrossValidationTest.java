package fdse.testcaseshow.cluster.tuning;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CrossValidationTest {
    public List<TestCase> getTestCases(List<Long> ids, Session session) {
        Query<TestCase> query = session.createQuery("from TestCase where id in :ids", TestCase.class);
        query.setParameterList("ids", ids);
        return query.list();
    }
    @Test
    public void testException() {
        Session session = SessionUtil.getSession();
        Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and crashIgnore = false ", TestCase.class);
        List<TestCase> testCases = query.list();
        CrossValidation crossValidation = new CrossValidation();
        List<Long> ids = crossValidation.getIds(testCases);
        assertEquals(100, ids.size());
        List<Long> trainIds = crossValidation.getTrainingIds(testCases, 2, 80, 20);
        assertEquals(20, trainIds.size());
        List<TestCase> trainTestCases = getTestCases(trainIds, session);
        int countOne = 0;
        int countMore = 0;
        for (TestCase testCase : trainTestCases) {
            if (testCase.getCrashClusterNum() == 1) {
                countOne++;
            } else {
                countMore++;
            }
        }
        assertEquals(16, countOne);
        assertEquals(4, countMore);
        List<Long> testIds = crossValidation.getTestIds(ids, trainIds);
        List<TestCase> testTestCases = getTestCases(testIds, session);
        assertEquals(80, testIds.size());
        countOne = 0;
        countMore = 0;
        for (TestCase testCase : testTestCases) {
            if (testCase.getCrashClusterNum() == 1) {
                countOne++;
            } else {
                countMore++;
            }
        }
        assertEquals(66, countOne);
        assertEquals(14, countMore);
        session.close();
    }

}