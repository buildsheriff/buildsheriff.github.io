package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.comparision.CompareFile;
import fdse.testcaseshow.cluster.evaluation.ClusterEvaluation;
import fdse.testcaseshow.cluster.evaluation.SingleResult;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ComparisionTest {

    public TestCase getTestCase(long TestCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", TestCaseId);
        testCase = query.getSingleResult();
        testCase.getTestLog().getLog();
        return testCase;
    }

    @Test
    public void test16() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(16, session);
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        assertEquals(7, selectedTestItems.size());
        List<List<TestItem>> testItemListList = CompareFile.compareFileCluster(selectedTestItems);
        assertEquals(1, testItemListList.get(0).size());
        assertEquals(6, testItemListList.get(1).size());
        List<Cluster> ahClustersCompareFile = ClusterEvaluation.testItemListListToClusterList(testItemListList);
        assertEquals(2, ahClustersCompareFile.size());

        SingleResult singleResultCompareFile = SingleResult.getSingleResult(testCase, ahClustersCompareFile, true);

        STSimilarity.Coefficient coefficient = new STSimilarity.Coefficient(0.22, 1.9, 6);
        List<Cluster> ahClustersSTSimilarity = STSimilarity.clusterBuild(coefficient, selectedTestItems);
        assertEquals(2, ahClustersCompareFile.size());
        SingleResult singleResultSTSimilarity = SingleResult.getSingleResult(testCase, ahClustersCompareFile, true);

        assertEquals(2, 2);
        session.close();
    }
}
