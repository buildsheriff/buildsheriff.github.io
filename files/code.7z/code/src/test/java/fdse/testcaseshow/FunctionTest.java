package fdse.testcaseshow;

import org.junit.jupiter.api.Test;

import java.io.FileInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class FunctionTest {
    @Test
    public void checkNoRemove() {
        System.out.println(Math.sqrt(0));
        double a = 0.0 / 0.0;
        System.out.println(a);
        System.out.println(a > 0.0);
        System.out.println(a >= 0.0);
        System.out.println(a < 0.0);
        System.out.println(a <= 0.0);
    }

    @Test
    public void testRethrow() {
        try {
            new FileInputStream("dda");
        } catch (IOException e) {
            assertThrows(RuntimeException.class, () -> {throw new RuntimeException(e);});

        }
        throw new RuntimeException();
    }

}