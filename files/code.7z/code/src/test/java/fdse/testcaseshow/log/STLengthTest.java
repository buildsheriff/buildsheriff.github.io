package fdse.testcaseshow.log;

import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class STLengthTest {

    @Test
    void getTestCaseLength() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : testCases) {
            int length = STLength.getTestCaseLength(testCase);
            System.out.println(testCase.getId() + " " + testCase.getLength() + " " + length);
        }
        session.close();
    }
}