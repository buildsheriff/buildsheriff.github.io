package fdse.testcaseshow.util;

import fdse.testcaseshow.model.TestCase;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReadTestCasesTest {

    @Test
    void getCrashTestCases() {
        List<TestCase> testCases = MysqlUtil.getCrashTestCases();
        assertTrue(testCases.size() - 100 >= 0);
        for (TestCase testCase : testCases) {
            assertTrue(testCase.getMultipleCrash());
            assertFalse(testCase.getCrashIgnore());
        }
    }

    @Test
    void getAssertionTestCases() {
        List<TestCase> testCases = MysqlUtil.getAssertionTestCases();
        assertTrue(testCases.size() - 100 >= 0);
        for (TestCase testCase : testCases) {
            assertTrue(testCase.getMultipleAssertion());
            assertFalse(testCase.getAssertionIgnore());
        }
    }
}