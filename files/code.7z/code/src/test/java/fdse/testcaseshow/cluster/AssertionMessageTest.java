package fdse.testcaseshow.cluster;

import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AssertionMessageTest {

    @Test
    void getAssertionMessage() {
        TestItem testItem = MysqlUtil.getTestItemById(506);
        String assertionMessage = AssertionMessage.getAssertionMessage(testItem);
        System.out.println(assertionMessage);
        assertEquals("expected <2013-06> but was <2012-06>", assertionMessage);

        testItem = MysqlUtil.getTestItemById(8);
        assertionMessage = AssertionMessage.getAssertionMessage(testItem);
        System.out.println(assertionMessage);
        assertEquals("org.junit.ComparisonFailure expected <'[Rang]eError'> but was <'[Typ]eError'>", assertionMessage);
    }

    @Test
    void getSim() {
        TestItem testItem1 = MysqlUtil.getTestItemById(505);
        TestItem testItem2 = MysqlUtil.getTestItemById(506);
        double sim = new AssertionMessage(null, 0.0).getSim(testItem1, testItem2);
        System.out.println(sim);
    }
}