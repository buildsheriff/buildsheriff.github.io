package fdse.testcaseshow.cluster;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EditDistanceTest {

    @Test
    void getsimilarity() {
        String str1 = "s u n d a y e e f";
        String str2 = "s a t u r d a y f r g";
        int d = EditDistance.minDistance(str1, str2);
        System.out.println(d);
        d = EditDistance.minDistance(str2, str1);
        System.out.println(d);

    }
}