package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class JavaFileDistancesTaskTest {
    public TestCase getTestCase(long testCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", testCaseId);
        testCase = query.getSingleResult();
        return testCase;
    }

    @Test
    public void testLongSet() {
        Set<Long> set = new HashSet<>();
        set.add(1L);
        set.add(7L);
        assertTrue(set.contains(7L));
        assertTrue(set.contains(1L));
        assertFalse(set.contains(9L));
    }

    @Test
    public void test293() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(293, session);
        Collection<JavaFile> javaFiles = testCase.getJavaFiles();
        JavaFileDistancesTask javaFileDistancesTask = new JavaFileDistancesTask(null, null);
        List<JavaFileDistances.Node> nodes = javaFileDistancesTask.initGraph(javaFiles, session);
        JavaFileDistances.Node node = null;
        for (JavaFileDistances.Node n : nodes) {
            if (n.getJavaFile().getCompleteFileName().equals("src/test/java/ru/lanwen/verbalregex/PredefinedCharClassesTest.java")) {
                node = n;
                break;
            }
        }
        assertEquals(5, node.getAdjNodes().size());
        List<JavaFileDistances.Node> sources = new ArrayList<>();
        nodes.forEach(n -> {
            if (n.getJavaFile().getChanged() != null && n.getJavaFile().getChanged().booleanValue() == true )
                sources.add(n);
        });
        assertEquals(2, sources.size());
        javaFileDistancesTask.breadthFirst(node);
        assertEquals(1, node.getDistance());
        for (JavaFileDistances.Node n : node.getAdjNodes()) {
            System.out.println(n.getJavaFile().getId());
            assertEquals(2, n.getDistance());
        }
        nodes.forEach(n -> {
            n.clear();
        });
        assertEquals(Integer.MAX_VALUE, node.getDistance());
        for (JavaFileDistances.Node n : node.getAdjNodes()) {
            System.out.println(n.getJavaFile().getId());
            assertEquals(Integer.MAX_VALUE, n.getDistance());
        }
        JavaFileDistances.Node node1 = null;
        for (JavaFileDistances.Node n : nodes) {
            if (n.getJavaFile().getCompleteFileName().equals("src/main/java/ru/lanwen/verbalregex/VerbalExpression.java")) {
                node1 = n;
                break;
            }
        }
        javaFileDistancesTask.breadthFirst(node1);
        assertEquals(1, node1.getDistance());
        assertEquals(2, node.getDistance());

        session.close();
    }
}