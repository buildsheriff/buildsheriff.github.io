package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.cluster.codesim.CodeSimUtil;
import fdse.testcaseshow.cluster.codesim.StatementVisitor;
import fdse.testcaseshow.code.JavaVisitor;
import fdse.testcaseshow.util.FileUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCodeStatement;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.*;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.*;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
class StatementVisitorTest {
    @Test
    void test1() {
        String s = "Mustache m=c.compile(\"simple.html\");";
        Statement statement = CodeSimUtil.parseStatement(s);
        System.out.println(statement);
        StatementVisitor statementVisitor = new StatementVisitor();
        statement.accept(statementVisitor);
        Set<String> simpleNames = statementVisitor.getSimpleNames();
        System.out.println(simpleNames);
        assertEquals(4, simpleNames.size());
        assertThat(simpleNames).contains("Mustache");
        List<String> names = statementVisitor.getNames();
        System.out.println(Arrays.toString(names.toArray()));
    }

    @Test
    void test2() {
        String s = "ByteArrayInputStream inputStream=new ByteArrayInputStream(outputStream.toByteArray());";
        Statement statement = CodeSimUtil.parseStatement(s);
        assertTrue(statement instanceof VariableDeclarationStatement);
    }

    @Test
    void test3() {
        try (Session session = SessionUtil.getSession()) {
            Query<TestCodeStatement> query = session.createQuery("from TestCodeStatement where id > 0 ", TestCodeStatement.class);
            List<TestCodeStatement> testCodeStatements = query.list();
            for (TestCodeStatement testCodeStatement : testCodeStatements) {
                System.out.println(testCodeStatement.getId());
                String s = testCodeStatement.getStatement();
                Statement statement = CodeSimUtil.parseStatement(s);
                if (statement instanceof VariableDeclarationStatement) {

                } else if (statement instanceof ExpressionStatement) {

                } else if (statement instanceof TryStatement) {

                } else {
                }
            }
        }
    }

    @Test
    void test4() {
        String s = "ThrowException e";
        assertNull(CodeSimUtil.parseStatement(s));
    }

    @Test
    void test_try() {
        String s = "try {\n" +
                "  Object result=eval(getClass().getResourceAsStream(\"/java-stack.js\"));\n" +
                "  fail(\"should have thrown\");\n" +
                "}\n" +
                " catch (ThrowException e) {\n" +
                "  StackTraceElement[] stack=e.getStackTrace();\n" +
                "  assertThat(stack[0].getLineNumber()).isEqualTo(13);\n" +
                "}\n";
        Statement statement = CodeSimUtil.parseStatement(s);
        assertTrue(statement instanceof TryStatement);
        TryStatement tryStatement = (TryStatement)statement;
        List list = tryStatement.resources();
        assertEquals(0, list.size());
        List catchClauses = tryStatement.catchClauses();
        assertEquals(1, catchClauses.size());
        CatchClause catchClause = (CatchClause) catchClauses.get(0);
        SingleVariableDeclaration singleVariableDeclaration = catchClause.getException();
        System.out.println(singleVariableDeclaration);
    }

    @Test
    void test_try1() {
        String s = "try (CloseableHttpResponse response=httpclient.execute(request)){\n" +
                "  assertEquals(200,response.getStatusLine().getStatusCode());\n" +
                "  EntityUtils.consume(response.getEntity());\n" +
                "}\n" +
                " ";
        Statement statement = CodeSimUtil.parseStatement(s);
        assertTrue(statement instanceof TryStatement);
        TryStatement tryStatement = (TryStatement)statement;
        List list = tryStatement.resources();
        assertEquals(1, list.size());
        VariableDeclarationExpression variableDeclarationExpression = (VariableDeclarationExpression)list.get(0);
        System.out.println(variableDeclarationExpression);
    }

    @Test
    void test5() {
        String s = "Map<Integer, String> map = new HashMap<>();";
        Statement statement = CodeSimUtil.parseStatement(s);
        System.out.println(statement);
        StatementVisitor statementVisitor = new StatementVisitor();
        statement.accept(statementVisitor);
        Set<String> simpleNames = statementVisitor.getSimpleNames();
        System.out.println(simpleNames);
        assertEquals(5, simpleNames.size());
    }

    @Test
    void test6() throws IOException {
        String path = "/Users/zhangchen/projects/test-case-show/src/main/java/fdse/testcaseshow/Starter.java";
        ASTParser parser = ASTParser.newParser(AST.JLS14);
        parser.setKind(ASTParser.K_COMPILATION_UNIT);
        Map pOptions = JavaCore.getOptions();
        pOptions.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_11);
        pOptions.put(JavaCore.COMPILER_DOC_COMMENT_SUPPORT, JavaCore.ENABLED);
        parser.setCompilerOptions(pOptions);
        char[] source = FileUtil.getFileCharArray(path);
        parser.setSource(source);
        CompilationUnit node = (CompilationUnit) parser.createAST(null);


        StatementVisitor statementVisitor = new StatementVisitor();
        node.accept(statementVisitor);
        Set<String> simpleNames = statementVisitor.getSimpleNames();
        System.out.println(simpleNames);
        assertEquals(15, simpleNames.size());
        List<String> names = statementVisitor.getNames();
        System.out.println(names);
    }
}