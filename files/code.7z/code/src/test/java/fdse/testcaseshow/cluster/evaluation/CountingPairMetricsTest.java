package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Triplet;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CountingPairMetricsTest {
    @Test
    public void test0() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array0);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.77, randStatisticR, 0.0099);
        assertEquals(0.38, jaccardCoefficientJ, 0.0099);
        assertEquals(0.57, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test1() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array1);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.79, randStatisticR, 0.0099);
        assertEquals(0.41, jaccardCoefficientJ, 0.0099);
        assertEquals(0.59, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test2() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array2);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.68, randStatisticR, 0.0099);
        assertEquals(0.31, jaccardCoefficientJ, 0.0099);
        assertEquals(0.47, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test3() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array3);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.7, randStatisticR, 0.0099);
        assertEquals(0.35, jaccardCoefficientJ, 0.0099);
        assertEquals(0.52, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test4() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array4);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.72, randStatisticR, 0.0099);
        assertEquals(0.37, jaccardCoefficientJ, 0.0099);
        assertEquals(0.61, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test5() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array5);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.72, randStatisticR, 0.0099);
        assertEquals(0.37, jaccardCoefficientJ, 0.0099);
        assertEquals(0.61, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test6() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array6);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.95, randStatisticR, 0.0099);
        assertEquals(0.71, jaccardCoefficientJ, 0.0099);
        assertEquals(0.84, folkesAndMallowsFM, 0.0099);
    }

    @Test
    public void test7() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array7);
        Triplet<Double, Double, Double> result = CountingPairMetrics.getCountingPairsMetrics(ahClusters);
        double randStatisticR = result.getValue0();
        double jaccardCoefficientJ = result.getValue1();
        double folkesAndMallowsFM = result.getValue2();
        assertEquals(0.95, randStatisticR, 0.0099);
        assertEquals(0.71, jaccardCoefficientJ, 0.0099);
        assertEquals(0.84, folkesAndMallowsFM, 0.0099);
    }
}