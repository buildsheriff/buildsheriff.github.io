package fdse.testcaseshow.cluster.comparision;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.cluster.evaluation.ClusterEvaluation;
import fdse.testcaseshow.cluster.evaluation.SingleResult;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class RebucketTest {
    public static TestCase getTestCase(long TestCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", TestCaseId);
        testCase = query.getSingleResult();
        testCase.getTestLog().getLog();
        return testCase;
    }

    @Test
    public void check16() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(16, session);
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        assertEquals(7, selectedTestItems.size());
        List<Cluster> clusters = AHClusterOld.clusterBuild(2.0, 0.3, 0.54, selectedTestItems);
        assertEquals(2, clusters.size());
        System.out.println(clusters);

        SingleResult singleResult = SingleResult.getSingleResult(testCase, clusters, true);
        System.out.println(singleResult.toStringOfClusterResult());
        System.out.println(singleResult.toString());
        assertEquals(1.00, singleResult.getPurity(), 0.00001);
        assertEquals(6 / 7.0, singleResult.getInversePurity(), 0.00001);
        assertEquals(12 / 13.0, singleResult.getVRFMeasure(), 0.00001);
        assertEquals(15 / 21.0, singleResult.getRandStatisticR(), 0.00001);
        assertEquals(15 / 21.0, singleResult.getJaccardCoefficientJ(), 0.00001);
        assertEquals(Math.sqrt(15 / 21.0), singleResult.getFolkesAndMallowsFM(), 0.00001);

        assertEquals(2, singleResult.getDist());
        assertEquals(1, singleResult.getBcubedPrecioson(), 0.00001);
        assertEquals(37.0 / 7 / 7 , singleResult.getBcubedRecall(), 0.00001);

        List<List<TestItem>> testItemListList = CompareFile.compareFileCluster(selectedTestItems);
        assertEquals(4, testItemListList.size());
        for (List<TestItem> testItemList : testItemListList) {
            assertEquals(1, testItemList.size());
        }
        List<Cluster> ahClusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
        assertEquals(4, ahClusters.size());
        session.close();
    }
}