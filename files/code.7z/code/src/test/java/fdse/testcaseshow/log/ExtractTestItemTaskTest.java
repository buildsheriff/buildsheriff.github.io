package fdse.testcaseshow.log;

import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

class ExtractTestItemTaskTest {
    public Session session = null;
    @BeforeEach
    public void setUp() {
    }


    @AfterEach
    void tearDown() {
    }

    public TestCase getTestCase(long TestCaseId) {
        TestCase testCase = null;
        try(Session session = SessionUtil.getSession()) {
            Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
            query.setParameter("id", TestCaseId);
            testCase = query.getSingleResult();
            testCase.getTestLog().getLog();
        }
        return testCase;
    }
    @Test
    public void testTestCase18() {
        TestCase testCase = getTestCase(18);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(12, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        List<String> crashSummary = task.getCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        Pattern pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern1, pattern);
        List<TestItem> items = task.extract(section);
        assertEquals(7, items.size());
        TestItem item1 = items.get(0);
        assertEquals("getOMEXMLVersion", item1.getMethodName());
        assertEquals(false, item1.isCrash());
    }
    @Test
    public void testTestCase21() {
        TestCase testCase = getTestCase(21);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(2, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        List<String> crashSummary = task.getCrashSummary(section);
        crashSummary.forEach(System.out::println);
        Matcher matcher = ExtractTestItemTask.pattern1.matcher(crashSummary.get(1));
        if (matcher.find())
            System.out.println(matcher.group());
        Pattern pattern = task.getPattern(crashSummary);
        assertEquals(ExtractTestItemTask.pattern1, pattern);
        List<String> items = task.splitSummary(crashSummary, pattern);
        assertEquals(3, items.size());
        String s0 = items.get(0);
        TestItem testItem0 = task.stringToTestItem(s0, true, pattern);
        assertEquals("retrofit2.adapter.guava.ListenableFutureTest", testItem0.getClassName());
        assertEquals("bodySuccess200", testItem0.getMethodName());
        assertEquals(": java.lang.NoClassDefFoundError: org/json/JSONException", testItem0.getErrorMessage());
    }

    @Test
    public void testTestCase32() {
        TestCase testCase = getTestCase(32);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(2, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        assertEquals(0, nonCrashSummary.size());
        List<String> crashSummary = task.getCrashSummary(section);
        assertEquals(0, crashSummary.size());
        assertEquals(0, nonCrashSummary.size());
        List<TestItem> specialTestItems = task.extractSpecialItems(section);
        assertEquals(21, specialTestItems.size());
        assertEquals("AssignHelperTest", specialTestItems.get(0).getClassName());
        assertEquals("assignContext", specialTestItems.get(0).getMethodName());
        assertTrue(specialTestItems.get(0).isCrash());
        assertEquals("NumberHelperTest", specialTestItems.get(20).getClassName());
        assertEquals("stripesWithNullReference", specialTestItems.get(20).getMethodName());
        assertTrue(specialTestItems.get(20).isCrash());
    }

    @Test
    public void testTestCase34() {
        TestCase testCase = getTestCase(34);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);

        List<TestItem> testItems = task.extractItems(section);
        assertEquals(2, testItems.size());
        assertEquals("com.github.jknack.handlebars.I18NHelperTest", testItems.get(0).getClassName());
        assertEquals("defaultI18nJs", testItems.get(0).getMethodName());
        assertFalse(testItems.get(0).isCrash());
        assertEquals("com.github.jknack.handlebars.i213.Issue213", testItems.get(1).getClassName());
        assertEquals("args", testItems.get(1).getMethodName());
        assertFalse(testItems.get(1).isCrash());
    }

    @Test
    public void testTestCase45() {
        TestCase testCase = getTestCase(45);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(2, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        Pattern pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern4, pattern);
        List<String> items = task.splitSummary(nonCrashSummary, pattern);
        assertEquals(2, items.size());
        String s0 = items.get(0);
        TestItem testItem0 = task.stringToTestItem(s0, true, pattern);
        assertEquals("TiffWriterTest", testItem0.getClassName());
        assertEquals("testSaveBytes", testItem0.getMethodName());
        assertEquals("» TestNG \nThe data provider is trying to pass 7 p...", testItem0.getErrorMessage());
    }

    @Test
    public void testTestCase48() {
        TestCase testCase = getTestCase(48);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        TestItem testItem0 = testItems.get(0);
        assertEquals("AllKindOfValuesCommandsTest", testItem0.getClassName());
        assertEquals("setNxExAndGet1", testItem0.getMethodName());
    }

    @Test
    public void testTestCase92() {
        TestCase testCase = getTestCase(92);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getClassName() + "-" + testItem.getMethodName() + "-" + testItem.isCrash());
        }
        assertEquals(2, testItems.size());
        assertEquals("WaitHookOptionsTest", testItems.get(0).getClassName());
        assertEquals("testDefaultValues", testItems.get(0).getMethodName());
        assertFalse(testItems.get(0).isCrash());
        assertEquals("WaitHookOptionsTest", testItems.get(1).getClassName());
        assertEquals("testDefaultValuesConfigureAwait", testItems.get(1).getMethodName());
        assertFalse(testItems.get(1).isCrash());
    }

    @Test
    public void testTestCase94() {
        TestCase testCase = getTestCase(94);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(2, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getClassName() + "-" + testItem.getMethodName() + "-" + testItem.isCrash());
        }
        assertEquals(12, testItems.size());
    }



    @Test
    public void testTestCase103() {
        TestCase testCase = getTestCase(103);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        assertEquals(0, nonCrashSummary.size());
        List<String> crashSummary = task.getCrashSummary(section);
        assertEquals(0, crashSummary.size());
        assertEquals(0, nonCrashSummary.size());
        List<TestItem> specialTestItems = task.extractSpecialItems(section);
        assertEquals(2, specialTestItems.size());
        assertEquals("StringUtilsTestCase", specialTestItems.get(0).getClassName());
        assertEquals("testBigShiftJIS_1", specialTestItems.get(0).getMethodName());
        assertFalse(specialTestItems.get(0).isCrash());
        assertEquals("StringUtilsTestCase", specialTestItems.get(1).getClassName());
        assertEquals("testNotSupported_1", specialTestItems.get(1).getMethodName());
        assertFalse(specialTestItems.get(1).isCrash());
    }

    @Test
    public void testTestCase223() {
        TestCase testCase = getTestCase(223);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        assertEquals(84, nonCrashSummary.size());
        Pattern pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<String> items = task.splitSummary(nonCrashSummary, pattern);

    }

    @Test
    public void testTestCase145() {
        TestCase testCase = getTestCase(145);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(9, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        assertEquals(0, nonCrashSummary.size());
        List<String> crashSummary = task.getCrashSummary(section);
        Pattern pattern = task.getPattern(crashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<String> items = task.splitSummary(crashSummary, pattern);
        String s0 = items.get(0);
        TestItem testItem0 = task.stringToTestItem(s0, true, pattern);
        assertEquals("BaseSeleniumTestCase", testItem0.getClassName());
        assertEquals("initSelenium", testItem0.getMethodName());

        String s1 = items.get(1);
        TestItem testItem1 = task.stringToTestItem(s1, true, pattern);
        assertEquals("UserAdminFT", testItem1.getClassName());
        assertEquals("logout", testItem1.getMethodName());
        List<List<String>> stackTraces = task.extractStackTrace(section);
        task.setStackTraceOfTestItemThroughMidMatch(testItem0, stackTraces);
        assertNotNull(testItem0.getStackTrace());
        task.setStackTraceOfTestItemThroughMidMatch(testItem1, stackTraces);
        assertNotNull(testItem1.getStackTrace());
    }
    @Test
    public void testTestCase148() {
        TestCase testCase = getTestCase(148);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(6, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> crashSummary = task.getCrashSummary(section);
        crashSummary.forEach(System.out::println);
        Pattern pattern = task.getPattern(crashSummary);
        assertEquals(ExtractTestItemTask.pattern4, pattern);
        List<String> items = task.splitSummary(crashSummary, pattern);
        String s0 = items.get(0);
        TestItem testItem0 = task.stringToTestItem(s0, true, pattern);

    }
    @Test
    public void testTestCase154() {

    }
    @Test
    public void testTestCase221() {
        TestCase testCase = getTestCase(221);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        Pattern pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<String> items = task.splitSummary(nonCrashSummary, pattern);
        assertEquals(1, items.size());
        String s0 = items.get(0);
        System.out.println(s0);
        TestItem testItem0 = task.stringToTestItem(s0, false, pattern);
        assertEquals("DontRunTestsWhenInitFailTest", testItem0.getClassName());
        assertEquals("testRun", testItem0.getMethodName());
        assertEquals("Expecting actual not to be null", testItem0.getErrorMessage());

        List<String> crashSummary = task.getCrashSummary(section);
        pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        items = task.splitSummary(crashSummary, pattern);
        assertEquals(8, items.size());

        s0 = items.get(0);
        testItem0 = task.stringToTestItem(s0, false, pattern);
        assertEquals("AfterTest", testItem0.getClassName());
        assertNull(testItem0.getMethodName());
        assertEquals("» NullPointer", testItem0.getErrorMessage());

        List<List<String>> stackTraces = task.extractStackTrace(section);
        task.setStackTraceOfTestItemThroughClassName(testItem0, stackTraces);
        System.out.println(testItem0.getStackTrace());
        assertEquals("when_driver_is_null_then_it_is_handle(org.fluentlenium.integration.AfterTest)  Time elapsed: 0.001 sec  <<< ERROR!\n" +
                "java.lang.NullPointerException", testItem0.getStackTrace());
    }
    @Test
    public void testTestCase169() {
        TestCase testCase = getTestCase(169);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(10, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        Pattern pattern = task.getPattern(nonCrashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<String> items = task.splitSummary(nonCrashSummary, pattern);
        assertEquals(6, items.size());
        String s0 = items.get(0);
        TestItem testItem0 = task.stringToTestItem(s0, false, pattern);
        assertEquals("ContainerLifecyleObserverTest", testItem0.getClassName());
        assertEquals("testExtensionBuilder", testItem0.getMethodName());
        assertNull(testItem0.getErrorMessage());

        section = sections.get(7);
        nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        List<String> crashSummary = task.getCrashSummary(section);
    }

    @Test
    public void testTestCase208() {
        TestCase testCase = getTestCase(208);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        List<String> crashSummary = task.getCrashSummary(section);
        crashSummary.forEach(System.out::println);
    }

    @Test
    public void testTestCase217() {

    }

    @Test
    public void testTestCase220() {
        TestCase testCase = getTestCase(220);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(6, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> crashSummary = task.getCrashSummary(section);
        crashSummary.forEach(System.out::println);
        Pattern pattern = task.getPattern(crashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<String> items = task.splitSummary(crashSummary, pattern);
        assertEquals(72, items.size());
    }

    @Test
    public void testTestCase225() {
        TestCase testCase = getTestCase(225);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> crashSummary = task.getCrashSummary(section);
        Pattern pattern = task.getPattern(crashSummary);
        assertEquals(ExtractTestItemTask.pattern3, pattern);
        List<TestItem> specialTestItems = task.extractItems(section);
        assertEquals(3, specialTestItems.size());
        assertEquals("interval while condition is true", specialTestItems.get(0).getMethodName());
        assertNotNull(specialTestItems.get(0).getStackTrace());
        assertEquals("once", specialTestItems.get(2).getMethodName());
        assertNotNull(specialTestItems.get(2).getStackTrace());
    }

    @Test
    public void testTestCase269() {
        TestCase testCase = getTestCase(269);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        assertEquals(5, nonCrashSummary.size());
        List<TestItem> testItems = task.extractItems(section);
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getClassName() + "-" + testItem.getMethodName() + "-" + testItem.isCrash());
        }
        assertEquals(4, testItems.size());

    }

    @Test
    public void testTestCase277() {
        TestCase testCase = getTestCase(277);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(5, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getClassName() + "-" + testItem.getMethodName() + "-" + testItem.isCrash());
        }
        assertEquals(4, testItems.size());
        assertEquals("NakadiGatewayTest", testItems.get(0).getClassName());
        assertEquals("shouldExposeFailedCommit", testItems.get(0).getMethodName());
        assertFalse(testItems.get(0).isCrash());
        assertEquals("NakadiGatewayTest", testItems.get(1).getClassName());
        assertEquals("shouldExposeConsumerException", testItems.get(1).getMethodName());
        assertFalse(testItems.get(1).isCrash());
        assertEquals("NakadiGatewayTest", testItems.get(2).getClassName());
        assertEquals("shouldExposeTimeoutException", testItems.get(2).getMethodName());
        assertFalse(testItems.get(2).isCrash());
    }

    @Test
    public void testTestCase278() {
        TestCase testCase = getTestCase(278);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(8, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        for (TestItem testItem : testItems) {
            System.out.println(testItem.getClassName() + "-" + testItem.getMethodName() + "-" + testItem.isCrash());
        }
        assertEquals(9, testItems.size());
        assertEquals("AccessTokensMissingTest", testItems.get(0).getClassName());
        assertEquals("shouldFailDueToMissingAccessTokenUrl", testItems.get(0).getMethodName());
        assertFalse(testItems.get(0).isCrash());
        assertEquals("PluginOverrideTest", testItems.get(1).getClassName());
        assertEquals("shouldFailDueToUnknownModule", testItems.get(1).getMethodName());
        assertFalse(testItems.get(1).isCrash());
    }

    @Test
    public void testTestCase280() {
        TestCase testCase = getTestCase(280);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(7, sections.size());
        List<String> section = sections.get(sections.size() - 1);

        List<TestItem> testItems = task.extractItems(section);
        assertEquals(2, testItems.size());
        assertEquals("MetricsPluginTest", testItems.get(0).getClassName());
        assertEquals("shouldRecordFailureMetric", testItems.get(0).getMethodName());
        assertFalse(testItems.get(0).isCrash());
        assertEquals("MetricsPluginTest", testItems.get(1).getClassName());
        assertEquals("shouldRecordSuccessMetric", testItems.get(1).getMethodName());
        assertFalse(testItems.get(1).isCrash());
    }

    @Test
    public void testTestCase295() {
        TestCase testCase = getTestCase(295);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        testItems.removeIf(testItem -> testItem.isCrash());
        assertEquals(3, testItems.size());
    }

    @Test
    public void testTestCase297() {
        TestCase testCase = getTestCase(297);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(6, testItems.size());
        System.out.println(testItems.get(0).getStackTrace());
    }

    @Test
    public void testTestCase298() {
        TestCase testCase = getTestCase(298);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(2, testItems.size());
    }

    @Test
    public void testTestCase300() {
        TestCase testCase = getTestCase(300);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(58, testItems.size());
    }

    @Test
    public void testTestCase303() {
        TestCase testCase = getTestCase(303);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(2, testItems.size());
        assertEquals("OperationResourceIntTest", testItems.get(0).getClassName());
        assertEquals("getAllOperations", testItems.get(0).getMethodName());
        assertEquals("OperationResourceIntTest", testItems.get(1).getClassName());
        assertEquals("getOperation", testItems.get(1).getMethodName());
    }

    @Test
    public void testTestCase314() {
        TestCase testCase = getTestCase(314);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(6, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(5, testItems.size());
        assertEquals("com.[secure].breakerbox.service.core.tests.InstancesTest", testItems.get(0).getClassName());
        assertEquals("propertyKeyUris", testItems.get(0).getMethodName());
    }

    @Test
    public void testTestCase316() {
        TestCase testCase = getTestCase(316);
        assertNotNull(testCase.getTestLog().getLog());
        ExtractTestItemTask task = new ExtractTestItemTask(null, null);
        task.setTestCase(testCase);
        List<String> logList = LogUtil.stringToList(testCase.getTestLog().getLog());
        List<List<String>> sections = task.contentSplit(logList);
        assertEquals(1, sections.size());
        List<String> section = sections.get(sections.size() - 1);
        List<String> nonCrashSummary = task.getNonCrashSummary(section);
        nonCrashSummary.forEach(System.out::println);
        List<TestItem> testItems = task.extractItems(section);
        assertEquals(2, testItems.size());
        System.out.println(testItems.get(0).getStackTrace());
    }

    @Test
    public void noclass() {
        try(Session session = SessionUtil.getSession()) {
            List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
            for (TestCase testCase : testCases) {
                List<TestItem> testItems = STSimilarity.getSelectedTestItems(testCase);
                for (TestItem testItem : testItems) {
                    if (testItem.getStackTrace() != null && testItem.getStackTrace().contains("java.lang.NoClassDefFoundError")) {
                        System.out.println(testCase.getId());
                        break;
                    }
                }
            }
        }
    }
}