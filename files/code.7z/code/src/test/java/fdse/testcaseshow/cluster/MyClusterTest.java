package fdse.testcaseshow.cluster;

import fdse.testcaseshow.cluster.comparision.AHClusterOld;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class MyClusterTest {

    @Test
    public void test1() {
        try(Session session = SessionUtil.getSession()) {
            Transaction tx =session.beginTransaction();
            Query<TestCase> query = session.createQuery("from TestCase where multipleCrash = true and noStackTrace = false", TestCase.class);
            List<TestCase> testCases = query.list();

            for (TestCase testCase : testCases) {
                Collection<TestItem> testItems = testCase.getTestItems();
                List<TestItem> selectedTestItems = new ArrayList<>();
                testItems.forEach(e -> {
                    if (e.isCrash()  && e.getStackTrace() != null)
                        selectedTestItems.add(e);
                });
                List<Cluster> clusters = AHClusterOld.clusterBuild(2.0, 0.49, selectedTestItems);
                testCase.setMyCluster(clusters.size());
            }

            tx.commit();
        }
    }
}