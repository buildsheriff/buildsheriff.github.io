package fdse.testcaseshow.feature;

import com.github.gumtreediff.actions.Diff;
import com.github.gumtreediff.actions.EditScript;
import com.github.gumtreediff.actions.EditScriptGenerator;
import com.github.gumtreediff.actions.SimplifiedChawatheScriptGenerator;
import com.github.gumtreediff.actions.model.Action;
import com.github.gumtreediff.client.Run;
import com.github.gumtreediff.gen.TreeGenerators;
import com.github.gumtreediff.matchers.MappingStore;
import com.github.gumtreediff.matchers.Matcher;
import com.github.gumtreediff.matchers.Matchers;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.tree.TreeContext;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.util.FileUtil;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.javatuples.Quintet;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class ChangedInfoTest {
    public TestCase getTestCase(long testCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", testCaseId);
        testCase = query.getSingleResult();
        return testCase;
    }

    public List<String> getNames(Set<Token> tokens) {
        List<String> list = new ArrayList<>();
        for (Token token : tokens) {
            list.add(token.getName());
        }
        return list;
    }

    @Test
    public void test17() {
        Instant start = Instant.now();
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(17, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(6, changedFileInfos.size());
        Set<Token> classNames = changedInfo.getChangedClassTokens();
        List<String> list = getNames(classNames);
        assertThat(list).contains("ThrowException");
        for (Token s : classNames) {
            assertEquals(TokenType.CLASS_NAME, s.getType());
        }
        Instant end = Instant.now();
        session.close();
    }

    @Test
    public void test21() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(21, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(6, changedFileInfos.size());
        Set<Token> classNames = changedInfo.getChangedClassTokens();
        session.close();
    }

    @Test
    public void test24() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(24, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(3, changedFileInfos.size());
        try {
            List<Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript>> diffFileASTInfos = changedInfo.getDiffFileASTInfos();
            for (var astInfo : diffFileASTInfos) {
                for (Action action : astInfo.getValue4()) {
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Set<Token> names = changedInfo.getChangedTokens();
        for (Token i : names) {
        }
        System.out.println(names);
        assertTrue(names.contains(Token.create("Retrofit", TokenType.CLASS_NAME, TokenStatus.MODIFIED)));
        assertTrue(names.contains(Token.create("Builder", TokenType.CLASS_NAME, TokenStatus.MODIFIED)));
        assertTrue(names.contains(Token.create("callbackExecutor", TokenType.METHOD_NAME, TokenStatus.MODIFIED)));
        assertTrue(names.contains(Token.create("addConverterFactory", TokenType.METHOD_NAME, TokenStatus.MODIFIED)));
        session.close();
    }

    @Test
    public void test50() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(50, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(1, changedFileInfos.size());
        Set<Token> methodNames = changedInfo.getChangedMethodTokens();
        System.out.println(methodNames);
        assertTrue(methodNames.contains(Token.create("checkIfMatch", TokenType.METHOD_NAME, TokenStatus.ADDED)));
        session.close();
    }

    @Test
    public void test59() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(59, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        Set<Token> resourceNames = changedInfo.getChangedResourceNames();
        assertEquals(20, changedFileInfos.size());
        assertEquals(4, resourceNames.size());
        assertTrue(resourceNames.contains(Token.create("simple.html", TokenType.RESOURCE_NAME, TokenStatus.MODIFIED)));
        assertTrue(resourceNames.contains(Token.create("simple.txt", TokenType.RESOURCE_NAME, TokenStatus.MODIFIED)));
        session.close();
    }

    @Test
    public void test_177() throws IOException {
//        Session session = SessionUtil.getSession();
//        ChangedInfo changedInfo = new ChangedInfo(177, session);
//        List<ChangedInfo.DiffFileInfo> diffFileInfos = changedInfo.getDiffFileInfos();
//        assertEquals(206, diffFileInfos.size());
//        Map<ChangedInfo.DiffFileInfo, List<Action>> diffFileActionsMap = changedInfo.getDiffFileActionsMap();
//        assertEquals(178, diffFileActionsMap.size());
//        for (Map.Entry<ChangedInfo.DiffFileInfo, List<Action>> entry : diffFileActionsMap.entrySet()) {
//            if (entry.getKey().getCurrentFilePath().contains("OAuth2AccessTokenImpl.java")) {
//                List<Action> actions = entry.getValue();
//                System.out.println(actions.size());
//            }
//        }

        Run.initGenerators();
        //String srcFile = "/Users/zhangchen/projects/test-case-show/resources/code/OpenID-Connect-Java-Spring-Server-aadc011104ef8dd85e6138bb4247354b71345f45/openid-connect-client/src/main/java/org/mitre/oauth2/introspectingfilter/AuthorizationRequestImpl.java";
        //String dstFile = "/Users/zhangchen/projects/test-case-show/resources/code/OpenID-Connect-Java-Spring-Server-06b621e9950081ba3e398fde73834a2c64afd21a/openid-connect-client/src/main/java/org/mitre/oauth2/introspectingfilter/AuthorizationRequestImpl.java";
        String filePath = "src/main/java/redis/clients/jedis/JedisShardInfo.java";

        String preRepoPath = FileUtil.getRepoPath("fd5cb1c");
        String currentRepoPath = FileUtil.getRepoPath("6590287");
        String srcFile = Paths.get(preRepoPath, filePath).toString();;
        String dstFile = Paths.get(currentRepoPath, filePath).toString();
        TreeContext src = TreeGenerators.getInstance().getTree(srcFile);
        TreeContext dst = TreeGenerators.getInstance().getTree(dstFile);
        System.out.println(srcFile);

        for (Tree tree : dst.getRoot().preOrder()) {
            System.out.println(tree);
        }
        Matcher defaultMatcher = Matchers.getInstance().getMatcher();
        MappingStore mappings = defaultMatcher.match(src.getRoot(), dst.getRoot());

        EditScriptGenerator editScriptGenerator = new SimplifiedChawatheScriptGenerator();
        EditScript actions = editScriptGenerator.computeActions(mappings);

        for (Action action : actions) {
            System.out.println(action);
            System.out.println(action.getNode().getType());
        }
        Diff diff = new Diff(src, dst, mappings, actions);
    }

    @Test
    public void test_224() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(224, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(18, changedFileInfos.size());
        System.out.println(changedInfo.getChangedJavaTokens());
        Set<Token> typeNames = changedInfo.getChangedClassTokens();
        assertTrue(typeNames.contains(Token.create("FluentLeniumFunctionalWaitTest", TokenType.CLASS_NAME, TokenStatus.ADDED)));
        assertTrue(typeNames.contains(Token.create("FluentWaitSelectorMatcher", TokenType.CLASS_NAME, TokenStatus.ADDED)));

        Set<Token> methodNames = changedInfo.getChangedMethodTokens();
        assertTrue(methodNames.contains(Token.create("checkUseCustomMessage", TokenType.METHOD_NAME, TokenStatus.ADDED)));
        assertTrue(methodNames.contains(Token.create("checkPolling", TokenType.METHOD_NAME, TokenStatus.ADDED)));
        session.close();
    }

    @Test
    public void test_302() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(302, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(3, changedFileInfos.size());
        List<Quintet<ChangedFileInfo, Tree, Tree, MappingStore, EditScript>> astInfos = null;
        try {
            astInfos = changedInfo.getDiffFileASTInfos();
        } catch (IOException e) {
            e.printStackTrace();
        }
        astInfos.forEach(item -> {
            System.out.println(item.getValue0().getCurrentFilePath());
            List<Action> actions = changedInfo.getValidatedActions(item.getValue1(), item.getValue2(), item.getValue3(), item.getValue4());
            for (Action action : actions) {
                System.out.println(action);
            }

        });
        System.out.println(changedInfo.getChangedJavaTokens());
        Set<Token> typeNames = changedInfo.getChangedClassTokens();
        assertTrue(typeNames.contains(Token.create("NDCG", TokenType.CLASS_NAME, TokenStatus.MODIFIED)));
        Set<Token> names = changedInfo.getChangedTokens();
        assertTrue(names.contains(Token.create("ndcg", TokenType.FIELD_NAME, TokenStatus.ADDED)));
        session.close();
    }

    @Test
    public void test_310() {
        Session session = SessionUtil.getSession();
        ChangedInfo changedInfo = new ChangedInfo(310, session);
        List<ChangedFileInfo> changedFileInfos = changedInfo.getDiffFileInfos();
        assertEquals(12, changedFileInfos.size());
        Set<Token> names = changedInfo.getChangedTokens();
        System.out.println(names);
        List<String> list = getNames(names);
        assertTrue(names.contains(Token.create("issuer", TokenType.METHOD_NAME, TokenStatus.MODIFIED)));
        assertFalse(names.contains(Token.create("iss", TokenType.METHOD_NAME, TokenStatus.EMPTY)));
        session.close();
    }
}