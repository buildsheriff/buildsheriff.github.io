package fdse.testcaseshow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCaseShowApplicationTests {

    @Test
    void contextLoads() {
    }

}
