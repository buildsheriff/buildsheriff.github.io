package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Triplet;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BcubedMetricsTest {
    @Test
    public void test0() {
        int[][] array = ClusterEvaluationTest.array0;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.59, bcubedPrecision, 0.0099);
        assertEquals(0.89, bcubedRecall, 0.0099);
    }

    @Test
    public void test1() {
        int[][] array = ClusterEvaluationTest.array1;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.69, bcubedPrecision, 0.0099);
        assertEquals(0.89, bcubedRecall, 0.0099);
    }

    @Test
    public void test2() {
        int[][] array = ClusterEvaluationTest.array2;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.69, bcubedPrecision, 0.0099);
        assertEquals(0.71, bcubedRecall, 0.0099);
    }

    @Test
    public void test3() {
        int[][] array = ClusterEvaluationTest.array3;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.69, bcubedPrecision, 0.0099);
        assertEquals(0.75, bcubedRecall, 0.0099);

    }

    @Test
    public void test4() {
        int[][] array = ClusterEvaluationTest.array4;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.49, bcubedPrecision, 0.0099);
        assertEquals(1, bcubedRecall, 0.0099);

    }

    @Test
    public void test5() {
        int[][] array = ClusterEvaluationTest.array5;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(0.56, bcubedPrecision, 0.0099);
        assertEquals(1, bcubedRecall, 0.0099);
    }

    @Test
    public void test6() {
        int[][] array = ClusterEvaluationTest.array6;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(1, bcubedPrecision, 0.0099);
        assertEquals(0.69, bcubedRecall, 0.0099);

    }

    @Test
    public void test7() {
        int[][] array = ClusterEvaluationTest.array7;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Triplet<Double, Double, Double> result = BcubedMetrics.getBcubedMetrics(ahClusters);
        double bcubedPrecision = result.getValue0();
        double bcubedRecall = result.getValue1();
        double bcubedFMeasure = result.getValue2();
        assertEquals(1, bcubedPrecision, 0.0099);
        assertEquals(0.88, bcubedRecall, 0.0099);
    }
}