package fdse.testcaseshow.cluster.evaluation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SingleResultTest {

    @Test
    void testToString() {
        String s = String.format("id: %d length: %f", null, 0.0f / 0.0f);
        System.out.println(s);
    }
}