package fdse.testcaseshow.cluster;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StoreSimTest {

    @Test
    void test() {
        double a = 0.08;
        assertEquals("0.08", String.format("%.2f", a));
        double b = 0.98;
        assertEquals("0.98", String.format("%.2f", b));
        double c = 1;
        assertEquals("1.00", String.format("%.2f", c));
        double d = 0.7999999999999999;
        assertEquals("0.80", String.format("%.2f", d));
    }
}