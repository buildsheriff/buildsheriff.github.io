package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.javatuples.Quartet;
import org.javatuples.Triplet;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EntropyMetricsTest {
    @Test
    public void test0() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array0);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(1.02, entropy, 0.0099);
        assertEquals(0.26, classEntropy, 0.0099);
        assertEquals(1.23, mutualInformation, 0.0099);
        assertEquals(1.29, vi, 0.00999);
    }

    @Test
    public void test1() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array1);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0.83, entropy, 0.0099);
        assertEquals(0.26, classEntropy, 0.0099);
        assertEquals(1.43, mutualInformation, 0.0099);
        assertEquals(1.09, vi, 0.00999);
    }

    @Test
    public void test2() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array2);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0.83, entropy, 0.0099);
        assertEquals(0.69, classEntropy, 0.0099);
        assertEquals(1, mutualInformation, 0.0099);
        assertEquals(1.52, vi, 0.00999);
    }

    @Test
    public void test3() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array3);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0.83, entropy, 0.0099);
        assertEquals(0.49, classEntropy, 0.0099);
        assertEquals(1, mutualInformation, 0.0099);
        assertEquals(1.32, vi, 0.00999);
    }

    @Test
    public void test4() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array4);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(1.29, entropy, 0.0099);
        assertEquals(0, classEntropy, 0.0099);
        assertEquals(0.99, mutualInformation, 0.0099);
        assertEquals(1.28, vi, 0.00999);
    }

    @Test
    public void test5() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array5);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(1.29, entropy, 0.0099);
        assertEquals(0, classEntropy, 0.0099);
        assertEquals(0.99, mutualInformation, 0.0099);
        assertEquals(1.28, vi, 0.00999);
    }

    @Test
    public void test6() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array6);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0, entropy, 0.0099);
        assertEquals(0.61, classEntropy, 0.0099);
        assertEquals(2.19, mutualInformation, 0.0099);
        assertEquals(0.61, vi, 0.0099);
    }

    @Test
    public void test7() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array7);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0, entropy, 0.0099);
        assertEquals(0.28, classEntropy, 0.0099);
        assertEquals(2.19, mutualInformation, 0.0099);
        assertEquals(0.27, vi, 0.0099);
    }

    @Test
    public void test8() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array8);
        Quartet<Double, Double, Double, Double> result = EntropyMetrics.getEntropyMetrics(ahClusters);
        double entropy = result.getValue0();
        double classEntropy = result.getValue1();
        double mutualInformation = result.getValue2();
        double vi = result.getValue3();
        assertEquals(0.96, entropy, 0.0099);
        assertEquals(1.01, classEntropy, 0.0099);
    }
}