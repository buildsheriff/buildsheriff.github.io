package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EditDistanceMetricsTest {
    @Test
    public void test0() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array0);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(7, dist);
    }

    @Test
    public void test1() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array1);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(7, dist);
    }

    @Test
    public void test2() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array2);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(7, dist);
    }

    @Test
    public void test3() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array3);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(6, dist);
    }

    @Test
    public void test4() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array4);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(6, dist);
    }

    @Test
    public void test5() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array5);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(6, dist);
    }

    @Test
    public void test6() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array6);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(9, dist);
    }

    @Test
    public void test7() {
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(ClusterEvaluationTest.array7);
        int dist = EditDistanceMetrics.getEditDistance(ahClusters);
        assertEquals(6, dist);
    }

}