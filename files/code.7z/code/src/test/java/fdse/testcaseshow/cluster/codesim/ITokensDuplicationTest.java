package fdse.testcaseshow.cluster.codesim;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

class ITokensDuplicationTest {
    @Test
    void test_TokensContainDuplication() {
        ITokensDuplication tokensDuplication = TokensContainDuplication.getInstance();
        Collection<String> collection = Arrays.asList("zc", "zly", "hpy", "zc");
        Collection<String> result = tokensDuplication.processTokens(collection);
        assertEquals(4, result.size());
    }

    @Test
    void test_TokensRemoveDuplication() {
        ITokensDuplication tokensDuplication = TokensRemoveDuplication.getInstance();
        Collection<String> collection = Arrays.asList("zc", "zly", "hpy", "zc");
        Collection<String> result = tokensDuplication.processTokens(collection);
        assertEquals(3, result.size());
        assertTrue(result.contains("zc"));
        assertTrue(result.contains("zly"));
        assertTrue(result.contains("hpy"));
    }
}