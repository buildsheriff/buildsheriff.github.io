package fdse.testcaseshow.code;

import fdse.testcaseshow.model.JavaFile;
import fdse.testcaseshow.model.JavaFileToken;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExtractJavaTokenTest {
    @Test
    public void test16() {
        Session session = SessionUtil.getSession();
        JavaFile javaFile = MysqlUtil.getJavaFileById(session, 151L);
        ExtractJavaTokenTask extractJavaTokenTask = new ExtractJavaTokenTask(null, null);
        List<JavaFileToken> javaFileTokens = extractJavaTokenTask.getTokens(javaFile);
        for (JavaFileToken javaFileToken : javaFileTokens) {
            assertEquals(1, javaFileToken.getDistance());
        }

        javaFile = MysqlUtil.getJavaFileById(session, 1L);
        javaFileTokens = extractJavaTokenTask.getTokens(javaFile);
        for (JavaFileToken javaFileToken : javaFileTokens) {
            assertEquals(3, javaFileToken.getDistance());
        }
        session.close();
    }
}