package fdse.testcaseshow.code;

import fdse.testcaseshow.log.LogUtil;
import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.javatuples.Pair;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.regex.Matcher;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ExtractCodeTaskTest {
    public TestCase getTestCase(long TestCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", TestCaseId);
        testCase = query.getSingleResult();
        return testCase;
    }

    public TestItem getTestItem(long id, String className, String methodName, Session session) {
        TestItem testItem = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", id);
        TestCase testCase = query.getSingleResult();
        for (TestItem t : testCase.getTestItems()) {
            if (t.getClassName().equals(className) && t.getMethodName().equals(methodName)) {
                return t;
            }
        }
        return null;
    }

    public TestItem getTestItem(long id, String summaryPart, Session session) {
        TestItem testItem = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", id);
        TestCase testCase = query.getSingleResult();
        for (TestItem t : testCase.getTestItems()) {
            if (t.getSummary().contains(summaryPart)) {
                return t;
            }
        }
        return null;
    }

    @Test
    void splitClassFullName() {
        String frame = "at redis.clients.jedis.Protocol.processError(Protocol.java:114)";
        Matcher matcher = LogUtil.framePattern.matcher(frame);
        if (matcher.find()) {
            System.out.println(matcher);
            for (int i = 1; i < 7; i++) {
                System.out.println(matcher.group(i));
            }
        }

        String classFullName = "fdse.testcaseshow.log.ExtractTestItemTask";
        Pair<String, String> pair = ExtractCodeTask.splitClassFullName(classFullName);
        assertEquals("fdse.testcaseshow.log", pair.getValue0());
        assertEquals("ExtractTestItemTask", pair.getValue1());
    }

    @Test
    void getFrameInfoList() {
        Session session = SessionUtil.getSession();
        ExtractCodeTask extractCodeTask = new ExtractCodeTask(null, null, null);
        TestItem testItem = getTestItem(217, "PlatformerLevelGeneratorTest.make", session);
        List<FrameInfo> frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        assertEquals(1, frameInfoList.size());
        assertEquals("PlatformerLevelGeneratorTest", frameInfoList.get(frameInfoList.size() - 1).getClassName());
        assertEquals("make", frameInfoList.get(frameInfoList.size() - 1).getMethodName());

        testItem = getTestItem(17, "testNumberNegativeDigitsRangeError(org.dynjs.runtime.builtins.types.BuiltinNumberTest)", session);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        assertEquals(258, frameInfoList.get(frameInfoList.size() - 1).getNum());

        testItem = getTestItem(18, "getOMEXMLVersion(loci.formats.utests.xml.OMEXMLServiceTest)", session);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        MethodInfo methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(151, "testGetJsonIdPolicyFalse(org.geoserver.wfs.json.GeoJSONTest)", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(224, "checkPolling(org.fluentlenium.integration.FluentLeniumFunctionalWaitTest)", session);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(269, "si.[secure].rescu.RestInvocationHandlerTest", "testHttpBasicAuth", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(277, "NakadiGatewayTest", "shouldExposeFailedCommit", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(280, "MetricsPluginTest", "shouldRecordFailureMetric", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);

        testItem = getTestItem(300, "TXmlReaderWriter>TAbstractFeatureModelReaderWriter.testFeatureCount", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        frameInfoList.forEach(System.out::println);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        System.out.println(methodInfo.getMethodDeclaration());
        assertNotNull(methodInfo);

        testItem = getTestItem(314, "propertyKeyUris(com.[secure].breakerbox.service.core.tests.InstancesTest)", session);
        ExtractCodeTask.replaceSecure(testItem);
        frameInfoList = ExtractCodeTask.getFrameInfoList(testItem);
        methodInfo = extractCodeTask.extractTestCode(testItem, frameInfoList.get(frameInfoList.size() - 1), session);
        assertNotNull(methodInfo);
        session.close();
    }

    @Test
    void test_258() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(258, session);
        List<TestItem> testItems = (List<TestItem>) testCase.getTestItems();
        ExtractCodeTask extractCodeTask = new ExtractCodeTask(null, null, null);
        TestItem testItem = null;
        for (TestItem t : testItems) {
            if (t.getClassName().equals("com.thoughtworks.xstream.io.xml.JDom2ReaderTest") && t.getMethodName().equals("testIsXXEVulnerableWithExternalGeneralEntity")) {
                testItem = t;
                break;
            }
        }
        assertNotNull(testItem);
        List<FrameInfo> frameInfoList = extractCodeTask.getFrameInfoList(testItem);
        frameInfoList.forEach(System.out::println);
        session.close();
    }

}