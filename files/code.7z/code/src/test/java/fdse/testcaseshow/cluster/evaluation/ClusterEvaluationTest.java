package fdse.testcaseshow.cluster.evaluation;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.DataPoint;
import fdse.testcaseshow.cluster.comparision.RebucketTest;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.SessionUtil;
import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
import org.hibernate.Session;
import org.javatuples.Quartet;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class ClusterEvaluationTest {
    public static int[][] array0 = {
            {0, 1, 1},
            {0, 0, 0, 0},
            {2, 3, 4, 5, 5, 5, 5}
    };

    public static int[][] array0_t = {
            {0, 1, 1, 1, 1},
            {0, 0},
            {2},
            {2},
            {2},
            {2, 2, 2, 2}
    };
    public static int[][] array0_mysql = {
            {1, 2, 2},
            {1, 1, 1, 1},
            {3, 4, 5, 6, 6, 6, 6}
    };

    public static int[][] array1 = {
            {0},
            {1, 1},
            {0, 0, 0, 0},
            {2, 3, 4, 5, 5, 5, 5}
    };

    public static int[][] array2 = {
            {0},
            {0, 0},
            {0, 0, 0, 0},
            {1, 2, 3, 4, 4, 4, 4}
    };
    public static int[][] array3 = {
            {0, 0, 0},
            {0, 0, 0, 0},
            {1, 2, 3, 4, 4, 4, 4}
    };

    public static int[][] array4 = {
            {0, 1, 2, 3},
            {4, 5, 5, 5, 5}
    };
    public static int[][] array5 = {
            {0, 1, 2, 3, 4},
            {5, 5, 5, 5}
    };

    public static int[][] array6 = {
            {0},
            {0},
            {1},
            {1},
            {2},
            {2},
            {3},
            {3},
            {4, 4, 4, 4, 4}
    };
    public static int[][] array7 = {
            {0, 0},
            {1, 1},
            {2, 2},
            {3, 3},
            {4, 4, 4, 4},
            {4}
    };
    // https://stackoverflow.com/questions/35709562/how-to-calculate-clustering-entropy-a-working-example-or-software-code
    public static int[][] array8 = {
            {0, 0, 0, 0, 0, 1},
            {0, 1, 1, 1, 1, 2},
            {0, 0, 2, 2, 2}
    };

    public static void checkTestItemListList(int[][] array, List<List<TestItem>> testItemListList) {
        for (int i = 0; i < array.length; i++) {
            int[] subArray = array[i];
            for (int j = 0; j < subArray.length; j++) {
                assertEquals(subArray[j], testItemListList.get(i).get(j).getClusterType());
            }
        }
    }

    public static void checkAHClusterList(int[][] array, List<Cluster> ahClusters) {
        for (int i = 0; i < array.length; i++) {
            assertEquals(i, ahClusters.get(i).getClusterID());
            int[] subArray = array[i];
            for (int j = 0; j < subArray.length; j++) {
                assertEquals(subArray[j], ahClusters.get(i).getDataPoints().get(j).getTestItem().getClusterType());
            }
        }
    }

    public static void checkClusterList(int[][] array, List<List<Integer>> clusterList) {
        assertEquals(array.length, clusterList.size());
        for (int i = 0; i < array.length; i++) {
            int[] subArray = array[i];
            assertEquals(subArray.length, clusterList.get(i).size());
            for (int j = 0; j < subArray.length; j++) {
                assertEquals(subArray[j], clusterList.get(i).get(j));
            }
        }
    }

    static Stream<int[][]> dataProvider() {
        return Stream.of(array0, array1, array2, array3, array4, array5, array6, array7, array8);
    }

    @ParameterizedTest
    @MethodSource("dataProvider")
    public void testTransformation(int[][] array) {
        List<List<TestItem>> testItemListList = ClusterEvaluation.intArrayToTestItemList(array);
        assertEquals(array.length, testItemListList.size());
        checkTestItemListList(array, testItemListList);
        List<Cluster> ahClusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
        assertEquals(array.length, ahClusters.size());
        checkAHClusterList(array, ahClusters);
        ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        checkAHClusterList(array, ahClusters);
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        checkClusterList(array, clusterList);
    }

    private static MyCluster getMyCluster(List<MyCluster> myClusterList, int i) {
        MyCluster myCluster = null;
        for (MyCluster mc : myClusterList) {
            if (mc.getMyClusterId() == i) {
                myCluster = mc;
            }
        }
        return myCluster;
    }

    public static void checkMyclusterList(List<MyCluster> myClusterList, List<List<Integer>> intListList, boolean isCompareCategories) {
        for (int i = 0; i < intListList.size(); i++) {
            List<Integer> intList = intListList.get(i);
            MyCluster myCluster = getMyCluster(myClusterList, i);
            assertEquals(myCluster.getClusterSize(), intList.size());
            List<Integer> ids = new ArrayList<>();
            for (MyDataPoint myDataPoint : myCluster.getMyDataPoints()) {
                if (isCompareCategories) {
                    ids.add(myDataPoint.getCluster().getMyClusterId());
                } else {
                    ids.add(myDataPoint.getCategory().getMyClusterId());
                }
            }
            Collections.sort(intList);
            Collections.sort(ids);
            assertTrue(intList.equals(ids));
        }
    }

    private static MyDataPoint getMyDataPoint(List<MyDataPoint> myDataPoints, int categoryId, int clusterId) {
        for (MyDataPoint myDataPoint : myDataPoints) {
            if (myDataPoint.getCategory().getMyClusterId() == categoryId && myDataPoint.getCluster().getMyClusterId() == clusterId)
                return myDataPoint;
        }
        return null;
    }

    public static void checkMyDataPoints(int[][] array, List<MyDataPoint> myDataPoints) {
        for (int i = 0; i < array.length; i++) {
            int[] subarray = array[i];
            for (int j = 0; j < subarray.length; j++) {
                MyDataPoint myDataPoint = getMyDataPoint(myDataPoints, subarray[j], i);
                assertNotNull(myDataPoint);
            }
        }
    }

    @ParameterizedTest
    @MethodSource("dataProvider")
    void testClusterListToMyDataPointList(int[][] array) {
        int N = 0;
        for (int[] subarray : array) {
            N += subarray.length;
        }
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        Quartet<List<MyCluster>, List<MyCluster>, List<MyDataPoint>, Integer> result = ClusterEvaluation.clusterListToMyDataPointList(ahClusters);
        List<MyCluster> categories = result.getValue0();
        List<MyCluster> clusters = result.getValue1();
        List<MyDataPoint> myDataPoints = result.getValue2();
        assertEquals(N, myDataPoints.size());
        assertEquals(N, result.getValue3());
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        checkMyclusterList(clusters, clusterList, false);
        List<List<Integer>> categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        checkMyclusterList(categories, categoryList, true);
        checkMyDataPoints(array, myDataPoints);

    }

    @Test
    void testClusterListToCategoryList() {
        int[][] array = array0;
        int[][] array_mysql = array0_mysql;
        int[][] array_t = array0_t;
        List<Cluster> ahClusters = ClusterEvaluation.intArrayToClusterList(array);
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        List<List<Integer>> categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        checkClusterList(array_t, categoryList);

        ahClusters = ClusterEvaluation.intArrayToClusterList(array_mysql);
        checkAHClusterList(array_mysql, ahClusters);
        clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);

        checkClusterList(array, clusterList);
        categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        checkClusterList(array_t, categoryList);
    }



    @Test
    public void case_138_145() {
        int[][] simArray = {
                {0, 0, 1}
        };
        List<List<TestItem>> testItemListList = ClusterEvaluation.intArrayToTestItemList(simArray);
        assertEquals(1, testItemListList.size());
        checkTestItemListList(simArray, testItemListList);
        List<Cluster> ahClusters = ClusterEvaluation.testItemListListToClusterList(testItemListList);
        assertEquals(1, ahClusters.size());
        Session session = SessionUtil.getSession();
        TestCase testCase = RebucketTest.getTestCase(138, session);
        SingleResult singleResult = SingleResult.getSingleResult(testCase, ahClusters, true);
        System.out.println(singleResult);
        checkAHClusterList(simArray, ahClusters);
        Quartet<List<MyCluster>, List<MyCluster>, List<MyDataPoint>, Integer> quartet = ClusterEvaluation.clusterListToMyDataPointList(ahClusters);
        List<MyCluster> categories = quartet.getValue0();
        List<MyCluster> clusters = quartet.getValue1();
        List<MyDataPoint> myDataPoints = quartet.getValue2();
        int N = quartet.getValue3();
        assertEquals(6, categories.size());
        assertEquals(3, clusters.size());
        assertEquals(14, myDataPoints.size());
        assertEquals(14, N);
        double bcubedPrecision = BcubedMetrics.bcubedPrecision(myDataPoints, N);
        assertEquals(0.59, bcubedPrecision, 0.01);
        double bcubedRecall = BcubedMetrics.bcubedRecall(myDataPoints, N);
        assertEquals(0.88, bcubedRecall, 0.01);
        List<List<Integer>> clusterList = ClusterEvaluation.aHClusterListToClusterList(ahClusters);
        checkClusterList(array0, clusterList);
        List<List<Integer>> categoryList = ClusterEvaluation.clusterListToCategoryList(clusterList);
        categoryList.forEach(list -> {
            list.forEach(System.out::print);
            System.out.println();
        });
        assertEquals(6, categoryList.size());
        session.close();
    }
}