package fdse.testcaseshow.cluster;

import fdse.testcaseshow.util.SessionUtil;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class STSimilarityWithoutDistanceTest {
    public TestCase getTestCase(long TestCaseId, Session session) {
        TestCase testCase = null;
        Query<TestCase> query = session.createQuery("from TestCase where id=:id", TestCase.class);
        query.setParameter("id", TestCaseId);
        testCase = query.getSingleResult();
        testCase.getTestLog().getLog();
        return testCase;
    }
    @Test
    public void check148() {
        Session session = SessionUtil.getSession();
        TestCase testCase = getTestCase(148, session);
        List<TestItem> selectedTestItems = STSimilarity.getSelectedTestItems(testCase);
        List<Cluster> clusters = STSimilarityWithoutDistance.clusterBuild(selectedTestItems, 0.51,
                1.7, 0, 1, 1);
        for (Cluster cluster : clusters) {
            System.out.println(cluster);
        }
        session.close();
    }
}