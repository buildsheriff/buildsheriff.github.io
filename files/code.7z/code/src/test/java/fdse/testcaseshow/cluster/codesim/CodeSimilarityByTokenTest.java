package fdse.testcaseshow.cluster.codesim;

import fdse.testcaseshow.cluster.Cluster;
import fdse.testcaseshow.cluster.STSimilarity;
import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestCodeStatement;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CodeSimilarityByTokenTest {
    @Test
    void test_17() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 17);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 17);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(17L);
        assertNotNull(distanceMap);
        assertEquals(0, distanceMap.get("ThrowException"));
        assertEquals(2, distanceMap.get("testNumberNegativeDigitsRangeError"));
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        TestItem testItem1 = null;
        TestItem testItem2 = null;
        for (TestItem t : selectedTestItems) {
            if (t.getMethodName().equals("testNumberNegativeDigitsRangeError"))
                testItem1 = t;
            if (t.getMethodName().equals("testNumberTooManyDigitsRangeError"))
                testItem2 = t;
        }
        Collection<TestCodeStatement> testCodeStatements = testItem1.getTestCodeStatements();
        assertEquals(testCodeStatements.size(), 1);
        List<String> statementTokens = CodeSimilarity.getStatementTokens(((List<TestCodeStatement>)testCodeStatements).get(0));
        List<String> methodTokens1 = CodeSimilarity.getTokens(testItem1, distanceMap);
        assertEquals(statementTokens.size(), methodTokens1.size());
        assertTrue(statementTokens.contains("ThrowException"));
        List<String> methodTokens2 = CodeSimilarity.getTokens(testItem2, distanceMap);
        System.out.println(methodTokens1);
        System.out.println(methodTokens2);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        assertEquals(1.0, sim);
        session.close();
    }

    @Test
    void test_22() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 22);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 22);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(22);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(0, distanceMap.get("responseFailure"));
        assertEquals(0, distanceMap.get("bodyFailure"));
        session.close();
    }

    @Test
    void test_24() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 24);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 24);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(24);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        session.close();
    }

    @Test
    void test_42() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 42);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensContainDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 42);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(42);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

        session.close();
    }

    @Test
    void test_48() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 48);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(48);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(0, distanceMap.get("setNxExAndGet"));
        assertEquals(0, distanceMap.get("setAndExpireMillis"));
        assertEquals(0, distanceMap.get("setNxExAndGet"));
        assertEquals(0, distanceMap.get("setIfNotExistAndGet"));
        assertEquals(0, distanceMap.get("setAndExpire"));
        session.close();
    }

    @Test
    void test_59() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 59);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 59);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(59L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(0, distanceMap.get("simple.html"));
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);;
        List<String> methodTokens1 = CodeSimilarity.getTokens(testItem1, distanceMap);
        List<String> methodTokens2 = CodeSimilarity.getTokens(testItem2, distanceMap);
        System.out.println(methodTokens1);
        System.out.println(methodTokens2);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        session.close();
    }

    @Test
    void test_79() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 79);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.5, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(79L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(3, selectedTestItems.size());
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_136() {

    }

    @Test
    void test_274() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 274);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.5, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(274L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(2, selectedTestItems.size());
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_293() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 293);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.5, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(293L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(9, selectedTestItems.size());
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_296() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 296);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.8, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(296L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(3, selectedTestItems.size());
        TestItem testItem0 = selectedTestItems.get(0);
        TestItem testItem1 = selectedTestItems.get(1);
        TestItem testItem2 = selectedTestItems.get(2);
        double sim = codeSimilarity.getSim(testItem0, testItem1);
        double sim1 = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        System.out.println(sim1);
        session.close();
    }

    @Test
    void test_300() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 300);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.8, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(300);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(6, selectedTestItems.size());
        TestItem testItem0 = selectedTestItems.get(0);
        TestItem testItem1 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem0, testItem1);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_305() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 305);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.5, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(305L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(4, selectedTestItems.size());
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_310() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 310);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 1.5, 16, 0, 0.78);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(310L);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
        assertEquals(4, selectedTestItems.size());
        TestItem testItem1 = selectedTestItems.get(0);
        TestItem testItem2 = selectedTestItems.get(1);
        double sim = codeSimilarity.getSim(testItem1, testItem2);
        System.out.println(sim);
        session.close();
    }

    @Test
    void test_315() {
        Session session = SessionUtil.getSession();
        TestCase testCase = MysqlUtil.getTestCaseById(session, 315);
        List<TestItem> selectedTestItems = CodeSimilarity.getSelectedTestItems(testCase);
        CodeSimilarity.Coefficient coefficient = new CodeSimilarity.Coefficient(0, 0, 16, 0, 0.86);
        CodeSimilarity codeSimilarity = new CodeSimilarityByToken(selectedTestItems, testCase.getJavaFileTokens(), coefficient, TokensRemoveDuplication.getInstance());
        assertEquals(codeSimilarity.testCaseId, 315);
        Map<String, Integer> distanceMap = CodeSimilarity.getDistanceMap(315);
        assertNotNull(distanceMap);
        for (Map.Entry<String, Integer> entry : distanceMap.entrySet()) {
        }
        assertEquals(0, distanceMap.get("ClassInPackageA.java"));
        session.close();
    }

    @Test
    void test_exception() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase :testCases) {
            List<TestItem> testItems = STSimilarity.getSelectedTestItems(testCase);
            List<Long> list = new ArrayList<>();
            for (TestItem testItem : testItems) {
                if (testItem.getTestCode() == null) {
                    list.add(testItem.getId());
                }

            }
            if (list.size() > 0)
                System.out.println(testCase.getId() + " -> " + list);
        }
        session.close();
    }
}