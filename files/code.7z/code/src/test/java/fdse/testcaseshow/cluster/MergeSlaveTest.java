package fdse.testcaseshow.cluster;

import fdse.testcaseshow.model.TestCase;
import fdse.testcaseshow.model.TestItem;
import fdse.testcaseshow.util.MysqlUtil;
import fdse.testcaseshow.util.SessionUtil;
import org.hibernate.Session;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MergeSlaveTest {

    @Test
    void test() {
        Session session = SessionUtil.getSession();
        List<TestCase> testCases = MysqlUtil.getCrashTestCases(session);
        for (TestCase testCase : testCases) {
            List<TestItem> testItems = STSimilarity.getSelectedTestItems(testCase);
            System.out.println(testCase.getId() + "  " + testItems.size());
        }
        session.close();
    }
}